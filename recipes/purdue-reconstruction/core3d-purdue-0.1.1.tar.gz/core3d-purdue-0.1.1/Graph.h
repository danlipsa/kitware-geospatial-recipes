#ifndef __LiDAR_POINT_PROCESS_TOPOLOGY_GRAPH_CLASS_DEFINE_H__
#define __LiDAR_POINT_PROCESS_TOPOLOGY_GRAPH_CLASS_DEFINE_H__

#include "Function.h"
#define  TPGROUP_INATIAL 9999


class Graph
{
private:

	int n_V;//
	int *m_Matrix;//

	vector<G_Vertex > m_V;//
	vector<G_Edge > m_E;//

	vector<G_Edge > m_E_attr;

	int *m_MatrixTemp;

public:
	vector<IDList > *m_loops;
	int n_loops;
	Graph *tpGraph_childs;
	vector<Graph * > *m_childs;
public:
	Graph();
// initial
	void graphInitial(int n_vertex,vector<void *> *vertexMes=NULL);

// vertex operation
	void setVertexType(int ID, int m_type);
	int insert_Vertex(void *attr=NULL);

	 G_Vertex* getVertexbyID(int ID){return &m_V.data()[(ID)];}
	 int getVertexCount(){ return (int)m_V.size(); }
	
	int getDegreeOfaVertex(int vID);
	int getDegreeOfaVertex_noneStep(int vID);
	void findNeighbours(int vertex_ID,IDList *pN);
	void findNeighbours_noneStep(int vertex_ID,IDList *pN);
//edge operation
	int insert_Edge(int ID_1,int ID_2,void *attr=NULL);

	int insert_Edge_withType(int ID_1, int ID_2, int m_type, void *attr = NULL);
	
	//// -1 out of range  0 not exist  1 success
	int setEdge(int ID_1,int ID_2,bool flag,double weight,ridgeType edgeType,TP_Vertex *p1=NULL,TP_Vertex *p2=NULL);
	int setEdgeFlag(int ID_1,int ID_2,bool flag);//
	int setEdgeWeight(int ID_1,int ID_2,double weight);
	int setEdgeType(int ID_1,int ID_2,ridgeType edgeType);
	
	G_Edge* getEdge(int ID_1,int ID_2);//
	G_Edge* getEdgebyFatherID(int ID)
	{
		for (int i = 0; i<m_E.size(); i++)
		{
			if (m_E.data()[i].fatherID == ID)return &m_E.data()[ID];
		}
		return NULL;
	}
	G_Edge* getEdgebyID(int ID){return &m_E.data()[ID];}//
	int getEdgeCount(){return m_E.size();} 

	bool setFatherID_v(int ID,int fatherID);
	int getFatherID_v(int ID);
	bool setFatherID_e(int ID,int fatherID);
	int getFatherID_e(int ID);

//
	int findConnectGroups(int *flags);

	int findLoops();
	int getloopsCount(){return n_loops;}
	void decomposeGraph();


	void expansionGraphFlags(vector<IDList >  *m_flags);

//*************************************
	
	int insert_Edge_Multiply(int ID_1,int ID_2,void *attr1=NULL);
	void getEdge_Multiply(int ID_1,int ID_2,vector<G_Edge* > *m_backs);

//*************************************
//	G_Tree* SpanningTree(int fatherID, int *matrixNow);

private:
	int checkEdge(int ID_1,int ID_2);
	void DFS(int  beginID, int groupNum,int *flags);//

	void BFS(int  beginID, int groupNum,int *vertex_flags,int *edge_flags);//
	void caculateTempMatrix();
	int setTempMatrix_bystepEdge(int step_flag);
	int setTempMatrix_byinsideEdge(int step_flag);
	int findTriangles();
	int findQuadrangles();
	void findPolygon();
	void removeRedundantLoops();
	
};




#endif