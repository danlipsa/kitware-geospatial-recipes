// Reconstruction.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"

#include "modelIO.h"

//#include <windows.h>
//void TcharToChar(const TCHAR * tchar, char * _char)
//{
//	int iLength;
//	iLength = WideCharToMultiByte(CP_ACP, 0, tchar, -1, NULL, 0, NULL, NULL);
//	WideCharToMultiByte(CP_ACP, 0, tchar, -1, _char, iLength, NULL, NULL);
//}
int main(int argc, char* argv[])
//int _tmain(int argc, _TCHAR* argv[])
{
	long charSize = 1024;
//	_TCHAR *dataPath = nullptr;
	char * datapath = new char[charSize];

	if (argc == 2)
	{
		datapath = argv[1];
		//TcharToChar(dataPath, datapath);
		if (NULL == strstr(datapath, ".txt"))
		{
			printf("Error, the input should be las file");
			return 0;
		}
	}
	
	model_IO io_new;
	io_new.readSegmentationResults(datapath);
	io_new.writsModels(datapath);

	return 0;
}

