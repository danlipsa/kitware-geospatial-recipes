#ifndef __LiDAR_POINT_PROCESS_TOPOLOGY_MODEL_IO_CLASS_DEFINE_H__
#define __LiDAR_POINT_PROCESS_TOPOLOGY_MODEL_IO_CLASS_DEFINE_H__

#include "topology.h"
#include "PrimitiveMatch.h"
class model_IO
{
public:
	double offset_x,offset_y,offset_z;
	vector<TP_Model > m_models;
public:

	bool readSegmentationResults(char *inPath);

	void setOffset(double x,double y, double z)
	{
		offset_x = x;offset_y = y ; offset_z = z;
	};
	void writsModels(char* outPath);

};



#endif