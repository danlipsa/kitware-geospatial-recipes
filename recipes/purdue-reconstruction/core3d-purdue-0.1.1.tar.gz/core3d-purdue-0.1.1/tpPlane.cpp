//#include "stdafx.h"
#include "math.h"
#include "tpPlane.h"

TP_PtList *getPartOfLoop(TP_PtList *m_list,int id_start, int id_end)
{
	TP_PtList *m_back=new TP_PtList;
	int i,n_pts=m_list->size();
	id_start = findIDinList(m_list,id_start,0,n_pts);
	id_end = findIDinList(m_list,id_end,0,n_pts);
	assert(id_start!= -1 && id_end != -1 );

	if (id_start <= id_end)
	{
		for (i=id_start;i<id_end;i++)
		{
			m_back->push_back(m_list->data()[(i)]);
		}
	}
	else
	{
		for (i=id_start;i<n_pts ;i++)
		{
			m_back->push_back(m_list->data()[(i)]);
		}
		for (i=0;i<id_end;i++)
		{
			m_back->push_back(m_list->data()[(i)]);
		}
	}
	return m_back;
}

void findPtsWithinLine(TP_PtList *m_input,G_Edge *e_now)
{
	TP_PtList temp;
	CCVector3 *v1=NULL,*v2=NULL;
	v1= &e_now->p1->m_p;v2= &e_now->p2->m_p;
	int id1,id2;
	double dis1,dis2,dismin1=9999,dismin2=9999;
	for (int i=0;i<m_input->size();i++)
	{
	      dis1=calDisP2P_2(v1,&m_input->data()[(i)].m_p);
		  dis2=calDisP2P_2(v2,&m_input->data()[(i)].m_p);
		
		  if (dis1 < dismin1) { dismin1 =dis1;id1=i;}
		  if (dis2 < dismin2) { dismin2 =dis2;id2=i;}		
	}
	for (int i=fmin(id1,id2);i<fmax(id1,id2);i++)temp.push_back(m_input->data()[(i)]);	
	m_input->clear();
	for (int i=0;i<temp.size();i++)m_input->push_back(temp.data()[(i)]);

};
void findEdgeBdBetweenTwoPlanes(TP_Plane *p1,TP_Plane *p2,G_Edge *e_now)//fuhe
{
	ccPointCloud combPoints;
	ccPointCloud  *c_comb = &combPoints;

	long npt_p1 = p1->getPointCloud()->size();
	long npt_comb = p1->getPointCloud()->size() + p1->getPointCloud()->size();
	c_comb->reserve(npt_comb);
	for (long i = 0; i < p1->getPointCloud()->size(); i++)
	{
		c_comb->push_back(p1->getPointCloud()->at(i));
	}
	for (long i = 0; i < p2->getPointCloud()->size(); i++)
	{
		c_comb->push_back(p2->getPointCloud()->at(i));
	}

	TP_PlaneBoundary *bd1=p1->m_boundarys;
	TP_PlaneBoundary *bd2=p2->m_boundarys;

	int n_outbd;
	TP_PlaneBoundary *bdComb=generateEdge(c_comb,1,&n_outbd);

	TP_PlaneBoundary back_bd1;
	TP_PlaneBoundary back_bd2;
	TP_PtList back1,back2;

	int n_e1=bd1->size();
	int n_e2=bd2->size();
	int n_comb=bdComb->size();
	int i,j,k;
	TP_PtList *plist1=NULL,*plist2=NULL,*plistComb=NULL;

	for(i=0;i<n_e1;i++)
	{
		plist1=&(bd1->data()[(i)]->m_pts);
		for(k=0;k<n_comb;k++)
		{
			plistComb=&(bdComb->data()[(k)]->m_pts);
			compareEdgeLists(plistComb,plist1,&back_bd1,i);
		}
		
	}	

	for(i=0;i<n_e2;i++)
	{	
		plist2=&(bd2->data()[(i)]->m_pts);
		for(k=0;k<n_comb;k++)
		{
			plistComb=&(bdComb->data()[(k)]->m_pts);
			compareEdgeLists(plistComb,plist2,&back_bd2,i);
		}
		
	}
	int n_bd1=back_bd1.size();
	int n_bd2=back_bd2.size();
	TP_PtList *m_bdpts=NULL;

	if (e_now->p1 != NULL && e_now->p2 != NULL)
	{
		for(i=0;i<n_bd1;i++)
			findPtsWithinLine(&back_bd1.data()[(i)]->m_pts,e_now);
		for(i=0;i<n_bd2;i++)
			findPtsWithinLine(&back_bd2.data()[(i)]->m_pts,e_now);
	}


	for(i=0;i<n_bd1;i++)
	{
		BoundaryPts *m_bd1=back_bd1.data()[(i)];
		
		for(j=0;j<n_bd2;j++)
		{
			BoundaryPts *m_bd2=back_bd2.data()[(j)];
		
			if (true == getDistanceOfTwoList(&m_bd1->m_pts,&m_bd2->m_pts))
			{	
				if (fmin(m_bd1->m_pts.size() ,m_bd2->m_pts.size())== 0)continue;
							
				TP_Plane_ridgeMessage *mes1=new TP_Plane_ridgeMessage;
				TP_Plane_ridgeMessage *mes2=new TP_Plane_ridgeMessage;
					
				mes1->ridge=mes2->ridge=e_now->ID;
				mes1->m_edge =mes2->m_edge =e_now;
				mes1->n_bd=m_bd1->ID;mes2->n_bd=m_bd2->ID;

				mes1->list_start=m_bd1->m_pts.data()[(0)].ID;mes1->list_end=m_bd1->m_pts.data()[(m_bd1->m_pts.size()-1)].ID;
				mes2->list_start=m_bd2->m_pts.data()[(0)].ID;mes2->list_end=m_bd2->m_pts.data()[(m_bd2->m_pts.size()-1)].ID;
				p1->m_ridgesMessage.push_back(*mes1);
				p2->m_ridgesMessage.push_back(*mes2);
			}
		}	
	}
	c_comb->clear();
}
bool planeInPlane(TP_Plane *p1,TP_Plane *p2)
{
	return (areaInArea(& p1->convex_BD,& p2->convex_BD)> 0.5 /* || areaInArea(plist2,plist1)== true*/)? true : false ;
}
void insertSkelonIntomixBd(Plane_ConnectiveEdgeList *P_CEL,bool _inverse,TP_PtList *m_mixBd)
{

	if (_inverse == false)
	{		
		for (std::list<TP_Vertex *>::iterator itr=P_CEL->get_List_v()->begin();itr != P_CEL->get_List_v()->end();itr++)
		{
			m_mixBd->push_back(**itr);
		}
	}
	else
	{
		for (std::list<TP_Vertex *>::reverse_iterator itr=P_CEL->get_List_v()->rbegin();itr != P_CEL->get_List_v()->rend();itr++)
		{
			m_mixBd->push_back(**itr);
		}
	}
}

void insertPointsBetweenVerters(TP_PtList *m_bd,int id1,int id2,bool _inverse,TP_PtList *m_mixBd)
{
	int i;
	assert( id1 > -1 && id1< m_bd->size() && id2 > -1 && id2< m_bd->size() );
	if (_inverse == false)
	{
		if (id1 <= id2)
			for (i=id1;i<id2;i++)m_mixBd->push_back(m_bd->data()[(i)]);	
		else
		{
			for (i=id1;i<m_bd->size();i++)m_mixBd->push_back(m_bd->data()[(i)]);
			for (i=0;i<id2;i++)m_mixBd->push_back(m_bd->data()[(i)]);
		}
	}
	else
	{
		if (id1 <= id2)
		{
			for (i=id1;i != 0;i--)m_mixBd->push_back(m_bd->data()[(i)]);
			for (i=m_bd->size()-1;i != id2;i--)m_mixBd->push_back(m_bd->data()[(i)]);
		}
			
		else
		for (i=id1;i>id2;i--)m_mixBd->push_back(m_bd->data()[(i)]);	
	}

}

double assertBetwweenPCEAndEdge(TP_PtList *plist,Plane_ConnectiveEdgeList *m_pce)
{
	int nEgs= m_pce->get_List_e()->size();
	
	double dis,disMin = 9999,sigama = 0; 
	CCVector3 p1,p2;
	for (int i=0;i<plist->size();i++)
	{
		disMin = 9999;
		for (std::list<TP_Edge *>::iterator itr=m_pce->get_List_e()->begin();itr != m_pce->get_List_e()->end();itr++)
		{
			p1 = (*itr)->ptBejin->m_p;
			p2 = (*itr)->ptEnd->m_p;
			dis = calDisPt2LineSegment_2d(&plist->data()[(i)].m_p,&p1,&p2);
			if (dis < disMin)disMin = dis;
		}
		sigama += fabs(disMin*disMin);	
	}

	return sigama/plist->size();

}

int caculateRelatationBetwweenPCEAndEdge(TP_PtList *mixBD,Plane_ConnectiveEdgeList *m_pce)
{
	if(mixBD==NULL || mixBD->size()==0)return -1;


	m_pce->l_nbd =m_pce->r_nbd = 0;

	int npt = mixBD->size();

	
	CCVector3 p1 = m_pce->get_List_v()->front()->m_p;
	CCVector3 p2 = m_pce->get_List_v()->back()->m_p;
	double dis1,dis2,dis1Min=9999,dis2Min=9999;
	int id_start,id_end;
	for (int kj=0;kj< npt;kj++)
	{
		dis1=calDisP2P_2(&mixBD->data()[(kj)].m_p,&p1);
		dis2=calDisP2P_2(&mixBD->data()[(kj)].m_p,&p2);
		if (dis1 < dis1Min)    {dis1Min=dis1;    id_start=kj;}
		if (dis2 < dis2Min)    {dis2Min =dis2;   id_end  =kj;}
	}
	m_pce->l_id = id_start;
	m_pce->r_id = id_end;

	if (id_start == id_end)
	{
		m_pce->flag_inverse =false;
		return -1;
	}

	TP_PtList pts_increase, pts_decrease;
	int n1 = (id_end + npt - id_start)%npt - 1;
	int n2 = (id_start + npt - id_end)%npt - 1;

	assert((n1 + n2 +2) == npt);


	for(int i=1;i< n1+1;i++)pts_increase.push_back(mixBD->data()[((id_start+i+npt)%npt)]);

	for(int i=1;i< n2+1;i++)pts_decrease.push_back(mixBD->data()[((id_start-i+npt)%npt)]);

	double in_sigama= assertBetwweenPCEAndEdge(&pts_increase,m_pce);
	double out_sigama= assertBetwweenPCEAndEdge(&pts_decrease,m_pce);

	if (in_sigama < out_sigama)m_pce->flag_inverse =false;
	else m_pce->flag_inverse =true;

	return 1;
}

int caculateRelatationBetwweenLoopsAndEdge(TP_PlaneBoundary *m_boundarys,TP_Edge *edge_now,G_Edge *eg)
{
	bool flag_converse=false;
	TP_PtList *m_bdpts=NULL;
	int n_bd= m_boundarys->size();
	double dis1,dis2,dis1Min=9999,dis2Min=9999;
	double *disBD=new double[n_bd*2];
	int    *idBD =new int   [n_bd*2];
	int nbd_l=0,nbd_r=0,id_start,id_end;
	for (int ki=0;ki< n_bd;ki++)
	{
		m_bdpts=&m_boundarys->data()[(ki)]->m_pts;
		disBD[ki*2]=disBD[ki*2 + 1]=9999;

		for (int kj=0;kj<m_bdpts->size();kj++)
		{
			dis1=calDisP2P_2(&m_bdpts->data()[(kj)].m_p,&eg->p1->m_p);
			dis2=calDisP2P_2(&m_bdpts->data()[(kj)].m_p,&eg->p2->m_p);
			if (dis1 < disBD[ki*2])    {disBD[ki*2] =dis1;    idBD[ki*2]=kj;}
			if (dis2 < disBD[ki*2 + 1]){disBD[ki*2 + 1] =dis2;idBD[ki*2+1]=kj;}
		}

		if (disBD[ki*2] < dis1Min)  {dis1Min=disBD[ki*2];nbd_l=ki;}
		if (disBD[ki*2+1] < dis2Min){dis2Min=disBD[ki*2+1];nbd_r=ki;}
				
	}
	if (nbd_l != nbd_r)		
	{
		if (fmax(disBD[nbd_l*2],disBD[nbd_l*2+1]) < fmax(disBD[nbd_r*2],disBD[nbd_r*2+1])  )
		{
			nbd_r =nbd_l;
		}
		else nbd_l =nbd_r;
	}

	id_start = idBD[nbd_l*2];
	id_end   = idBD[nbd_l*2+1];


	edge_now->n_bd=nbd_l;

	m_bdpts=&m_boundarys->data()[(nbd_l)]->m_pts;
	double *m_data = new double[m_bdpts->size()];

	int i;
	for (i=0;i<m_bdpts->size();i++)
	{
		m_data[i] = calDisPt2LineSegment_2d(&m_bdpts->data()[(i)].m_p,&eg->p1->m_p,&eg->p2->m_p);
	}

	if (id_start > id_end)
	{
		int temp= id_end;id_end  =id_start;id_start=temp;flag_converse = true;
	}

	double in_sigama=0,out_sigama=0;

	for (i=0;i<id_start;i++)out_sigama += fabs(m_data[i]/**m_data[i]*/);
	
	for (i=id_start;i<id_end+1;i++) in_sigama += fabs(m_data[i]/**m_data[i]*/);

	for (i=id_end+1;i<m_bdpts->size();i++)out_sigama += fabs(m_data[i]/**m_data[i]*/);

	
	
	in_sigama= (in_sigama / (id_end-id_start+1))  ;
	out_sigama= (out_sigama / (m_bdpts->size()-(id_end-id_start+1)));

	delete []disBD;
	delete []idBD;
	delete []m_data;

	if (in_sigama  <  out_sigama)
	{
		edge_now->bd_start = id_start;
		edge_now->bd_end   = id_end;
		
	}
	else
	{
		edge_now->bd_start = id_end;
		edge_now->bd_end   = id_start;
		
	}
	if ((!flag_converse  && in_sigama  <  out_sigama)  || (flag_converse  && in_sigama  >  out_sigama))
	{
		return 0;
	}
	else return 1;
	
	
}

void replaceTP_List(TP_PtList *dst,int id_l,int id_r, TP_PtList *InsertPts,Plane_bd_range *_r)
{
	double ser_min=0, ser_max = dst->size();
	if ( _r != NULL)
	{
		ser_min = _r->id_min;
		ser_max = _r->id_max+1;
	}
	int id1= findIDinList(dst,id_l,ser_min,ser_max);
	int id2= findIDinList(dst,id_r,ser_min,ser_max);
	if (id1 == -1 || id2 == -1)return;
	
	int i;
	TP_PtList m_back;
	for(i=0;i< dst->size();i++)m_back.push_back(dst->data()[(i)]);

	dst->clear();

	if (id1 < id2)
	{
		getPartOfPtsFromLoop(&m_back,dst,0,id1);
		for(i=0;i<InsertPts->size();i++)dst->push_back(InsertPts->data()[(i)]);
		getPartOfPtsFromLoop(&m_back,dst,id2,m_back.size());
	}
	else
	{
		for(i=0;i<InsertPts->size();i++)dst->push_back(InsertPts->data()[(i)]);
		getPartOfPtsFromLoop(&m_back,dst,id2,id1);
	}
	m_back.clear();
}


Vector3_lf TP_showObject::computeGravityCenter()
{
	double npt = (double)m_pts->size();
	Vector3_lf cen(0, 0, 0);
	for (long i = 0; i < npt; i++)
	{
		cen.x += m_pts->at(i).x/(npt);
		cen.y += m_pts->at(i).y / (npt);
		cen.z += m_pts->at(i).z / (npt);
	}
	return cen;
}

//steps 1



TP_Plane::TP_Plane()
{
	isBdRegular = false;
	flag_IsInsidePlane=false;
	flag_caculated=false;
	flag_havingCombingBds=false;
	m_boundarys=NULL;
	m_outsideBD = NULL;
	m_oriType = ori_none;
	fatherID = -1;
	show_val = 0;
	alpha_0 = 0;
	ori_id.clear();
	//m_edge = NULL;
	//	mainEdgeID=0;
}

CCVector3 TP_Plane::Point2D_to_3D_ccVector3(const CCVector3 _in)
{
	CCVector3 pt = _in;
	pt.z  = -(pt.x * m_a + pt.y * m_b + m_d)/m_c;
	return pt;
}

void TP_Plane::Point2D_to_3D(TP_Vertex *_in)
{
	CCVector3 *pt = &_in->m_p;
	pt->z  = -(pt->x * m_a + pt->y * m_b + m_d)/m_c;	
}

void TP_Plane::getPlaneParameter()//ax+by+cz+d=0
{	
	ccPointCloud *pPoints=getPointCloud();
	long sum= pPoints->size();
	if (sum == 0)return;
	long k;
	centerPt.x=centerPt.y=centerPt.z=0;
	double z_max= pPoints->at(0).z;
	for (k=0;k<sum;k++)
	{
		const CCVector3 *ptNow= &pPoints->at(k);
		centerPt.x += ptNow->x/(double(sum));
		centerPt.y += ptNow->y/(double(sum));
		centerPt.z += ptNow->z/(double(sum));
		if (z_max < ptNow->z) z_max = ptNow->z;
	}	

	if (isUnRoboustPlane)
	{
		m_a = m_b = 0;
		m_c = 1;
		m_d = -(centerPt.z + 0.8*(z_max - centerPt.z));
		return;
	}
	//
	CCVector3 * pts = new CCVector3[sum];
	for (k=0;k<sum;k++)
	{
		const CCVector3 *ptNow= &pPoints->at(k);
		pts[k] = (*ptNow) - centerPt;
	}

	//直接求解 ax+by+cz+d=0,ATA最小特征值对应的特征向量则为所求参数
	int n=4;
	double *ata = new double[n*n];//法方程系数
	double *atl = new double[n];//常数项
	double *acoe   = new double[n];//每一个观测值的系数数组
	double al;//常数项
	int i;	
	memset(ata,0,n*n*sizeof(double));
	memset(atl,0,n*sizeof(double));

	for(i=0;i<sum;i++)
	{
		memset(acoe,0,n*sizeof(double));
		const CCVector3 *P=&pPoints->at(i);
		acoe[0] = pts[i].x;
		acoe[1] = pts[i].y;
		acoe[2] = pts[i].z;
		acoe[3] = 1;			
		al = 0;
		pNormal(acoe,n,al,ata,atl,1);	
	}
	Eigen::Matrix4d T_mat; T_mat.setZero(n, n);
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
		{
			T_mat(j, i) = ata[i * n + j];
		}

	Eigen::SelfAdjointEigenSolver<Eigen::Matrix4d> eigensolver(T_mat);
	Eigen::Matrix4d eig_N = eigensolver.eigenvectors();
	
	m_a = eig_N(0, 0); m_b = eig_N(1, 0); m_c = eig_N(2, 0); m_d = eig_N(3, 0);

	double mod = sqrt(m_a*m_a + m_b*m_b + m_c*m_c);
	m_a /= mod; m_b /= mod; m_c /= mod; m_d /= mod;
	
	if (m_c < 0)
	{
		m_a *= -1.0;m_b *= -1.0;m_c *= -1.0;m_d *= -1.0;
	}

	m_d = -(m_a * centerPt.x + m_b * centerPt.y+ m_c * centerPt.z);
	double smallAngle = cos(3 * PI / 180.0);
	if (m_c > smallAngle)
	{
		m_c =1; m_a = m_b = 0; 
		m_d = -centerPt.z;
		m_type = H;
	}
	else m_type = S;

	delete[] pts; pts = NULL;
	delete[] ata; ata=NULL;
	delete[] atl; atl=NULL;
	delete[] acoe; acoe=NULL;		
}
bool TP_Plane::getPlaneEdge(double alpha)
{
	if (alpha_0 == 0) alpha_0 = alpha;
	long i,j;int n_outbd;
	m_boundarys=generateEdge(getPointCloud(),alpha,&n_outbd);
	alpha_scale = alpha;
	if (m_boundarys == NULL)return false;
	int bdCount = m_boundarys->size();
	if (bdCount > 1)
	{
	     int out_count = 0;
	     for (i=0;i< bdCount;i++) if (m_boundarys->data()[(i)]->type == OUTSIDE_EDGE)out_count ++;
		 if (out_count > 1)
		 {
			 for (i=0;i< bdCount;i++) delete m_boundarys->data()[(i)];
			 m_boundarys->clear();
			 return getPlaneEdge(2*alpha);
		 }
		 else alpha_scale = alpha;
	}

	for (i=0;i< bdCount;i++)
	{
		BoundaryPts *bds=m_boundarys->data()[(i)];
		if (m_boundarys->data()[(i)]->type == OUTSIDE_EDGE) 
		{
			id_outside = i;
			m_outsideBD = bds;
		}
		TP_PtList *mixBd=&bds->mixBd;
		TP_PtList *the_pts=&bds->m_pts;
		TP_Vertex *tpV=NULL;
		CCVector3 *pt=NULL;
		int n_size=the_pts->size();
		for(j=0;j<n_size;j++)
		{
			pt=&(the_pts->data()[j].m_p);
			pt->z= (-m_d-m_a*pt->x-m_b*pt->y)/m_c;
		}
		for(j=0;j<the_pts->size();j++)
		{
			tpV=&the_pts->data()[j];
			tpV->m_p.z= (-m_d-m_a*tpV->m_p.x-m_b*tpV->m_p.y)/m_c;
			tpV->PlaneID=FacadeCount;
			tpV->id_InComploop = -1;
			tpV->ID=j;			
		}
	}
	return true;
}
bool TP_Plane::checkPlaneQuality()
{
	if (m_boundarys == NULL)
	{
		caculatePlaneMessage(10*aveDis);
	}

	int n_poly = m_boundarys->size();
	if (n_poly ==0 )return false;
	BoundaryPts *bd = NULL;
	m_planeArea = m_planeLen =0;
	for(int i= 0; i< n_poly; i++)
	{
		bd = m_boundarys->at(i);
		if (bd->type == OUTSIDE_EDGE)
		{
			m_planeArea += polygon_area(&bd->m_pts);
	        m_planeLen += polygon_length(&bd->m_pts);
		}
		else
			m_planeArea -= polygon_area(&bd->m_pts);
	}
	if (m_planeArea < 0) m_planeArea =0;	

	m_Planequa = sqrt(m_planeArea)/m_planeLen;
	double pointDis = getPointCloud()->size()/m_planeArea;
	pointDis = 1.0 /sqrt(pointDis);	
	if (m_Planequa <  0.1)return false;
	else return true;
	
}
bool TP_Plane::caculatePlaneMessage(int type)
{
	if (type == 0)getPlaneParameter();
	
	if (m_boundarys != NULL)
	{
		m_boundarys->clear();m_boundarys = NULL;
	}
	if (!convex_BD.empty())
	{
		convex_BD.clear();
	}
	if (getPlaneEdge(10* aveDis))
	{
		GetConvexBB(m_boundarys,&convex_BD);
		flag_caculated=true;
		return true;
	}
	return false;

}
void TP_Plane::insertPCEintoBd(TP_PtList *pts,Plane_ConnectiveEdgeList *_PCE,Plane_bd_range *m_range)
{	
	TP_PtList temp;
	int npts=pts->size(),i;
	int id1=findIDinList(pts,_PCE->l_id,m_range->id_min,m_range->id_max);
    int id2=findIDinList(pts,_PCE->r_id,m_range->id_min,m_range->id_max);
	if (id1 == -1 || id2== -1)return;
	
	for (i=0;i<fmin(id1,id2);i++)temp.push_back(pts->data()[(i)]);

	if (_PCE->flag_inverse == m_range->f_inverse)
	{
		_PCE->getPts(&temp, false);
	}
	else _PCE->getPts(&temp, true);

	for (i= fmax(id1,id2)+1;i<pts->size();i++)temp.push_back(pts->data()[(i)]);
	pts->clear();

	for (i=0;i<temp.size();i++)pts->push_back(temp.data()[(i)]);


}
vector<TP_Plane_ridgeMessage* > * TP_Plane::getP_RM_byEdgeID(int n_e)
{
	vector<TP_Plane_ridgeMessage* > *m_back=new vector<TP_Plane_ridgeMessage* >;
	for (int i=0;i< m_ridgesMessage.size();i++)
	{
		TP_Plane_ridgeMessage *TP_P_RM=&m_ridgesMessage.data()[(i)];
		if (TP_P_RM->ridge == n_e)
		{
			m_back->push_back(TP_P_RM);
		}
	}
	if (m_back->size() == 0)
	{
		delete m_back;m_back=NULL;
	}
	return m_back;
}

void TP_Plane::MixBounduryWithRoofEdges()//
{
	
	connect_Out_PCE();
//	connectMulitiplyOutsideEdges();

	getBdMixedbyRidgeAndBdPts();

	if (m_boundarys->size() == 1  && m_boundarys->front()->mixBd.empty())
	{
		m_boundarys->front()->mixBd = m_boundarys->front()->m_pts;return;
	}

	for (int i=0; i< m_boundarys->front()->mixBd.size();i++)
	{					
		Point2D_to_3D(&m_boundarys->front()->mixBd.data()[(i)]);		
	}

	



}
//steps 1
//1

void TP_Plane::connect_Out_PCE()  
{
	int i,j;
	int n_ge=m_GEdges.size();	

	m_graph_Ed=new Graph;
	vector<int > graph_V_id;

	for (i=0;i<n_ge;i++)
	{
		G_Edge *ge_now=m_GEdges.data()[i];
		if (ge_now->edgeType != NotExist &&  ge_now->edgeType !=  Step)
		{
			m_graph_Ed->insert_Vertex(ge_now);
			graph_V_id.push_back(ge_now->ID);
			m_graph_Ed->getVertexbyID(m_graph_Ed->getVertexCount()-1)->ID=i;//
		}
		
	}
	n_ge=m_graph_Ed->getVertexCount();

	if (n_ge == 0)return;
	int n_loop=m_loopMessage.size();
	int edge1,edge2,id1,id2;
	for(i=0;i<n_loop;i++)
	{
		edge1=m_loopMessage.data()[i].edge1;
		edge2=m_loopMessage.data()[i].edge2;
		id1=searchInVector<int>(graph_V_id,edge1);
		id2=searchInVector<int>(graph_V_id,edge2);
		if (id1 != -1 && id2 != -1)
		{
			m_graph_Ed->insert_Edge(id1,id2);
		}		
	}

	m_graph_Ed->decomposeGraph();

	int n_child=m_graph_Ed->tpGraph_childs->getVertexCount();
	for (i=0;i<n_child;i++)
	{
		Graph *child_i=m_graph_Ed->m_childs->data()[(i)];
		int n_v_ci=child_i->getVertexCount() ;

		TP_EgList *m_input=new TP_EgList;
		for(j=0;j<n_v_ci;j++)
		{
			TP_Edge *edge_now=new TP_Edge;
			int edgeID=child_i->getVertexbyID(j)->fatherID;
		
			edge_now->ID=m_graph_Ed->getVertexbyID(edgeID)->ID;			
			G_Edge *eg=m_GEdges.data()[(edge_now->ID)];
			edge_now->ptBejin=eg->p1;
			edge_now->ptEnd=eg->p2;
			edge_now->edgeID=eg->ID;
			
			vector<TP_Plane_ridgeMessage*> *m_TP_P_RM=getP_RM_byEdgeID(eg->ID);//

			if (m_TP_P_RM == NULL || m_TP_P_RM->empty()) continue;
			
//			if (m_TP_P_RM != NULL && m_TP_P_RM->data()[(0)]->list_start != m_TP_P_RM->data()[(0)]->list_end )
			{
				TP_Plane_ridgeMessage*m_TP_now=m_TP_P_RM->data()[0];
				edge_now->n_bd=m_TP_now->n_bd;										
				edge_now->bd_start = m_TP_now->list_start;
				edge_now->bd_end   = m_TP_now->list_end;
				edge_now->edgeID = m_TP_now->ridge;
				edge_now->translated = m_TP_now->isPlaneID_large;
				m_input->push_back(*edge_now);
			}
			//else //没能找到相关点  则取最近点;				
			//caculateRelatationBetwweenLoopsAndEdge(m_boundarys,edge_now,eg);							
			//edge_now->type=1;
			
			//m_input->push_back(*edge_now);
		}
		if (m_input->size() == 0)return;
		
		Plane_ConnectiveEdgeList *add_pce=new Plane_ConnectiveEdgeList;
		add_pce->Initial_P_CEL(m_input);
		add_pce->m_type = roofRidge;
		out_PCE.push_back(add_pce);

	
	}
}

//steps 1
//2
void TP_Plane::connectMulitiplyOutsideEdges()
{
	if (out_PCE.size() < 2 || m_boundarys->size() == 1)return;
	int n_steps=0;//
	int i,j,bd1_1,bd2_1,bd1_2,bd2_2;
	
	for (i=0;i<out_PCE.size();i++)
	{
		bd1_1=out_PCE.data()[(i)]->l_nbd;
		bd2_1=out_PCE.data()[(i)]->r_nbd;
		if (bd1_1 == bd2_1)continue;
		for (j=i+1;j<out_PCE.size();j++)
		{
			bd1_2=out_PCE.data()[(j)]->l_nbd;
			bd2_2=out_PCE.data()[(j)]->r_nbd;
			if (bd1_2 == bd2_2)continue;
			
			if ((bd1_1 == bd1_2 && bd2_1 == bd2_2) )//首首共环;
			{
				m_boundarys->data()[(bd1_1)]->mixBd.clear();
				m_boundarys->data()[(bd2_1)]->mixBd.clear();
		
				insertSkelonIntomixBd(out_PCE.data()[(i)],true,&m_boundarys->data()[(i)]->mixBd);//反向，左侧 到环bd1_1  true;
				r1.n_bd=bd1_1; r1.id_min= m_boundarys->data()[(i)]->mixBd.size();
				//左左相连  if 为反转脊（true） 从内部到左端点 id增大  到外侧继续增大 搜索无需倒转（false）;
				insertPointsBetweenVerters(&m_boundarys->data()[(bd1_1)]->m_pts,out_PCE.data()[(i)]->l_id,out_PCE.data()[(j)]->l_id,!out_PCE.data()[(i)]->flag_inverse,
					&m_boundarys->data()[(i)]->mixBd);
				r1.id_max=m_boundarys->data()[(i)]->mixBd.size()-1;
				if (r1.id_min > r1.id_max)
				{
					m_boundarys->data()[(bd1_1)]->mixBd.clear();
					m_boundarys->data()[(bd2_1)]->mixBd.clear();
					continue;
				}

				if (m_boundarys->data()[(i)]->mixBd.data()[(r1.id_min)].ID > m_boundarys->data()[(i)]->mixBd.data()[(r1.id_max)].ID ) r1.f_inverse =true;
				else r1.f_inverse =false;

				insertSkelonIntomixBd(out_PCE.data()[(j)],false,&m_boundarys->data()[(i)]->mixBd);//false
				//右右相连 ;
				r2.n_bd=bd2_1; r2.id_min= m_boundarys->data()[(i)]->mixBd.size();
				// if 为反转脊（true） 从左端点到内部 id减小 外侧应该保持一致 （ture） 不变号;
				insertPointsBetweenVerters(&m_boundarys->data()[(bd2_1)]->m_pts,out_PCE.data()[(j)]->r_id,out_PCE.data()[(i)]->r_id,out_PCE.data()[(j)]->flag_inverse,
					&m_boundarys->data()[(i)]->mixBd);
				r2.id_max=m_boundarys->data()[(i)]->mixBd.size()-1;

				
				if (r2.id_min > r2.id_max)
				{
					m_boundarys->data()[(bd1_1)]->mixBd.clear();
					m_boundarys->data()[(bd2_1)]->mixBd.clear();
					continue;
				}
				if (m_boundarys->data()[(i)]->mixBd.data()[(r2.id_min)].ID >m_boundarys->data()[(i)]->mixBd.data()[(r2.id_max)].ID ) r2.f_inverse =true;
				else r2.f_inverse =false;
				out_PCE.data()[(i)]->combinedByAnother = j;
				out_PCE.data()[(j)]->combinedByAnother = i;
				flag_havingCombingBds=true;


			}

			if (bd1_1 == bd2_2 && bd2_1 == bd1_2)//首尾共环;
			{
				m_boundarys->data()[(bd1_1)]->mixBd.clear();
				m_boundarys->data()[(bd2_1)]->mixBd.clear();

				

				insertSkelonIntomixBd(out_PCE.data()[(i)],true,&m_boundarys->data()[(i)]->mixBd);//反向，左侧 到环bd1_1;
				//false
				//左右相连 规则同上;
				r1.n_bd=bd1_1;r1.id_min= m_boundarys->data()[(i)]->mixBd.size();
				insertPointsBetweenVerters(&m_boundarys->data()[(bd1_1)]->m_pts,out_PCE.data()[(i)]->l_id,out_PCE.data()[(j)]->r_id,!out_PCE.data()[(i)]->flag_inverse,
					&m_boundarys->data()[(i)]->mixBd);
				  r1.id_max=m_boundarys->data()[(i)]->mixBd.size()-1;				  
				  if (r1.id_min > r1.id_max)
				  {
					  m_boundarys->data()[(i)]->mixBd.clear();
					  m_boundarys->data()[(j)]->mixBd.clear();
					  continue;
				  }
				  if (m_boundarys->data()[(i)]->mixBd.data()[(r1.id_min)].ID > m_boundarys->data()[(i)]->mixBd.data()[(r1.id_max)].ID ) r1.f_inverse =true;
				  else r1.f_inverse =false;
				insertSkelonIntomixBd(out_PCE.data()[(j)],true,&m_boundarys->data()[(i)]->mixBd);//false
				//左右相连 ;
				r2.n_bd=bd2_1;r2.id_min= m_boundarys->data()[(i)]->mixBd.size();
				//从屋脊2的左端出去  若2为反转脊（true）出端增大  外一致则增大;
				insertPointsBetweenVerters(&m_boundarys->data()[(bd2_1)]->m_pts,out_PCE.data()[(j)]->l_id,out_PCE.data()[(i)]->r_id,!out_PCE.data()[(j)]->flag_inverse,
					&m_boundarys->data()[(i)]->mixBd);
				  r2.id_max=m_boundarys->data()[(i)]->mixBd.size()-1;
				  
				  if (r2.id_min > r2.id_max)
				  {
					  m_boundarys->data()[(i)]->mixBd.clear();
					  m_boundarys->data()[(j)]->mixBd.clear();
					  continue;
				  }
				  if (m_boundarys->data()[(i)]->mixBd.data()[(r2.id_min)].ID > m_boundarys->data()[(i)]->mixBd.data()[(r2.id_max)].ID ) r2.f_inverse =true;
				  else r2.f_inverse =false;
				  out_PCE.data()[(i)]->combinedByAnother = j;
				  out_PCE.data()[(j)]->combinedByAnother = i;
				  flag_havingCombingBds=true;

			}

			if (flag_havingCombingBds==true)
			{
				for (int k=0;k<out_PCE.size();k++)
				{
					if (out_PCE.data()[(k)]->l_nbd != out_PCE.data()[(k)]->r_nbd )continue;
					
					if (out_PCE.data()[(k)]->l_nbd == r1.n_bd && out_PCE.data()[(k)]->combinedByAnother == -1 )
					{
						insertPCEintoBd(&m_boundarys->data()[out_PCE.data()[(k)]->l_nbd]->mixBd,out_PCE.data()[(k)],&r1);
					}
					if (out_PCE.data()[(k)]->l_nbd == r2.n_bd && out_PCE.data()[(k)]->combinedByAnother == -1)
					{
						insertPCEintoBd(&m_boundarys->data()[out_PCE.data()[(k)]->l_nbd]->mixBd,out_PCE.data()[(k)],&r2);
					}
				}
			}
			
			


		}
	}
	if (n_steps<2)return;
	

}



//steps 1 3
void TP_Plane::getBdMixedbyRidgeAndBdPts()
{	
	int n_bd=m_boundarys->size();
	int n_pce=out_PCE.size();
//	HE_edge *egBefore=NULL;

	int i,j,i_bd;

	int *flag_bd=new int[n_bd];
	for (i=0;i<n_bd;i++)flag_bd[i]=0;
	

	if (flag_havingCombingBds == true)
	{
		flag_bd[r1.n_bd]=1;flag_bd[r2.n_bd]=1;
	}
	
	vector<CmpType<int > > CmpData;
	TP_PtList *bdPts=NULL,*bdmixBd=NULL;	

	int bdPt_count;
	for (i_bd=0;i_bd<n_bd;i_bd++)
	{
		bdPt_count=0;
		if (flag_bd[i_bd]== 1)continue;
		if (m_boundarys->data()[(i_bd)]->type != OUTSIDE_EDGE)continue;

		bdPts=&m_boundarys->data()[(i_bd)]->m_pts;
		int n_bdPts= bdPts->size();
		bdmixBd=&m_boundarys->data()[(i_bd)]->mixBd;
		bdmixBd->clear();
		CmpData.clear();
		for (i=0;i< n_pce;i++)
		{
			//if (out_PCE.data()[(i)]->l_nbd == i_bd)
			{
				//if (out_PCE.data()[(i)].flag_inverse == false)
				{
					CmpType<int > CT_num(out_PCE.data()[(i)]->l_id,i);
					CmpData.push_back(CT_num); 
				}
				/*			else
				{
				CmpType<int > CT_num(out_PCE.data()[(i)].r_id,i);
				CmpData.push_back(CT_num);
				}*/
			}
	
		}
		if (CmpData.size() == 0)continue;

		qsort(&CmpData.data()[(0)],CmpData.size(),sizeof(CmpType<int >),cmp2<int>); 	

		int IDstart,IDend,IDbefore=0;
		int ridgeID,ridge_inModel;
		CCVector3 v1,v2;TP_Vertex *v_before=NULL;
		bool flag_v3=false;
		Plane_ConnectiveEdgeList *plist=NULL,*pl_st = NULL;
		int n_onePtEdge= 0; 
		bool bef_crossLoopEnd =false;
		
		for (i=0;i<CmpData.size();i++)
		{
			if (bef_crossLoopEnd)break;
			ridgeID=CmpData.data()[(i)].id;
			plist=out_PCE.data()[(ridgeID)];
			plist->deleteSingleShortPCE();
			if (plist->isPCECanceled)continue;
		     
			if (pl_st == NULL)pl_st=out_PCE.data()[(ridgeID)];
		
			IDstart=plist->l_id;IDend  =plist->r_id;
			if (IDstart == IDend)n_onePtEdge ++;
			if (IDstart > bdPts->size()-1 || IDend > bdPts->size()-1)continue;
			if (IDstart < 0 || IDend <0)continue;
			/*if (plist->flag_inverse == false)
			{IDstart=plist->l_id;IDend  =plist->r_id;}
			else{IDstart=plist->r_id;IDend  =plist->l_id;}*/

			if (!bef_crossLoopEnd &&IDstart < IDbefore && IDend < IDbefore)continue;//
			
			isBdRegular = true;
			if (v_before != NULL  && IDbefore < IDstart)
			{					
				v1 =bdmixBd->back().m_p;
				v2 =bdmixBd->data()[(bdmixBd->size()-2)].m_p;
				for (j=IDbefore+1;j<IDstart;j++)
				{		
					if (calDisPt2LineSegment_2d(&bdPts->data()[j].m_p,&v1,&v2) > 0.5)
					{
						bdmixBd->push_back(bdPts->data()[(j)]);
						bdPt_count++;
					}									
				}
			}
			int n_list_pt = plist->get_List_v()->size();
	
			if (n_list_pt == 0)
				{ 
					continue; 
				}
			
			//if (n_list_pt == 0)continue;
		
			
			if (plist->m_type != roofRidge)
			{	
				plist->getPts(bdmixBd,plist->flag_inverse);
				
				bdmixBd->data()[bdmixBd->size()- n_list_pt].id_ifisModelCorner = bdPts->at(IDstart).id_ifisModelCorner;
				bdmixBd->data()[bdmixBd->size()-1].id_ifisModelCorner = bdPts->at(IDend).id_ifisModelCorner;
			}
			else
			{
				//一个点被加了两次？是否需要对外点的内容做修改？待调试。。
				if (bdPts->at(IDstart).id_ifisModelCorner != -1){bdmixBd->push_back(bdPts->at(IDstart));}
				plist->getPts(bdmixBd,plist->flag_inverse);
				if (bdPts->at(IDend).id_ifisModelCorner != -1){bdmixBd->push_back(bdPts->at(IDend));}
			}
			/*	int n_newAdd =  plist->get_List_v()->size();
			for (int i_pce =0;i_pce< n_newAdd-1;i_pce++ )
			{
			HE_edge *eg_new = new HE_edge;
			eg_new->m_type = plist->m_type;			
			HE_vert *stPt =new HE_vert;
			stPt->pt = bdmixBd->data()[bdmixBd->size()- n_newAdd + i].m_p;
			stPt->edge = eg_new;
			eg_new->vert = stPt;				
			if (m_edge == NULL)m_edge = eg_new;		
			else egBefore->next = eg_new;
			egBefore = eg_new;
			}*/
            bdPt_count += n_list_pt;	
			if (IDstart > IDend)bef_crossLoopEnd = true;
			else bef_crossLoopEnd = false;
			IDbefore = IDend; v_before = plist->get_List_v()->back();		
		}
	
		int rest1=IDbefore,rest2;
		//plist=out_PCE.data()[(CmpData.data()[(0)].id)];
		if (pl_st == NULL)continue;	rest2=pl_st->l_id;
		if (rest1 == -1 || rest2 == -1)continue;
		
		if (!((rest2 -rest1) == 1 || (rest1 == (n_bdPts -1) && rest2 ==0)))
		{
			if (bdmixBd->empty())continue;
			v1 =bdmixBd->back().m_p;
			v2 =bdmixBd->data()[(bdmixBd->size()-2)].m_p;
			TP_PtList *restpts=getPartOfLoop(bdPts,rest1,rest2);
			int n_add = restpts->size();
			if (n_add  <=  (n_bdPts - bdPt_count+n_onePtEdge))
			{			
				for (j=0;j<restpts->size();j++)
				{
					if (calDisPt2LineSegment_2d(&restpts->data()[(j)].m_p,&v1,&v2) > 0.5)
						bdmixBd->push_back(restpts->data()[(j)]);
				}
			}
		}

		for (i=0;i< bdmixBd->size(); i++)
		{
			bdmixBd->data()[(i)].id_inMixBd =i;
		}
	}
	delete []flag_bd;
//	egBefore->next = m_edge;


}

//steps 2

/*
void TP_Plane::MixBounduryWithModelBd(bdAdjustment *modelBD)
{
	adjustBdByReplaceBoundurys(modelBD);

	for(int i_bd=0;i_bd < m_boundarys->size();i_bd++)
	{
	//	removeRedundantPtsBetweenExtensidedRidgeAndModelBD(&m_boundarys->data()[(i_bd)]->mixBd,modelBD);

		for (int i=0;i< m_boundarys->data()[(i_bd)]->mixBd.size() ;i++)
		{
			m_boundarys->data()[(i_bd)]->mixBd.data()[(i)].id_inMixBd = i;
		}
		 

	//	modelBD->upLoadUnfinishedParts(&m_boundarys->data()[(i_bd)]->mixBd,ID_childModle,m_GEdges.size());
		
		for (int i=0;i< m_boundarys->data()[(i_bd)]->mixBd.size() ;i++)
		{
			Point2D_to_3D(&m_boundarys->data()[(i_bd)]->mixBd.data()[(i)]);
			
		}
		//ConnectFacadeOutsiderBD(&m_boundarys->data()[(i_bd)]->mixBd,modelBD);
	}
}



void TP_Plane::adjustBdByReplaceBoundurys(bdAdjustment *modelBD)
{
	
	TP_PtList *bd=NULL;
	int i_bd;
	if (!flag_havingCombingBds)
	{
		for(i_bd=0;i_bd < m_boundarys->size();i_bd++)
		{
			bd=&m_boundarys->data()[(i_bd)]->mixBd;
			for (int i=0;i < bd->size();i++){
				if (bd->data()[(i)].ID > -1)
					bd->data()[(i)].id_InComploop =  m_boundarys->data()[(i_bd)]->m_pts.data()[(bd->data()[(i)].ID)].id_InComploop;		
			}
			ReplaceModelBDintoMixBD(bd,modelBD);
		}
	}											
	else
		{
			int n_bd=m_boundarys->size();
			int *flag_bd=new int[n_bd];
			for (int i=0;i<n_bd;i++)flag_bd[i]=0;
			if (flag_havingCombingBds == true)
			{
				flag_bd[r1.n_bd]=1;flag_bd[r2.n_bd]=1;
			}

			for (i_bd=0;i_bd<n_bd;i_bd++)
			{			
				if (flag_bd[i_bd]== 1)continue;	

				bd=&m_boundarys->data()[(i_bd)]->mixBd;
				for (int i=0;i < bd->size();i++){
					if (bd->data()[(i)].ID != -1)
						bd->data()[(i)].id_InComploop =  m_boundarys->data()[(i_bd)]->m_pts.data()[(bd->data()[(i)].ID)].id_InComploop;		
				}
				ReplaceModelBDintoMixBD(bd,modelBD);
			}

			
			if (m_boundarys->data()[(r1.n_bd)]->mixBd.size() != 0)
			{
				bd = &m_boundarys->data()[(r1.n_bd)]->mixBd;
			}
			else bd = &m_boundarys->data()[(r2.n_bd)]->mixBd;

			for (int i=r1.id_min;i < r1.id_max+1;i++){
				if (bd->data()[(i)].ID != -1)
					bd->data()[(i)].id_InComploop =  m_boundarys->data()[(r1.n_bd)]->m_pts.data()[(bd->data()[(i)].ID)].id_InComploop;		
			}
			for (int i=r2.id_min;i < r2.id_max+1;i++){
				if (bd->data()[(i)].ID != -1)
					bd->data()[(i)].id_InComploop =  m_boundarys->data()[(r2.n_bd)]->m_pts.data()[(bd->data()[(i)].ID)].id_InComploop;		
			}

			int n_delete = bd->size();

			ReplaceModelBDintoMixBD(bd,modelBD,&r1);

			n_delete -= bd->size();
			Plane_bd_range _r2;
			_r2.n_bd = r2.n_bd;
			_r2.id_min = r2.id_min - n_delete;
			_r2.id_max = r2.id_max - n_delete;
		    ReplaceModelBDintoMixBD(bd,modelBD,&_r2);
		  
		}

}

























void TP_Plane::ReplaceModelBDintoMixBD(TP_PtList *m_mixBD, bdAdjustment *modelDB,Plane_bd_range *_r)
{
	double ser_min=0, ser_max = m_mixBD->size();
	if ( _r != NULL)
	{
		ser_min = _r->id_min;
		ser_max = _r->id_max+1;
	}
	int i,n_pt= m_mixBD->size();
	int *f_bd=new int[n_pt]; memset(f_bd,0, sizeof(int)*n_pt);
	TP_Vertex *pt=NULL;
	for (i= ser_min;i< ser_max;i++){	
		pt=&m_mixBD->data()[(i)];
		if (!(pt->id_InComploop == -1 || modelDB->getRidgesbyBdID(pt->id_InComploop) == NULL))f_bd[i]=1;		
	}

	vector<CCVector2i > list_bd;//可能有多块在边界上
	fitContinuePartsInLoop(f_bd,n_pt,&list_bd);

	if (list_bd.size() == 0 )return;
	

	TP_PtList newBd;
	for(i=0;i< n_pt;i++)newBd.push_back(m_mixBD->data()[(i)]);

	int id_l,id_r,id1,id2;
	for (i=0;i<list_bd.size();i++)
	{
		id_l = list_bd.data()[(i)].x;
		id_r = list_bd.data()[(i)].y;
		if (id_l == id_r)continue;

		TP_PtList bdPts;

        int id1= m_mixBD->data()[(id_l)].id_InComploop;
		int id2= m_mixBD->data()[(id_r)].id_InComploop;

		if ((id2+ modelDB->n_pts - id1)%modelDB->n_pts  == (id_r +n_pt-id_l)%n_pt )
			      modelDB->getVerterxByIDRange(id1,id2,&bdPts,0);
		else modelDB->getVerterxByIDRange(id2,id1,&bdPts,1);
	
		

		

		
		for (int j=0;j<bdPts.size();j++)
		{
			Point2D_to_3D(&bdPts.data()[(j)]); 
			bdPts.data()[(j)].ID= -2;	
			//bdPts.data()[(j).PtType = InterSect_Vertical_Outside;
			bdPts.data()[(j)].id_InComploop= -1;
		}
		bdPts.front().ID= -3;//标注一段屋脊线的内外;
		bdPts.back().ID= -3;
		bdPts.front().PtType = Ordinary_Outside;
		bdPts.back().PtType = Ordinary_Outside;
		bdPts.front().PtStab = OriginCorner;
		bdPts.back().PtStab = OriginCorner;
		
		bdPts.front().dis_to_edge = modelDB->getRidgesbyBdID(m_mixBD->data()[(id_l)].id_InComploop)->ID;
		bdPts.back().dis_to_edge = modelDB->getRidgesbyBdID(m_mixBD->data()[(id_r)].id_InComploop)->ID;

	    //用生成的点代替原来点;
		replaceTP_List(&newBd,m_mixBD->data()[(id_l)].ID,m_mixBD->data()[(id_r)].ID,&bdPts,_r);	

		bdPts.clear();
	}
	m_mixBD->clear();

	for(i=0;i< newBd.size();i++)m_mixBD->push_back(newBd.data()[(i)]);	

}



void TP_Plane::removeRedundantPtsBetweenExtensidedRidgeAndModelBD(TP_PtList *m_bd,bdAdjustment *modelBD)
{
	if ( m_bd == NULL || m_bd->size() == 0)return;
	int n_pt= m_bd->size();
	
	IDList up,down;

	int count=0, id,i,j;
	TP_Vertex *pt=NULL;
	for (i=0;i<n_pt;i++)
	{
		 pt= &m_bd->data()[(i)];
		if (pt->ID != -1  ||  pt->PtStab != Extensible )continue;
		
		if (count == 0 && pt->onBD == true )up.push_back(i);
		if (count == 1 && pt->onBD == true )down.push_back(i);

		count = (count+1)%2 ;
	}

	
	for (i=0;i<m_bd->size();i++)m_bd->data()[(i)].delete_flag = false;
	
	if (up.size() > 0)
	{
		for( i=0;i< up.size();i++)
		{
			m_bd->data()[(up.data()[(i)])].PtType = Extensided_onBD;
			for (j=1;j<4;j++)
			{
				id= (up.data()[(i)]- j + n_pt)%n_pt;
				pt = &m_bd->data()[(id)];
				if (pt->ID == -3)
				{
					for (int k_delete=(id+1)%n_pt; (k_delete%n_pt) != up.data()[(i)] ;k_delete++){
						m_bd->data()[(k_delete%n_pt)].delete_flag = true;
					}										
					break;
				}
				if (pt->ID == -1)break;
				
			}
		}
    }
	if (down.size() > 0)
	{
		for( i=0;i< down.size();i++)
		{
			m_bd->data()[(down.data()[(i)])].PtType = Extensided_onBD;
			for (j=1;j<4;j++)
			{
				id= (down.data()[(i)]+ j)%n_pt;
				pt = &m_bd->data()[(id)];
				if (pt->ID == -3)
				{
					for (int k_delete=(down.data()[(i)]+1)%n_pt; (k_delete%n_pt) != (id)%n_pt ;k_delete++){
						m_bd->data()[(k_delete%n_pt)].delete_flag = true;
					}					
					break;
				}
				if (pt->ID == -1)break;
			}
		}

	}
	
	refreshTP_ListByDeleteFlag(m_bd);

	deleteRepickPtsInLoops(m_bd);


}

void TP_Plane::ConnectFacadeOutsiderBD(TP_PtList *m_bd,bdAdjustment *modelBD)
{
	if ( m_bd == NULL || m_bd->size() == 0)return;
	int n_pt= m_bd->size();

	int *m_flags = new int[n_pt];memset(m_flags,0,sizeof(int)*n_pt);
	for (int i=0;i<n_pt;i++)
	{
		if (m_bd->data()[(i)].ID > 0  )m_flags[i] = 1;
	}

	vector<CCVector2i>  segs;
	fitContinuePartsInLoop(m_flags,n_pt,&segs);

	if (segs.size() == 0 )return;	

	int st_id,end_id,count=0;
	for(int i=0; i< segs.size();i++)
	{
		st_id  = segs.data()[(i)].x;
		end_id = segs.data()[(i)].y;
		for (int j=0;j< ((end_id-st_id+1+ n_pt)%n_pt) ;j++)
		{
			if (m_bd->data()[(st_id+j)].id_InComploop != -1)count++;			 
		}
	}

	if (count > 3 || count > ((end_id-st_id+1+ n_pt)%n_pt)/2 )
	{


	}


}




//old
void TP_Plane::fitModelBdsFromMixBd(bdAdjustment *modelBD)
{
	int n_bd=m_boundarys->size();
	TP_PtList *bd=NULL;
	for(int i_bd=0;i_bd<n_bd;i_bd++)
	{
		bd=&m_boundarys->data()[(i_bd)]->mixBd;
		int npt=bd->size();
		
		int i=0,id,i_st= -1,i_end= -1;

		for (int i=0;i<npt;i++)bd->data()[(i)].delete_flag =false;


		for (int i=0;i<npt;i++)
		{
			id=bd->data()[(i)].id_InComploop;
			
			if (id == -1 || modelBD->getRidgesbyBdID(id) == NULL)continue;	

			if (i_st == -1){i_st = i; continue;}
			i_end = i;	

			int id_next=bd->data()[((i+1)%npt)].id_InComploop;

			if (id_next == -1 || modelBD->getRidgesbyBdID(id_next) == NULL)
			{
				Plane_bd_range eg_add;
				eg_add.id_min=i_st;//bd->data()[(i_st).id_InComploop;
				eg_add.id_max=i_end;//bd->data()[(i_end).id_InComploop;
				eg_add.n_bd=i_bd;
				eg_add.f_inverse=false;
				if ((i_end+npt-i_st) % npt > 2)
				{
					bd_onModelEdge.push_back(eg_add);
					int n_existingCorners= cornersInModelBd.size();
					int count_n=modelBD->getVerterxByIDRange(bd->data()[(i_st)].id_InComploop,bd->data()[(i_end)].id_InComploop,&cornersInModelBd);
					if (count_n >= 2)
					{			
     					TP_Plane_ExtensiblePts *expt_st=new TP_Plane_ExtensiblePts(i_bd,i_st,-1,true,&cornersInModelBd.data()[(n_existingCorners)],&cornersInModelBd.data()[(n_existingCorners+1)]);
						TP_Plane_ExtensiblePts *expt_end=new TP_Plane_ExtensiblePts(i_bd,i_end,-1,false,&cornersInModelBd.data()[(cornersInModelBd.size()-2)],&cornersInModelBd.back());
						extPts.push_back(*expt_st);extPts.push_back(*expt_end);
					}
				}	

				for (int j=1;j<(i_end+npt-i_st)%npt ;j++)bd->data()[(i_st+j)].delete_flag =true;
				i_st = i_end = -1;
			}
		}

	}
}



void TP_Plane::connect_extensibleEdges(bdAdjustment *modelBD)
{
	int i,n_endPts= extPts.size();

	//modelBD->axis_x modelBD->axis_y
	double nx,ny,cos_sita;
	for (i=0;i< n_endPts;i++)//比较与主方向的关系
	{
		nx= extPts.data()[(i)].end_pt.m_p.x- extPts.data()[(i)].inside_pt.m_p.x;
		ny= extPts.data()[(i)].end_pt.m_p.y- extPts.data()[(i)].inside_pt.m_p.y;

		cos_sita = fabs(nx * modelBD->axis_x + ny * modelBD->axis_y)/
			sqrt((nx *nx+ ny *ny)*(modelBD->axis_x* modelBD->axis_x+ modelBD->axis_y* modelBD->axis_y));

		if (acos(cos_sita)*180/PI < 5 )extPts.data()[(i)].type = 1;
		else if (acos(cos_sita)*180/PI > 85 )extPts.data()[(i)].type = 2;
		else extPts.data()[(i)].type =0;

	}

	vector<CmpType<int > > CmpData;
	for ( i=0;i< n_endPts;i++)
	{	
		CmpType<int > CT_num(extPts.data()[(i)].IDinBd,i);
		CmpData.push_back(CT_num);		
	}
	if (CmpData.size() > 3)
	{
		qsort(&CmpData.front(),CmpData.size(),sizeof(CmpType<int >),cmp2<int>);
		int *flag_ex=new int[n_endPts];memset(flag_ex,0,sizeof(int)*n_endPts);
		int *flag_change=new int[n_endPts];memset(flag_change,0,sizeof(int)*n_endPts);
		TP_Plane_ExtensiblePts *tpe_now,*tpe_connect;
	
		for (i=0;i<n_endPts;i++)
		{
			if (flag_ex[i] != 0 || extPts.data()[(i)].flag_orientation == true)continue;
		
			tpe_now=&extPts.data()[(CmpData.data()[(i)].id)];
			tpe_connect=&extPts.data()[(CmpData.data()[((i+1)%n_endPts)].id)];
		
			if (tpe_connect->flag_orientation != true)continue;
		
//			if (1 == modelBD->interSectTwoExtensivePts(tpe_now,tpe_connect,&m_boundarys->data()[(tpe_now->n_bd)->mixBd))flag_change[i] =1;
		

		}

		for (i=0;i<n_endPts;i++)
		{
			if (flag_change[i] ==1 )
			{
				TP_Vertex * pt_now = &extPts.data()[(CmpData.data()[(i)].id)].end_pt;
				TP_Vertex * pt_nex = &extPts.data()[(CmpData.data()[((i+1)%n_endPts)].id)].end_pt;
				int ID_bd = extPts.data()[(CmpData.data()[(i)].id)].IDinBd;
				int ID_bd_nex = extPts.data()[(CmpData.data()[((i+1)%n_endPts)].id)].IDinBd;
				TP_Vertex *pt_inBD=  &m_boundarys->data()[(extPts.data()[(i)].n_bd)]->mixBd.data()[(ID_bd)];
				TP_Vertex *pt_inBDNex=  &m_boundarys->data()[(extPts.data()[(i)].n_bd)]->mixBd.data()[(ID_bd_nex)];
				//if ((int)pt_inBD->flag <= (int)Extensible)
				{
					pt_inBD->m_p.x =  pt_now->m_p.x;
					pt_inBD->m_p.y =  pt_now->m_p.y;
					pt_inBD->m_p.z = -(m_a * pt_now->m_p.x+ m_b * pt_now->m_p.y + m_d)/m_c;
					//updateEdgeEndPoint(extPts.data()[(CmpData.data()[(i).id).belonged_edge,&pt_inBD->m_p);
				}
				//if ((int)pt_inBDNex->flag <= (int)Extensible)
				{
					pt_inBDNex->m_p.x=pt_nex->m_p.x;
					pt_inBDNex->m_p.y=pt_nex->m_p.y;
					pt_inBDNex->m_p.z = -(m_a * pt_nex->m_p.x+ m_b * pt_nex->m_p.y + m_d)/m_c;
					//updateEdgeEndPoint(extPts.data()[(CmpData.data()[((i+1)%n_endPts).id).belonged_edge,&pt_inBDNex->m_p);
				}
			  					
				tpe_now=&extPts.data()[(CmpData.data()[(i)].id)];
				tpe_connect=&extPts.data()[(CmpData.data()[((i+1)%n_endPts)].id)];
				int n_mixBDPts=m_boundarys->data()[(extPts.data()[(i)].n_bd)]->mixBd.size();
				for (int j=1;j< ((tpe_connect->IDinBd + n_mixBDPts - tpe_now->IDinBd)% n_mixBDPts);j++)
				{					
					m_boundarys->data()[(extPts.data()[(i)].n_bd)]->mixBd.data()[((tpe_now->IDinBd+j)% n_mixBDPts)].delete_flag = true;
				}		
			}

		}
		delete []flag_change;
		delete []flag_ex;
	}
	for (int i_bd=0;i_bd< m_boundarys->size();i_bd++)
	{
		TP_PtList *plist= &m_boundarys->data()[(i_bd)]->mixBd;
		TP_PtList temp;
		for (int j=0; j< plist->size();j++)
		{
			if (plist->data()[(j)].delete_flag == false)temp.push_back(plist->data()[(j)]);				
		}
        *plist = temp;

		//for (int j=0; j< plist->size();j++)plist->data()[(j).m_p.z = -(m_a * plist->data()[(j).m_p.x+ m_b * plist->data()[(j).m_p.y + m_d)/m_c;
		for (int j=0; j< plist->size();j++)
		{
			if (plist->data()[(j)].id_InComploop != -1)
			{
				TP_Vertex *v1=&plist->data()[(j)];
				TP_Vertex *v2=&plist->data()[((j+1)%plist->size())];
			}
		}
	}
	

}
*/
bool TP_Plane::updateEdgeEndPoint(int eg_id,CCVector3 *m_position)
{
	int n_egs=m_GEdges.size();
	G_Edge *eg=NULL;
	TP_Vertex *end1,*end2;
	double dis1,dis2;
	for (int i=0;i<n_egs;i++)
	{
		eg=m_GEdges.data()[(i)];
		if (eg->ID != eg_id)continue;		
		end1 =eg->p1;
		end2 = eg->p2;		
		dis1 = calDisP2P_xy_sqrt(&end1->m_p,m_position);
		dis2 = calDisP2P_xy_sqrt(&end2->m_p,m_position);

		if (dis1 < dis2 && dis1 < 1 && end1->PtStab != Stable)
		{
			end1->m_p.x=m_position->x;
			end1->m_p.y=m_position->y;
			end1->m_p.z=m_position->z;
			end1->PtStab = Extensided;
			return true;
		}
		if (dis2 < dis1  && dis2 < 1 &&end2->PtStab != Stable )
		{
			end2->m_p.x=m_position->x;
			end2->m_p.y=m_position->y;
			end2->m_p.z=m_position->z;
			end2->PtStab = Extensided;
			return true;
		}
	}
	return false;
}
//
/*
void TP_Plane::caculateSingleInsidePlane(bdAdjustment *modelBD,TP_Plane *FatherPlane)
{
	if(m_GEdges.size() != 1  ||  m_boundarys->size()!= 1 )return;
	G_Edge * m_eg = m_GEdges.front();
	TP_PtList *bdPts = &m_boundarys->front()->m_pts;
	TP_Edge *edge_now=new TP_Edge;
	edge_now->ptBejin=m_eg->p1;
	edge_now->ptEnd=m_eg->p2;
	caculateRelatationBetwweenLoopsAndEdge(m_boundarys,edge_now,m_eg);
	TP_PtList mixbd;
	mixbd.push_back(edge_now->ptBejin);
	mixbd.push_back(edge_now->ptEnd);
	getPartOfPtsFromLoop(bdPts,&mixbd,edge_now->bd_end,edge_now->bd_start);	
	modelBD->caculateSingleInsidePlane(&mixbd);
	m_boundarys->front()->mixBd = mixbd;
	for (int i=0;i< m_boundarys->front()->mixBd.size() ;i++)
	{
		Point2D_to_3D(&m_boundarys->front()->mixBd.data()[(i)]);
	}


}	
*/
bool TP_Plane::getCornerEdgeSegment_Describer(int ID,CornerEdgeSegment_Describer *CES_D)
{
	if (m_outsideBD->mixBd.empty())return false;
	TP_PtList * mixbd;
	mixbd = &m_outsideBD->mixBd;
    int npt = mixbd->size(),cor_ID= -1;
	for(int i = 0; i < npt ;i++)mixbd->data()[i].id_inMixBd = i;

	CES_D->ID = ID;
	for(int i = 0; i < npt ;i++)
	{
		if (mixbd->at(i).id_ifisModelCorner != ID)continue;
		else {cor_ID = i ; break;}
	}
	if (cor_ID == -1)return false;
	CES_D->corID = cor_ID;

	bool isUpPtOut=true, rgDecided= false,outDecided = false;//点链增加方向在外部;
	int id_rg= -1,id_out= -1;
	//先找到屋脊线的外端点;
	const TP_Vertex *pt1,*pt2;
	int outCount1 =0,outCount2 =0; if (mixbd->at(cor_ID).PtType == Extensible_OutsideStepBD_Ends|| mixbd->at(cor_ID).PtType ==  Extensible_InsideStepBD_Ends){outCount1=outCount2=1;}
	for (int i = 1;i< npt; i++)//找到第二个外点或者第一个屋脊端点即可;
	{
		pt1 = &mixbd->at((cor_ID+i)%npt);pt2 = &mixbd->at((cor_ID+npt -i)%npt);

		if (pt1->PtType ==  Extensible_OutsideStepBD_Ends|| pt1->PtType ==  Extensible_InsideStepBD_Ends|| pt1->PtType ==InterSect_Vertical_Outside_BD)outCount1 ++;
		if (pt1->PtType ==  InterSect_Vertical_Outside_BD || outCount1 == 2) {isUpPtOut = true;  id_out =  (cor_ID+i)%npt; outDecided = true; break;}
		if (pt1->PtType == Extensible_Roof_Ends){isUpPtOut = false; id_rg =  (cor_ID+i)%npt; rgDecided = true; break;}


		if (pt2->PtType ==  Extensible_OutsideStepBD_Ends|| pt2->PtType ==  Extensible_InsideStepBD_Ends|| pt2->PtType ==InterSect_Vertical_Outside_BD)outCount2 ++;
		if (pt2->PtType ==  InterSect_Vertical_Outside_BD|| outCount2 == 2) {isUpPtOut = false;  id_out =  (cor_ID+npt -i)%npt; outDecided = true;break;}
		if (pt2->PtType ==  Extensible_Roof_Ends){isUpPtOut = true; id_rg =  (cor_ID+npt -i)%npt; rgDecided = true;break;}
	}

	

	int bias = -1;if (isUpPtOut) bias = 1;	
	
	if (!rgDecided)
	{
		for (int i = 1;i< npt; i++)
		{
			pt1 = &mixbd->at((cor_ID+npt-i*bias)%npt);
			if (pt1->PtType== Extensible_Roof_Ends)
			{
				id_rg =(cor_ID+npt-i*bias)%npt;
				break;
			}
		}
	}
	outCount1=0; if (mixbd->at(cor_ID).PtType == Extensible_OutsideStepBD_Ends|| mixbd->at(cor_ID).PtType ==  Extensible_InsideStepBD_Ends){outCount1=1;}
	
	if (! outDecided )
	{
//		id_out= -1;
		for (int i = 1;i< npt; i++)
		{
			pt1 = &mixbd->at((cor_ID+npt+i*bias)%npt);
			if (pt1->PtType ==  Extensible_OutsideStepBD_Ends|| pt1->PtType ==  Extensible_InsideStepBD_Ends
				|| pt1->PtType ==InterSect_Vertical_Outside_BD|| pt1->PtType ==Extensible_Roof_Ends){outCount1++;}			
			 if (outCount1 == 2)
			{
				id_out =(cor_ID+npt+i*bias)%npt;
				break;
			}
		}
	}  
	if (id_out == -1 || id_rg == -1)
	{
		return false;
	}

	CES_D->id_ifAddPts = (id_rg + bias+npt)%npt;

	CES_D->rg_in = &mixbd->data()[id_rg];CES_D->rg_out = &mixbd->data()[(id_rg-bias+npt)%npt];
	CES_D->bd_in = &mixbd->data()[(id_out-bias+npt)%npt];CES_D->bd_out = &mixbd->data()[id_out];
	outCount1 = abs(cor_ID -id_rg); outCount2 = abs(cor_ID -CES_D->bd_in->id_inMixBd);
	CES_D ->count1 = fmin(outCount1, (npt - outCount1))-1;
	CES_D ->count2 = fmin(outCount2, (npt - outCount2));
	
	CES_D->rg_nv = CES_D->rg_out->m_p * (-1) + CES_D->rg_in->m_p;CES_D->rg_nv.z = 0;
	CES_D->bd_nv = CES_D->bd_out->m_p* (-1) + CES_D->bd_in->m_p; CES_D->bd_nv.z = 0;
	CCVector3 tmp = CCVector3(0, 0, 0);
	double len = calDisP2P_xy_sqrt(&CES_D->rg_nv, &tmp); CES_D->rg_nv = CES_D->rg_nv *(1/len);
	len = calDisP2P_xy_sqrt(&CES_D->bd_nv, &tmp); CES_D->bd_nv = CES_D->bd_nv  *(1 / len);

	TP_PtList insidePts_p;
	if (CES_D->count1 > 0 || CES_D->count2 > 0)
	{
		for(int i =1; i< CES_D->count1 +CES_D->count2+1  ;i++)
		{
			insidePts_p.push_back(mixbd->at((CES_D->rg_in->id_inMixBd + bias*i+npt)%npt));
			mixbd->data()[(CES_D->rg_in->id_inMixBd + bias*i+npt)%npt].delete_flag = true;

		}
	}
	int backID= decideRelationshipBetweentwoNormals(CES_D->rg_nv,CES_D->bd_nv);
	CES_D->isPara = CES_D->isVertical = false;
	if (backID == 1)CES_D->isPara = true;
	if (backID == 2)CES_D->isVertical= true;
	CES_D->pro_max = calDisP2P_xy_sqrt(&CES_D->bd_out->m_p,&CES_D->bd_in->m_p);
	double pro_now= calProPt2LineSegment_2d(&CES_D->rg_in->m_p,&CES_D->bd_out->m_p,&CES_D->bd_in->m_p);
	if (pro_now > CES_D->pro_max)CES_D->pro_max = pro_now;
	if (!insidePts_p.empty())
	{
		for (int i = 0 ; i< insidePts_p.size();i++)
		{
			pro_now = calProPt2LineSegment_2d(&insidePts_p.data()[i].m_p,&CES_D->bd_out->m_p,&CES_D->bd_in->m_p);
			if (pro_now > CES_D->pro_max)CES_D->pro_max = pro_now;
		}
	}
	insidePts_p.clear();
	return true;
}
