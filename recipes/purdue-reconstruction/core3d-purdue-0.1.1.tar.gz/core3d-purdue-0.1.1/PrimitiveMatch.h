#ifndef __LiDAR_POINT_PROCESS_TOPOLOGY_PRIMITIVE_MATCH_CLASS_DEFINE_H__
#define __LiDAR_POINT_PROCESS_TOPOLOGY_PRIMITIVE_MATCH_CLASS_DEFINE_H__

#include "topology.h"

/*
enum PrimitivesType
{
	Shed_1 = 1,
	Flat_1 = 2,
	Gable_2 = 3,
	Gambrel_4 = 4,
	Hipped_4 = 5,
	Mansard_8 = 6
};
*/
struct Primitive_infor_Hipped
{
	int nodes_ids[4]; //0, 1, 2, 3 ;   
	int ridge_ids[5];//0-1, 0-3,1-2 , 1-3, 2-3; 1 - 3 H ridge;
};
struct Primitive_infor_Gambrel
{
	int nodes_ids[4]; //0, 1, 2, 3 ;   
	int ridge_ids[3];//0-1,1-2, 2-3; all H ridge;
};
struct Primitive_infor_Gable
{
	int nodes_ids[2]; //0, 1, 2, 3 ;   
	int ridge_id;//0-1;  H ridge;
};

class PrimitiveMatch
{
public:
	TP_Model *m_model;
	Graph *m_Graph;
	int * flag_used;

	int n_pls;
	long n_for_pri;

	bool detect_Shed;
	bool detect_Flat;
	bool detect_Gable;
	bool detect_Gambrel;
	bool detect_Hipped;
	bool detect_Mansard;

	std::vector<Primitive_infor_Hipped>  hips;	
	std::vector<Primitive_infor_Gambrel>  gams;
	std::vector<Primitive_infor_Gable>  gabs;
	IDList flats;
	IDList sheds;

private:

	Graph *g_Gable;
	Graph *g_Gambrel;
	Graph *g_Hipped;
	Graph *g_Mansard;




public:
	PrimitiveMatch();
	void InitialMatch(TP_Model *md);
	bool search_child_In_father();
	int do_search();

private:
	int do_search_mansard();
	int do_search_node_four();
	int do_search_node_two();
	int do_search_node_one();
};

#endif