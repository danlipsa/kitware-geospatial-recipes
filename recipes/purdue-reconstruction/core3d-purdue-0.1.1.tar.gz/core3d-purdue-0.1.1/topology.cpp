//#include "stdafx.h"
#include "topology.h"
#include <algorithm>
#include <math.h>

# define  cos_angleSmall cos(3*PI/180)

CCVector2 getRidgeOri(G_Edge* eg)
{
	double dis1 = calDisP2P_xy_sqrt(&eg->p1->m_p, &eg->p2->m_p);
	return CCVector2((eg->p1->m_p.x - eg->p2->m_p.x)/dis1, (eg->p1->m_p.y - eg->p2->m_p.y)/dis1);
}
double cmpTwoOritations(CCVector2 r1,CCVector2 r2)
{
	return max(fabs(r1.x*r2.x+r1.y*r2.y), fabs(-r1.y*r2.x+r1.x*r2.y));
}
bool comTwoPlaneOri(vector<int > ori_1,vector<int > ori_2)
{
	if (ori_1.empty() || ori_2.empty() || ori_1.size() != ori_2.size())return false;
	
	bool f_return = true;

	for (int i=0;i< ori_1.size() ;i++)
	{
		if (ori_1.data()[(i)] != ori_2.data()[(i)])f_return = false;
	}
	return f_return;
}

double ori2double(CCVector2 m_ori)
{
	double a = fabs(m_ori.x),b= fabs(m_ori.y),temp;
	if (a < b )
	{
		temp = a; a= b,b = temp;
	}
	return acos(a/sqrt(a*a+b*b));
}


//step 1

void projectionPlane2Plane(TP_Plane *p1, TP_Plane *p2)
{

	p1->getPointCloud()->reserve(p1->getPointCloud()->size()+p2->getPointCloud()->size());
	for(long i = 0; i< p2->getPointCloud()->size();i++)
	{
		CCVector3* pt = &p2->getPointCloud()->at(i);
		CCVector3 pt_add = p1->Point2D_to_3D_ccVector3(*pt);	
		p1->getPointCloud()->push_back(pt_add);
	}

	p2->fatherID = p1->ID;
	p2->flag_IsInsidePlane = true;
	p1->childPlanes.push_back(p2);

	
}
void cutLongEdgeBD(BoundaryPts *m_outBD)	
{	
	TP_PtList *m_list = &m_outBD->mixBd;
	int npt= m_list->size();
	if (npt == 0)return;

	TP_PtList temp;  temp.push_back(m_list->front());
	double len =0;
	CCVector3 pt1, pt2;

	for (int i = 0; i < npt; i++)
	{
		pt1 = m_list->data()[i].m_p;
		pt2 = m_list->data()[(i+1)%npt].m_p;
		len= calDisP2P_2(&pt1,&pt2);
		len = sqrt(len);
		if (len < 10)
		{
			temp.push_back(m_list->data()[(i+1)%npt]);
		}
		else
		{
			int n_add = (int)(len/10.0);
			for (int j=1;j<n_add;j++)
			{
				TP_Vertex *m_add=new TP_Vertex;
				m_add->m_p = pt1 + (pt2 - pt1)*j*10*(1/len);
				m_add->delete_flag = false;
				m_add->PtType = NewlyAddCorners;
				temp.push_back(*m_add);
			}
			temp.push_back(m_list->data()[i+1]);
		}
	}
	temp.pop_back();
	m_outBD->mixBd = temp;
}

bool addtoIDlist(IDList *m_list,int id_add)
{
	if (m_list == NULL) m_list = new IDList;
	
	for(int i =0; i < m_list->size(); i++)
	{
		if (m_list->at(i)== id_add)return false;		
	}

	m_list->push_back(id_add);
	return true;
}


void decideOriAmongTwoPlanes(TP_Plane *p1,TP_Plane *p2,IDList *list_accept)
{
	IDList list_l = p1->ori_get();
	IDList list_r = p2->ori_get();

	if (list_l.empty() && list_r.empty()) return;

	if (p1->getPointCloud()->size() > 5 * p2->getPointCloud()->size() || list_r.empty())
	{
		(*list_accept) = list_l; return;
	}
	else if (p2->getPointCloud()->size() > 5 * p1->getPointCloud()->size() || list_l.empty())
	{
		(*list_accept) = list_r; return;
	}

	if (p1->f_expanded == p2->f_expanded)
	{
		(*list_accept) = list_l;
		for (int j= 0; j< list_r.size(); j++)
		{
			bool flag_same = false;
			for (int k = 0; k < list_l.size();k++)
			{
				if (list_r.data()[j] == list_l.data()[k])
				{flag_same= true ;break;}		
			}

			if (flag_same == false)
			{
				list_accept->push_back( list_r.data()[j]);
			}
		}
	}
	else if (!p1->f_expanded)   (*list_accept) = list_l;
	else (*list_accept) = list_r;


}
//M_M methods;
void replaceAnotherSide(Plane_Plane_Relation *ppr_all,bool isP1Upper,vector <TP_ModelCorner* > *mcd,vector <Plane_ConnectiveEdgeList*> *newPCEs)
{
	TP_PtList *l_now = NULL, *l_stable = NULL ;
	if (isP1Upper)l_now = &ppr_all->back_bd2;
	else l_now = &ppr_all->back_bd1;
	if (l_now->empty())return;
	

	TP_PtList l_temp; l_temp = *l_now;

	l_stable = &ppr_all->tps_stbd;

	int n_corners = l_stable->size();
	if (n_corners == 0)return;

	bool f_inverse = false;
	double dis_1 = calDisP2P_xy_sqrt(&l_now->front().m_p,&l_stable->front().m_p);
	double dis_2 = calDisP2P_xy_sqrt(&l_now->front().m_p,&l_stable->back().m_p);
	if (dis_1 > dis_2)f_inverse = true;
	IDList cornerIDs;
	int st_id,end_id,id_bias;

	if (!f_inverse)
	{
		int id_before = -1;
		CCVector3 pt1,pt2;
		for (int i =0; i< n_corners;i++)
		{
			pt1 = l_stable->at(i).m_p;
			dis_2 = 99999;
			int id_add = id_before+1;
			for(int j=id_before+1;j< l_now->size();j++)
			{
				pt2 = l_now->at(j).m_p;
				dis_1 = calDisP2P_xy_sqrt(&pt1,&pt2);
				if (dis_1 < dis_2)
				{
					dis_2 = dis_1;
					id_add = j;
				}
			}
			id_before = id_add;
			if (id_add < l_now->size())			
			cornerIDs.push_back(id_add);
		}
		if (cornerIDs.size() < 2 )return;		
		for (int i =0; i< cornerIDs.size();i++)
		{
			l_temp.data()[cornerIDs.at(i)].m_p = l_stable->at(i).m_p ;	
			l_temp.data()[cornerIDs.at(i)].PtStab = StepEdgeCorner;		
		}
		l_temp.data()[cornerIDs.front()].PtStab =l_stable->front().PtStab;
		l_temp.data()[cornerIDs.back()].PtStab =l_stable->back().PtStab;


	}
	else
	{
		int id_before = l_now->size();
		CCVector3 pt1,pt2;
		IDList temp;
		for (int i =0; i< n_corners;i++)
		{
			pt1 = l_stable->at(i).m_p;
			dis_2 = 99999;
			int id_add = id_before-1;
			for(int j=id_before-1;j> -1;j--)
			{
				pt2 = l_now->at(j).m_p;
				dis_1 = calDisP2P_xy_sqrt(&pt1,&pt2);
				if (dis_1 < dis_2)
				{
					dis_2 = dis_1;
					id_add = j;
				}
			}
			id_before = id_add;
			if (id_add >= 0)temp.push_back(id_add);
		}
		if (temp.size() < 2)return;

		for(int i =0 ;i < temp.size(); i++)
		{ 
			int ida = temp.at(i);
			cornerIDs.push_back(temp.at(temp.size()-i-1));			
			l_temp.data()[ida].m_p = l_stable->at(i).m_p;
			l_temp.data()[ida].PtStab = StepEdgeCorner;
		}
		l_temp.data()[cornerIDs.front()].PtStab =l_stable->back().PtStab;
		l_temp.data()[cornerIDs.back()].PtStab =l_stable->front().PtStab;

	}
	ppr_all->ID_onlist_2.x = l_now->at(cornerIDs.front()).ID;
	ppr_all->ID_onlist_2.y = l_now->at(cornerIDs.back()).ID;

	int npt = cornerIDs.back() -cornerIDs.front() +1 ;
	int plID = l_now->at(cornerIDs.front()).comp_flag;
	int st =l_now->at(cornerIDs.front()).id_InComploop;
	TP_Vertex *pt_now,*pt_after;
	int flag_same,len =0,id1 =cornerIDs.front(),id2;
	vector <TP_ModelBDSegments > tpmbs;

	for(int i =cornerIDs.front();i < cornerIDs.back(); i++)
	{
		len ++;
		pt_after = &l_now->data()[i+1];
		if (pt_after->comp_flag == plID  && (i+1) != cornerIDs.back())continue;
		TP_ModelBDSegments mbs_add;
		mbs_add.id_st= st;
		mbs_add.id_end = l_now->at(i).id_InComploop;
		mbs_add.id1 = id1;
		mbs_add.id2 = i;
		mbs_add.id_plane = plID;
		if ((i + 1) == cornerIDs.back() && pt_after->comp_flag == plID)
		{
			mbs_add.id_end = l_now->at(i + 1).id_InComploop;
			mbs_add.id2 = i + 1;
		}
		
		if (mbs_add.id1 != mbs_add.id2)
		{
			tpmbs.push_back(mbs_add);
		}		
		st = l_now->at(i+1).id_InComploop;
		id1 = i+1;
		plID = pt_after->comp_flag;
	}


	for(int i = 0 ;i < tpmbs.size(); i++)
	{
		Plane_ConnectiveEdgeList *newPCE = new Plane_ConnectiveEdgeList;
		TP_ModelBDSegments *mbs_now = &tpmbs.data()[i];
		//if (mbs_now->id1 < m_position.x || mbs_now->id2> m_position.y)continue;

		if (newPCE->InitialbyPtlist_stepEgs_withIDRange(&l_temp,CCVector2i(mbs_now->id1,mbs_now->id2)))
		{
			newPCE->pl_id = mbs_now->id_plane;
			newPCE->isPCEStepEg = true;			
			newPCEs->push_back(newPCE);
			mbs_now->pce = newPCE;
		}	
		else mbs_now->pce = NULL;
	}

}
void replaceModelBdByStepEdges(Plane_Plane_Relation *ppr_all,TP_PtList *bd_all,vector <Plane_Plane_Relation *> *m_stepPPR,
	vector <TP_ModelCorner* > *mcd,bool isP1Upper,vector <Plane_ConnectiveEdgeList*> *newPCEs)
{	
	if (bd_all->empty())return;
	
	int npt = bd_all->size();
	int plID = bd_all->front().comp_flag;
	int st = bd_all->front().id_InComploop;
	TP_Vertex *pt_now,*pt_after;
	int flag_same,len =0,id1 =0,id2;
	
	vector <TP_ModelBDSegments > tpmbs;


	for(int i =0;i < npt-1; i++)
	{
		len ++;
		pt_after = &bd_all->data()[i+1];
		if (pt_after->comp_flag == plID  && i != (npt-2))continue;
		
		TP_ModelBDSegments mbs_add;
		mbs_add.id_st= st;
		mbs_add.id_end = (i+1 == (npt-1)?bd_all->at(i+1).id_InComploop :bd_all->at(i).id_InComploop);
		mbs_add.id_plane = plID;
		mbs_add.id1 = id1;
		mbs_add.id2 = (i+1 == (npt-1)?i+1: i);
		
		for (int j = 0; j< m_stepPPR->size(); j++)
		{	
			if (m_stepPPR->at(j)->m_p1->ID != plID && m_stepPPR->at(j)->m_p2->ID != plID) continue;	

			m_stepPPR->at(j)->stepBD1.isPCECanceled = true;
			m_stepPPR->at(j)->stepBD2.isPCECanceled = true;
			mbs_add.m_pprs.push_back( m_stepPPR->at(j));
			if (addtoIDlist(&mbs_add.id_oris, m_stepPPR->at(j)->ori_id))
			{
				mbs_add.m_oris.push_back(m_stepPPR->at(j)->m_ori_ifStep);
			}
		}
		tpmbs.push_back(mbs_add);
		st = bd_all->at(i+1).id_InComploop;
		id1 = i+1;
		plID = pt_after->comp_flag;
	}
	int *pflag = new int[tpmbs.size()];

	for (int i =0 ; i< tpmbs.size();i++)
	{
		if (!tpmbs.at(i).id_oris.empty())pflag[i] = tpmbs.at(i).id_oris.front();
		else pflag[i] = -1;
		
	}
		//m_stepPPR->at(i)->ori_id;
	vector<CCVector2i > m_SParts;
	vector<CCVector3 > m_Oris;
	CCVector2i m_pos;
	int fg= pflag[0];id1 =id2= 0;
	for (int i =0 ; i< tpmbs.size();i++)
	{
//		if (tpmbs.at(id1).ppr == NULL)id1 = i;		
		if (i != tpmbs.size()-1 &&(pflag[i] == fg || pflag[i] == -1))
		{         
			id2 = i;
			continue;
		}
		if (i == tpmbs.size()-1){m_SParts.push_back(CCVector2i(id1,i));break;}
		
		for (int j = i;j>=0; j--)
		{
			if (pflag[i] == fg)
			{			
				m_SParts.push_back(CCVector2i(id1,j));
				id1 =id2 = i;
			}
		}
	}
	int id_a,id_b;
	for (int i = 0 ; i < m_SParts.size(); i++)
	{
		id1 = m_SParts.at(i).x;id2 = m_SParts.at(i).y;
		id_a = tpmbs.at(id1).id1;id_b = tpmbs.at(id2).id2;
		TP_PtList m_use,m_temp,m_out;
		
		for (int j = id_a ;j< id_b+1;j++ )m_use.push_back(bd_all->at(j));
		CCVector2 ori_now ;
		if (!tpmbs.at(id1).m_oris.empty())	ori_now = tpmbs.at(id1).m_oris.front();
		else continue;
		PtList_IO(&m_use,&m_temp,ori_now,false);
		CCVector2i m_position(-1,-1);
		replacePtListByPolyLine(&m_temp,&m_out,&m_position,0.5);
		if (m_position.x == -1 || m_position.y == -1)continue;
		
		ppr_all->ID_onlist_1.x = m_temp.at(m_position.x).ID;
		ppr_all->ID_onlist_1.y = m_temp.at(m_position.y).ID;
	

		TP_PtList *l_all;
		if (isP1Upper)l_all = &ppr_all->m_p1->m_outsideBD->m_pts;
		else l_all = &ppr_all->m_p2->m_outsideBD->m_pts;

		TP_PtList l_all_proj;
		PtList_IO( l_all,&l_all_proj,ori_now,false);

		adjustStepBd(&m_temp,&m_out,&l_all_proj,m_position,true);
		PtList_IO(&m_out,&m_out,ori_now,true);		
		for(int j =id1 ;j <id2+1; j++)
		{
			Plane_ConnectiveEdgeList *newPCE = new Plane_ConnectiveEdgeList;
			TP_ModelBDSegments *mbs_now = &tpmbs.data()[j];
			//if (mbs_now->id1 < m_position.x || mbs_now->id2> m_position.y)continue;
			if (mbs_now->id1 < m_position.x)mbs_now->id1 = m_position.x;
			if (mbs_now->id2 > m_position.y)mbs_now->id2 = m_position.y;
			if (mbs_now->id1 >= mbs_now->id2)continue;

			if (newPCE->InitialbyPtlist_stepEgs_withIDRange(&m_out,CCVector2i(mbs_now->id1,mbs_now->id2)))
			{
				newPCE->pl_id = mbs_now->id_plane;
				newPCE->isPCEStepEg = true;
				newPCEs->push_back(newPCE);
				mbs_now->pce = newPCE;
			}	
			else mbs_now->pce = NULL;
		}
	    
		for(int j =0 ;j <m_out.size(); j++)
		{
			if (m_out.at(j).PtStab > StepInside)ppr_all->tps_stbd.push_back(m_out.at(j));		
		}

	}
	
}




void getOneSideStepRidges(TP_PtList *pts,CCVector2i segRange,vector <CCVector2 > *m_oriPool,IDList *plOriIDs,Plane_ConnectiveEdgeList* newPCE)
{
	if (m_oriPool->empty()  || plOriIDs->empty())return ;
	
	TP_PtList pts_now,pts_proj,pts_cors,pts_temp,pts_all_proj;
	getPartOfPtsFromLoop(pts,&pts_now,segRange.x,segRange.y);

	vector <CCVector2 > oris_now;
	for(int i =0 ; i< plOriIDs->size();i++)
	{
		oris_now.push_back(m_oriPool->at(plOriIDs->at(i)));
	}
	long count_mark,count_max = 0,count_seg_max=9999;
	int ori_choose = 0,count_seg=0;
	CCVector2i m_pos(0, (long)oris_now.size());
	for(int i =0; i< oris_now.size();i++)
	{
		pts_proj.clear();
		pts_temp.clear();
		PtList_IO(&pts_now,&pts_proj,oris_now.at(i),false);
		CCVector2i m_pos_temp;

		replacePtListByPolyLine(&pts_proj,&pts_temp,&m_pos_temp,0.5);//

		/*FILE *temp = fopen("try1.txt", "w");
		for (size_t j = 0; j < pts_temp.size(); j++)
		{
			fprintf(temp, "%lf %lf\n", pts_temp.data()[j].m_p.x, pts_temp.data()[j].m_p.y);
		}
		fclose(temp);*/
		count_mark=0;
		count_seg=0;
		for (int j =0;j < pts_temp.size();j++)
		{
			if (pts_temp.at(j).PtStab >= StepInside)count_mark ++;	
			if (pts_temp.at(j).PtStab > StepInside)count_seg ++;	
		}
		if (count_seg < count_seg_max || (count_seg == count_seg_max &&  count_mark > count_max))
		{
			count_max = count_mark;
			ori_choose = i;
			pts_cors = pts_temp;
			m_pos = m_pos_temp;
			count_seg_max = count_seg;
		}
	}
	if (pts_cors.empty())return;
	PtList_IO(&pts_now,&pts_proj,oris_now.at(ori_choose),false);
	PtList_IO(pts,&pts_all_proj,oris_now.at(ori_choose),false);
	adjustStepBd(&pts_proj,&pts_cors,&pts_all_proj,m_pos,0.5);


	PtList_IO(&pts_cors,&pts_cors,oris_now.at(ori_choose),true);
	
	TP_PtList m_out;
	for (int i = 0; i< pts_cors.size();i++)
	{
		if (pts_cors.at(i).PtStab != StepInside)m_out.push_back(pts_cors.at(i));		
	}
	if (m_out.size() > 1)
	{		
		newPCE->InitialbyPtlist_stepEgs(&m_out);
		if (!newPCE->get_List_v()->empty())
		{
			newPCE->isPCEStepEg = true;
			newPCE->l_id = newPCE->get_List_v()->front()->id_InComploop;
			newPCE->r_id = newPCE->get_List_v()->back()->id_InComploop;
			
		}
		else  {newPCE->isPCEStepEg =false;newPCE->isPCECanceled = true;}
	}
	

	
}




void cutLoopIntoSegsByMarkedPts(int len, vector<CCVector2i >  usedRanges,vector<CCVector2i >  *m_segs)
{
//	assert(len > 0);
	int *fg_used= new int[len];memset(fg_used,0,sizeof(int)*len);
	int id1,id2;

	if (usedRanges.empty())m_segs->push_back(CCVector2i(0,len-1));
	
	for (int i=0; i< usedRanges.size();i++)
	{
		id1 = usedRanges.at(i).x;
		id2 = usedRanges.at(i).y;
		
		if (id1 <= id2)
		{
			for(int j=id1; j<= id2;j++)fg_used[j]= -1;
		}
		else
		{
			for(int j=0; j<= id2;j++)fg_used[j]= -1;
			for(int j=id1; j< len;j++)fg_used[j]= -1;
		}

	}
	IDList st_id,end_id;

	for(int i=0; i< len;i++)
	{
		if (fg_used[i] == -1 && fg_used[(i+1)%len] == 0)st_id.push_back((i+1)%len);
		if (fg_used[i] == 0 && fg_used[(i+1)%len] == -1)end_id.push_back(i);
	}

//	assert(st_id.size() == end_id.size());
	if (st_id.empty())return;
	
	if (end_id.front() < st_id.front())
	{
		for (int i=0; i< st_id.size();i++)
		{
			CCVector2i rg_add(st_id.at(i),end_id.at((i+1)%st_id.size()));
			m_segs->push_back(rg_add);
		}
	}
	else
	{
		for (int i=0; i< st_id.size();i++)
		{
			CCVector2i rg_add(st_id.at(i),end_id.at(i));
			m_segs->push_back(rg_add);
		}
	}
}

void  ForceAdjustTpList(TP_PtList *bd)
{
	deleteRepickPtsInLoops(bd);

	//ߵ
	int npt = bd->size();
	if (npt < 3) return;

	 CCVector3 pt1,pt2,pt3;
	double dis;
	int id_st, id_end;
	int *flag_id_test = new int[npt]; memset(flag_id_test, 0, sizeof(int)*npt);

	int countLine = 1, count_pt;
	for (int i = 0; i < npt; i++)
	{
		pt1 = bd->data()[i].m_p;
		pt2 = bd->data()[(i + 1) % npt].m_p;
		if (calDisP2P_xy_sqrt(&pt1, &pt2) <  0.5 ||flag_id_test[i] != 0)continue;
		count_pt = 0;
		id_st = i; id_end = (i + 1) % npt;
		for (int j = (i - 1 + npt) % npt; j!= i; j--)
		{
			if (j < 0) j += npt;
			if (flag_id_test[j] != 0) break;
			pt3 = bd->data()[j].m_p;
			dis = calDisPt2LineSegment_2d(&pt3, &pt1, &pt2, 1);
			if (dis < 0.1 && flag_id_test[j] == 0)
			{
				id_st = j;
				count_pt++;	
				flag_id_test[j] = countLine;
			}
			else break;
		}
		for (int j = (i + 2) % npt; j != i; j++)
		{
			 j = j %npt;
			if (flag_id_test[j] != 0) break;
			pt3 = bd->data()[j].m_p;
			dis = calDisPt2LineSegment_2d(&pt3, &pt1, &pt2, 1);
			if (dis < 0.1 && flag_id_test[j] == 0)
			{
				id_end = j;
				count_pt++;	
				flag_id_test[j] = countLine;
			}
			else break;
		}
		if (count_pt != 0)
		{
			flag_id_test[id_st] = countLine;
			flag_id_test[id_end] = countLine;
			for (int j = (id_st + 1) % npt; count_pt > 0;  count_pt--)
			{
				j = j %npt;
				flag_id_test[j] = countLine;				
				bd->data()[j].delete_flag = true;
				j++;
			}
		}
		
	}
	delete[]flag_id_test;

	refreshTP_ListByDeleteFlag(bd);




}
//Pl_Triangle_show Tri_to_PlTri(TRIANGLE *tri)
//{
////	return CCVector3(pt->x,pt->y,pt->attr);
//}

/*
void ConcavePolygonWithHoles_ToTriangles_TinMethods(TP_Plane *mainPl)
{
	CTINClass *tin = new CTINClass("plBdpts");
	if(!tin) return;

	tin->BeginAddPoints();
	TP_PtList *l_out = &mainPl->m_outsideBD->mixBd;
	TP_PtList *l_holes = nullptr;
	
	long npt1 = l_out->size();


	for(int i=0;i<npt1 ;i++)
	{
		const CCVector3* P = &l_out->at(i).m_p;
		tin->AddPoint((double) P->x, (double) P->y,i,1.0);	
		mainPl->m_trianglePts.push_back(l_out->at(i).m_p);
	}
	long npt2 = npt1;

	vector<TP_PtList *>  m_holes;
	vector<CCVector3>  triPts_add;
	
	
	if (!mainPl->childPlanes.empty())
	{
		for(int i=0;i<mainPl->childPlanes.size() ;i++)
		{
			l_holes =  &mainPl->childPlanes.data()[i]->m_outsideBD->mixBd;
			m_holes.push_back(l_holes);
			for(int j=0;j<l_holes->size();j++)
			{
				const CCVector3* P = &l_holes->at(j).m_p;
				tin->AddPoint((double) P->x, (double) P->y,npt2 +j,2.0);
				triPts_add.push_back(l_holes->at(j).m_p);
			}
			npt2 += l_holes->size();
		}

	}
	

	int  *fg_addPt=nullptr;
	int n_add = triPts_add.size();
	if (!triPts_add.empty())
	{		
		fg_addPt = new int[n_add];
		memset(fg_addPt,0,sizeof(int)*n_add);
	}

	tin->EndAddPoints();
	tin->FastConstruct();
	tin->EnableIntersection( true );
	tin->EnableConvex(false);

	int n_tin = tin->GetNumberOfTriangles();
	if (n_tin == 0 )return;
	tin->TriangleTraversalInit();
	TRIANGLE *tri_now = tin->TriangleTraverse();
//	vector <triPOINT *>
	while (tri_now != NULL)
	{
		triPOINT **pt = tri_now->vertex;
		CCVector3 pt_center;
		pt_center.x = (pt[0]->x + pt[1]->x+pt[2]->x)/3;
		pt_center.y = (pt[0]->y + pt[1]->y+pt[2]->y)/3;
		if (IsPtInRectList(l_out,pt_center))
		{
			bool fg_use = true;		
			//if (fg_use)
			{
				triPOINT  *pt_now = nullptr;
				Pl_Triangle_IDs  tri_add ;
				for(int i =0;i < 3;i++)
				{
					pt_now = tri_now->vertex[i];
					if ((int)(pt_now->attr) >= npt1)fg_addPt[(int)(pt_now->attr)- npt1] =1;
					tri_add.id[i] = (int)(pt_now->attr);
				}
				mainPl->m_triangleIDs.push_back(tri_add);			    
			}


		}
		
		tri_now = tin->TriangleTraverse();
	}

	int add_idNow = npt1;
	if (!triPts_add.empty())
	{
		for(int i =0;i < n_add;i++)
		{
			if (fg_addPt[i] == 1)
			{
				fg_addPt[i] = add_idNow;
				add_idNow++;
				mainPl->m_trianglePts.push_back(triPts_add.at(i));
			}
		}

		for(int i =0;i < mainPl->m_triangleIDs.size();i++)
		{
			Pl_Triangle_IDs *ids = &mainPl->m_triangleIDs.data()[i];
			for(int i =0;i < 3;i++)
			{
				if (ids->id[i] >= npt1)ids->id[i] = fg_addPt[ids->id[i] - npt1];
				
			}
		}
		delete [] fg_addPt;
		triPts_add.clear();
	}

	delete tin; tin = nullptr;

}
*/
TP_Model::TP_Model()
{
	father=NULL;
//	tin = NULL;
	tpGraph_initial=NULL;
	tpGraph_childs = NULL;
	m_childs =NULL;		
	mID_f2c=NULL;
	vID_f2c=NULL;
	ptsTPD=NULL;
	mainDirection=NULL;
	centerPt=NULL;

	id_ifIschildmodel = -1;
	flag_hasImageRidges = false;
	ori_ridges = NULL;
//	pMes=NULL;
}
TP_Model::~TP_Model()
{
	delete []ori_ridges;
}

//	



void TP_Model::Construct_main()
{

	n_plane=planes.size();	if (n_plane == 0)return;

	distinguishEdgeType();
		
	divideModleIntoChilds();

	for(int i =0 ; i < m_childs->size(); i++)
	{
		m_childs->at(i)->PrepareChildMessage();
	}
	for (int i = 0; i< tpGraph_childs->getEdgeCount();i++)
	{
		G_Edge *eg_now = tpGraph_childs->getEdgebyID(i);
		caculateM2M_relation(m_childs->at(eg_now->ID_1),m_childs->at(eg_now->ID_2));
	}
	for(int i =0 ; i < m_childs->size(); i++)
	{
		m_childs->at(i)->caculateModelBounduryOnWall();
	}	

	searchLoopsInGraph();
	for (int i = 0; i < n_plane; i++)
	{
		planes.data()[(i)]->MixBounduryWithRoofEdges();
	}

	//for (int i = 0; i < n_plane; i++)
	//	ForceAdjustTpList(&planes.data()[i]->m_outsideBD->mixBd);

	AdjustModelCorners();


	for (int i = 0; i< n_plane; i++)
	{ 
		TP_Plane *pl = planes.data()[(i)];
		for (int j = 0; j < pl->m_boundarys->size();j++ )
		{
			
			if (pl->m_boundarys->at(j)->type == OUTSIDE_EDGE)
			{
				TP_PtList *m_plpt = &pl->m_boundarys->at(j)->mixBd;
				for (size_t k = 0; k < m_plpt->size(); k++)
				{
					pl->Point2D_to_3D(&m_plpt->at(k));
				}
				ForceAdjustTpList(m_plpt);
			}			
		}
		
	}


	//	ForceAdjustTpList(&planes.data()[i]->m_outsideBD->mixBd);
	
	for (int i=0;i< n_plane ;i++)
	{
		TP_Plane * p1 = planes.data()[i];
		if (p1->m_GEdges.empty() && (p1->getPointCloud()->size() < 300 || p1->isUnRoboustPlane || !p1->isBdRegular))
		{
			if (p1->ori_get().empty())continue;
			
			int roi_id = p1->ori_get().front();
			if (roi_id > ori_pools.size()-1)continue;
		
			CCVector2 ori_now = this->ori_pools.at(roi_id);
			TP_PtList *bdpts = &p1->m_outsideBD->m_pts;
			if (bdpts->empty() || bdpts->size() < 3)continue;
			CCVector2 min_pt,max_pt,pt_trans;
			CCVector3 cen_pt = p1->computeGravityCenter();
			for (long j =0; j< bdpts->size();j++)
			{
				CCVector3 in = bdpts->at(j).m_p;
				pt_trans.x =  ori_now.x *(in.x- cen_pt.x)+ori_now.y*(in.y - cen_pt.y);
				pt_trans.y = -ori_now.y *(in.x- cen_pt.x)+ori_now.x*(in.y - cen_pt.y);
				if (j == 0)
				{
					min_pt.x =max_pt.x = pt_trans.x;
					min_pt.y =max_pt.y = pt_trans.y;
				}
				if (pt_trans.x > max_pt.x)max_pt.x = pt_trans.x;
				if (pt_trans.y > max_pt.y)max_pt.y = pt_trans.y;
				if (pt_trans.x < min_pt.x)min_pt.x = pt_trans.x;
				if (pt_trans.y < min_pt.y)min_pt.y = pt_trans.y;
			}
			CCVector2 mixBDpt[4];
			mixBDpt[0] = min_pt; mixBDpt[2]= max_pt;
			mixBDpt[1].x = max_pt.x; mixBDpt[1].y = min_pt.y;
			mixBDpt[3].x = min_pt.x; mixBDpt[3].y = max_pt.y;

			TP_Vertex mixBDOut[4];
			for (int j=0; j < 4;j++)
			{
				mixBDOut[j].m_p.x = ori_now.x * mixBDpt[j].x - ori_now.y *mixBDpt[j].y+cen_pt.x;
				mixBDOut[j].m_p.y = ori_now.y * mixBDpt[j].x + ori_now.x *mixBDpt[j].y+cen_pt.y;
			}
			bdpts = &p1->m_boundarys->front()->mixBd;			
			bdpts->clear();	
			for (int j=0; j < 4;j++)
				{
					p1->Point2D_to_3D(&mixBDOut[j]);
			        bdpts->push_back(mixBDOut[j]);
			    }
		}
	}		
}

void TP_Model::findInsidePlanes_andProjection()
{
	for (int i=0;i < tpGraph_initial->getEdgeCount();i++)
	{
		G_Edge *e_now =  tpGraph_initial->getEdgebyID(i);
		TP_Plane *p1=planes.data()[e_now->ID_1];
		TP_Plane *p2=planes.data()[e_now->ID_2];
		//算法有问题！?修改
		if (areaInArea(& p1->m_outsideBD->m_pts,& p2->m_outsideBD->m_pts)> 0.8)projectionPlane2Plane(p1,p2);
	}
	for (int i=0;i < n_plane;i++)
	{
		planes.data()[i]->m_boundarys->clear();
		planes.data()[i]->caculatePlaneMessage(1);
	}
	
}

void TP_Model::distinguishEdgeType()
{
	createAdjGraph();
	//findInsidePlanes_andProjection();
	int n_eg = tpGraph_initial->getEdgeCount();
	m_ppr = new Plane_Plane_Relation* [n_eg];
	Plane_Plane_Relation *ppr = NULL;
	TP_Plane *p1,*p2;
	G_Edge *e_now;
	for (int i=0;i < n_eg;i++)
	{
		e_now = tpGraph_initial->getEdgebyID(i);
		e_now->p1=e_now->p2=NULL;e_now->edgeType = NotExist;e_now->ori_group = -1;
		p1=planes.data()[e_now->ID_1];p2=planes.data()[e_now->ID_2];
		m_ppr[i]= new Plane_Plane_Relation(p1,p2,e_now);
		ppr = m_ppr[i];e_now->attr1 = ppr ;ppr->plist=(LineSegmentsList *)e_now->attr;	
		if (ppr->plist->size() == 0) continue;	
		if (p1->m_boundarys == NULL || p2->m_boundarys == NULL|| p1->m_boundarys->size() == 0 || p2->m_boundarys->size() == 0)continue;
		if (p1->isUnRoboustPlane || p2->isUnRoboustPlane)continue;
		
		ppr->caculateRobustRidgesFirst();
	}
	decideModelOri();
	for (int i=0;i < n_eg;i++)
	{
		e_now = tpGraph_initial->getEdgebyID(i);
		if (e_now->edgeType > 3)continue;
	
		p1 = planes.data()[e_now->ID_1]; p2 = planes.data()[e_now->ID_2];
		if (p1->m_boundarys == NULL || p2->m_boundarys == NULL || p1->m_boundarys->size() == 0 || p2->m_boundarys->size() == 0)continue;
		if (p1->isUnRoboustPlane || p2->isUnRoboustPlane)continue;
		IDList ori_accepted;
		decideOriAmongTwoPlanes(planes.data()[e_now->ID_1],planes.data()[e_now->ID_2],&ori_accepted);
		vector <CCVector2 > ori_tested;
		for (int j= 0; j< ori_accepted.size(); j++) ori_tested.push_back(ori_pools.data()[ori_accepted.at(j)]);

		if (ori_tested.empty())
		{
			m_ppr[i]->caculateRobustStepEdges(&ori_pools);
		}
		else m_ppr[i]->caculateRobustStepEdges(&ori_tested);		
	}
}
//step 2
void TP_Model::divideModleIntoChilds()
{		
	decomposeGraph();
	caculateChildsAndRelations();
}

#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>  
#include <CGAL/Delaunay_triangulation_2.h>
#include <CGAL/Triangulation_vertex_base_with_info_2.h>

using namespace CGAL;
typedef CGAL::Exact_predicates_inexact_constructions_kernel         K;
typedef CGAL::Triangulation_vertex_base_with_info_2<unsigned, K>    Vb;
typedef CGAL::Triangulation_data_structure_2<Vb>                    Tds;
typedef CGAL::Delaunay_triangulation_2<K, Tds>                      Delaunay;
typedef Delaunay::Point                                             Point;


void TP_Model::createAdjGraph()
{
	if (tpGraph_initial != NULL) return;

	int iFacade = planes.size();
	tpGraph_initial = new Graph;
	tpGraph_initial->graphInitial(iFacade);
	
	std::vector< std::pair<Point, unsigned> > points;
	long pt_id = 0;
	for (size_t i_seg = 0; i_seg < planes.size(); i_seg++)
	{
		TP_PtList *pl_now = &planes.at(i_seg)->m_outsideBD->m_pts;
		
		for (size_t i_pt = 0; i_pt < pl_now->size(); i_pt++)
		{
			CCVector3 pt_now = pl_now->data()[i_pt].m_p;
			points.push_back(std::make_pair(Point(pt_now.x, pt_now.y), i_seg));
			pt_id++;
		}
	}
	Delaunay dy;
	dy.insert(points.begin(), points.end());
	
	double delt_x, delt_y, dis2;
	int iF1=0, iF2=0, id1=0, id2=0;
	pLSL = new LineSegmentsList[iFacade*iFacade];
	LineSegmentsList * pLSL_now = NULL;
	CCVector3 pt1, pt2;
	
	long n_triangles = dy.number_of_faces();
	Delaunay::Finite_faces_iterator f_iter;

	//CDT::Finite_edges_iterator f_iter;
	for (f_iter = dy.faces_begin(); f_iter != dy.faces_end(); f_iter++)
	{
		for (int i = 0; i < 3; i++)
		{
			Point pt = f_iter->vertex(i)->point();
			pt1.x = pt.x(); pt1.y = pt.y(); 
			
			pt = f_iter->vertex((i + 1) % 3)->point();
			pt2.x = pt.x(); pt2.y = pt.y();

			iF1 = f_iter->vertex(i)->info();
			iF2 = f_iter->vertex((i + 1) % 3)->info();
			if (iF1 != iF2)
			{
				tinPointConnecters v_add;
				if (iF1 < iF2)
				{
					v_add.planeID_1 = iF1;
					v_add.planeID_2 = iF2;
					v_add.pt1 = pt1;
					v_add.pt2 = pt2;
				}
				else
				{
					v_add.planeID_1 = iF2;
					v_add.planeID_2 = iF1;
					v_add.pt1 = pt2;
					v_add.pt2 = pt1;
				}
				v_add.delt_h = fabs(pt2.z - pt1.z);
				pLSL[iF1*iFacade + iF2].push_back(v_add);
			}
		}
	}
			
	for (int i = 0; i<iFacade; i++)
		for (int j = i + 1; j<iFacade; j++)
		{
			pLSL_now = pLSL + i*iFacade + j;
			if (pLSL_now->size()> 1)
			{
				tpGraph_initial->insert_Edge(i, j, pLSL_now);
				tpGraph_initial->setEdge(i, j, true, pLSL_now->size(), NotExist);
			}
		}

}
/*
void TP_Model::createAdjGraph()
{
	if (tpGraph_initial != NULL) return;

	int iFacade = planes.size();	
	tpGraph_initial=new Graph;
	tpGraph_initial->graphInitial(iFacade);

	long pts_sum = 0;
	for (size_t i_seg = 0; i_seg < planes.size();i_seg++)
	{
		pts_sum += (long)planes.at(i_seg)->getPointCloud()->size();
	}

	pcl::PointCloud<pcl::PointXYZ>::Ptr m_cloud(new pcl::PointCloud<pcl::PointXYZ>);
	m_cloud->resize(pts_sum); m_cloud->width = pts_sum; m_cloud->height = 1;
	int *seg_flag = new int[pts_sum]; memset(seg_flag, 0, sizeof(int)*pts_sum);
	
	long pt_id = 0;
	for (size_t i_seg = 0; i_seg < planes.size(); i_seg++)
	{
		ccPointCloud *pl_now = planes.at(i_seg)->getPointCloud();
		for (size_t i_pt = 0; i_pt < pl_now->size(); i_pt++)
		{
			m_cloud->points[pt_id].x = pl_now->data()[i_pt].x;
			m_cloud->points[pt_id].y = pl_now->data()[i_pt].y;
			m_cloud->points[pt_id].z = 0;// pl_now->data()[i_pt].z;
			seg_flag[pt_id] = (long) i_seg;
			pt_id++;
		}

		//TP_PtList *pl_now = &planes.at(i_seg)->m_outsideBD->m_pts;
		//
		//for (size_t i_pt = 0; i_pt < pl_now->size(); i_pt++)
		//{
		//	m_cloud->points[pt_id].x = pl_now->data()[i_pt].m_p.x;
		//	m_cloud->points[pt_id].y = pl_now->data()[i_pt].m_p.y;
		//	m_cloud->points[pt_id].z = 0;// pl_now->data()[i_pt].m_p.z;
		//	seg_flag[pt_id] = (long) i_seg;
		//	pt_id++;
		//}
	}

	pcl::PointCloud<pcl::PointNormal>::Ptr cloud_with_normals(new pcl::PointCloud<pcl::PointNormal>);
	pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> n;
	pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>);
	pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ>);
	tree->setInputCloud(m_cloud);
	n.setInputCloud(m_cloud);
	n.setSearchMethod(tree);
	n.setKSearch(30);
	n.compute(*normals);
	pcl::concatenateFields(*m_cloud, *normals, *cloud_with_normals);
	pcl::search::KdTree<pcl::PointNormal>::Ptr tree2(new pcl::search::KdTree<pcl::PointNormal>);
	tree2->setInputCloud(cloud_with_normals);

	pcl::GreedyProjectionTriangulation<pcl::PointNormal> gp3;
	pcl::PolygonMesh mesh; 
	gp3.setSearchRadius(20*aveDis);
	gp3.setMu(2.5);
	gp3.setMaximumNearestNeighbors(100);
	gp3.setMaximumSurfaceAngle(M_PI/4);
	gp3.setMinimumAngle(M_PI / 18);
	gp3.setMaximumAngle(2*M_PI/3 );
	gp3.setNormalConsistency(false);
	gp3.setInputCloud(cloud_with_normals);
	gp3.setSearchMethod(tree2);
	gp3.reconstruct(mesh);

	double delt_x, delt_y, dis2;
	int iF1, iF2,iF3, id1, id2,id3;
	pLSL = new LineSegmentsList[iFacade*iFacade];
	LineSegmentsList * pLSL_now = NULL;
	CCVector3 pt1, pt2;

	long n_triangles = mesh.polygons.size();	
	for (long i = 0; i < n_triangles; i++)
	{
		for (long j = 0; j < 3; j++)
		{
			id1 = (long)mesh.polygons.at(i).vertices[j];
			id2 = (long)mesh.polygons.at(i).vertices[(j+1)%3];
			iF1 = seg_flag[id1];
			iF2 = seg_flag[id2];
			pt1.x = m_cloud->points[id1].x; pt1.y = m_cloud->points[id1].y; pt1.z = m_cloud->points[id1].z;
			pt2.x = m_cloud->points[id2].x; pt2.y = m_cloud->points[id2].y; pt2.z = m_cloud->points[id2].z;
			//if (calDisP2P_xy_sqrt(&pt1,&pt2) > 10)continue;
			
			if (iF1 != iF2)
			{
				tinPointConnecters v_add;
				if (iF1< iF2)
				{
					v_add.planeID_1 = iF1;
					v_add.planeID_2 = iF2;
					v_add.pt1 = pt1;
					v_add.pt2 = pt2;
				}
				else
				{
					v_add.planeID_1 = iF2;
					v_add.planeID_2 = iF1;
					v_add.pt1 = pt2;
					v_add.pt2 = pt1;
				}
				v_add.delt_h = fabs(pt2.z - pt1.z);
				pLSL[iF1*iFacade + iF2].push_back(v_add);
		    }
	     }
	}
	m_cloud->clear();
	////*
	pcl::search::KdTree<pcl::PointXYZ>::Ptr kdtree(new pcl::search::KdTree<pcl::PointXYZ>);
	kdtree->setInputCloud(m_cloud);
	

	double delt_x, delt_y, dis2;
	int iF1, iF2,id1,id2;
	pLSL = new LineSegmentsList[iFacade*iFacade];
	LineSegmentsList * pLSL_now = NULL;
	tinPointDiscriber *TPD_1, *TPD_2 = NULL;
	TP_Plane *pl_1, *pl_2;
	CCVector3 pt1, pt2;

	for (long i = 0; i < m_cloud->size(); i++)
	{
		iF1 = seg_flag[i];
		pt1.x = m_cloud->points[i].x; pt1.y = m_cloud->points[i].y; pt1.z = m_cloud->points[i].z;
		pl_1 = planes.at(iF1);
		vector<int> nnh;
		vector<float> squaredistance;
		const pcl::PointXYZ ptNow = m_cloud->points[i];
		kdtree->radiusSearch(i, 10*aveDis, nnh, squaredistance);
		int n_neibors = nnh.size();
	
		for (int j = 0; j < n_neibors; j++)
		{
			id2 = nnh.at(j);
			iF2 = seg_flag[id2];
			if (iF1 != iF2)
			{
				pl_2 = planes.at(iF2);
				pt2.x = m_cloud->points[id2].x; pt2.y = m_cloud->points[id2].y; pt2.z = m_cloud->points[id2].z;		
								
				tinPointConnecters v_add;
				if (i < id2)
					{
						v_add.planeID_1 = iF1;
						v_add.planeID_2 = iF2;
						v_add.pt1 = pt1;
						v_add.pt2 = pt2;
					}
				else{
						v_add.planeID_1 = iF2;
						v_add.planeID_2 = iF1;
						v_add.pt1 = pt2;
						v_add.pt2 = pt1;
					}
					v_add.delt_h = fabs(pt2.z - pt1.z);
					
					pLSL[iF1*iFacade + iF2].push_back(v_add);
			}
		}		
	}
	m_cloud->clear();
	///
	for (int i=0;i<iFacade;i++)
		for(int j=i+1;j<iFacade;j++)
	{
		pLSL_now=pLSL+i*iFacade+j;
		if (pLSL_now->size()> 1 )
		{
			tpGraph_initial->insert_Edge(i,j,pLSL_now);
			tpGraph_initial->setEdge(i,j,true,pLSL_now->size(),NotExist);
		}	    
	}

}
*/
//methods for step 2
void TP_Model::decomposeGraph()
{

	long i,j,k;
	if (tpGraph_initial == NULL)return;
	

	for (i=0;i<tpGraph_initial->getEdgeCount();i++)
	{
		G_Edge *gEdge=tpGraph_initial->getEdgebyID(i);
		if (gEdge->edgeType == Step || gEdge->edgeType ==  NotExist|| gEdge->edgeType ==  Undecided)
		{
			tpGraph_initial->setEdgeFlag(gEdge->ID_1,gEdge->ID_2,0);
		}
	} 	
	mID_f2c =new int[n_plane];
	vID_f2c =new int[n_plane];
	int child_count=tpGraph_initial->findConnectGroups(mID_f2c);

	if (child_count > 0)
	{
		tpGraph_childs = new Graph;
		tpGraph_childs->graphInitial(child_count);

		m_childs =new vector<TP_Model * >;
		for (i=0;i<child_count;i++)
		{
			TP_Model *child_i = new TP_Model;
			int count_v=0;
			for (j=0;j<n_plane;j++)
			{
				if (mID_f2c[j] != i)continue;
				else
				{
					vID_f2c[j]=count_v++;
					child_i->planes.push_back(planes.data()[(j)]);
				}			
			}
			child_i->n_plane = child_i->planes.size();

			if (child_i->n_plane == 0)continue;			
			else
			{		
				ccPointCloud  *cc_clouds = new ccPointCloud;
				ccPointCloud  *cc_i = nullptr;
				for (j=0;j<child_i->n_plane;j++)
				{
					cc_i = child_i->planes.at(j)->getPointCloud();
					long npt_i = cc_i->size();
					for (long k = 0; k < npt_i;k++)
					{
						cc_clouds->push_back(cc_i->at(k));
					}
				}						
			child_i->setPointCloud(cc_clouds);
			child_i->father=this;
			child_i->tpGraph_initial=new Graph;
			child_i->tpGraph_initial->graphInitial(child_i->n_plane);
			child_i->id_ifIschildmodel = m_childs->size();
			m_childs->push_back(child_i);
			}
		}
     }
}
void TP_Model::caculateChildsAndRelations()
{
	if (tpGraph_initial == NULL)return;
	
	long i,j,k;
	G_Edge *edge_now=NULL;
	G_Edge *edge_father=NULL;
	TP_Model *model_now=NULL;
	Graph *graph_now=NULL;
	for (i=0;i < tpGraph_initial->getEdgeCount(); i++)//
	{
		edge_now=tpGraph_initial->getEdgebyID(i);//
		int id_1,id_2;
		id_1=mID_f2c[edge_now->ID_1];
		id_2=mID_f2c[edge_now->ID_2];

		if (id_1 == id_2)//属于同一子模?
		{
			model_now = m_childs->data()[(id_1)];
			graph_now=model_now->tpGraph_initial;
			graph_now->insert_Edge(vID_f2c[edge_now->ID_1],vID_f2c[edge_now->ID_2],edge_now->attr);			
			graph_now->setFatherID_e(graph_now->getEdgeCount() -1,i); 
			graph_now->setEdge(vID_f2c[edge_now->ID_1],vID_f2c[edge_now->ID_2],edge_now->flag_use,
			edge_now->weight,edge_now->edgeType,edge_now->p1,edge_now->p2);

		}
		else
		{
			/*tpGraph_childs->insert_Edge(id_1,id_2,edge_now->attr);
			tpGraph_childs->setFatherID_e(tpGraph_childs->getEdgeCount() -1,i); 
			tpGraph_childs->setEdge(id_1,id_2,edge_now->flag_use,edge_now->weight,edge_now->edgeType);*/
			if (id_1 > id_2)
			{
				m_ppr[i]->isModleID_1over2 = true;
				tpGraph_childs->insert_Edge_Multiply(id_2,id_1,m_ppr[i]);
			}
			else	tpGraph_childs->insert_Edge_Multiply(id_1,id_2,m_ppr[i]);
			
		}

	}
	for(i=0;i<n_plane;i++)//
	{
		model_now=m_childs->data()[(mID_f2c[i])];
		graph_now=model_now->tpGraph_initial;
		graph_now->setFatherID_v(vID_f2c[i],i);
	}
}



//methods for step 3
void TP_Model::searchLoopsInGraph()
{
	long i,j,k;	
	G_Edge *edge_now=NULL;
//	G_Edge *edge_father=NULL;
	TP_Model *model_now=this;
//	Graph *graph_now=NULL;
	model_now->n_plane=model_now->planes.size();
	if (model_now->planes.size()  > 1  && model_now->tpGraph_initial != NULL)
	{
		Graph *gp=model_now->tpGraph_initial;
		int loopCount=gp->findLoops();
		if (loopCount > 0)
		{
			for(j=0;j<loopCount;j++)//
			{
				IDList *list_loop=&gp->m_loops->data()[(j)];

				TP_Vertex *cornerPt=model_now->MultiplyPlanesAtOnePoint(list_loop,0.5);
				int errorCount=0;
				if (cornerPt != NULL)//能够将环合并,则归并到目标?
				{
					int n_ridges=list_loop->size();//有几个面 就有几条边需要调?;
					int id1,id2;
					double dis1,dis2,dis;

					//可能修改了面的参数，需要重新计算屋脊线，由于只是平移了平面，平面的法相和屋脊线的方向并不会改变;
					//计算过程，将原屋脊往过公共点的法相上投影，近出点修改为公共点，远处点为新顶点;
					//需要考虑两端都是公共点的情况;
					for ( k=0; k< n_ridges; k++)
					{
						id1 = list_loop->data()[(k)];
						id2 = list_loop->data()[((k+1)%n_ridges)];						
						edge_now = gp->getEdge(id1,id2);
//////////////////////////////////////////////////////////////////////////
//					    edge_father=father->tpGraph_initial->getEdgebyID(edge_now->fatherID);
						CCVector3  cen = cornerPt->m_p;						
						CCVector3  srcPt_1 = edge_now->p1->m_p;
						CCVector3  srcPt_2 = edge_now->p2->m_p;
						
						CCVector3  nv_ori = srcPt_2 - srcPt_1;
						double dis_1_2 = calDisP2P_xyz_sqrt(srcPt_1,srcPt_2); 
						nv_ori.x /= dis_1_2;nv_ori.y /= dis_1_2;nv_ori.z /= dis_1_2;


						double pro = calProPt2LineSegment_2d(&cen,&srcPt_1,&srcPt_2);
						

						if (pro < (-3)  || pro > (dis_1_2 + 3))	
						{ 
							errorCount++;
							if (errorCount < 2)continue;
							else break;									
						}

						dis1 = fabs(pro);
						dis2 = fabs(dis_1_2 - pro);

						int i_loop = j ;
						

						if (dis1 < dis2)//p1?且小于延伸距离，p1调整到中心，p2投影;
						{
							if (edge_now->p1->PtStab == Stable)
							{							
								{
									edge_now->p2=cornerPt;
									edge_now->p2->PtStab = Stable;
									edge_now->p2->i_loop = i_loop;
									continue;
								}
							}
							edge_now->p1 = cornerPt;
					        edge_now->p1->PtStab = Stable;
							edge_now->p1->i_loop = i_loop;
							if (edge_now->p2->PtStab != Stable)
							{
									CCVector3 pro_1_c(nv_ori.x*pro, nv_ori.y*pro, nv_ori.z*pro );
									edge_now->p2->m_p = cen- pro_1_c + srcPt_2 - srcPt_1;
							}
							continue;
						}
						else //p2?且小于延伸距离，p2调整到中心，p1投影;
						{
							if (edge_now->p2->PtStab == Stable)
							{
								{
									edge_now->p1=cornerPt;
									//edge_father->p1=edge_now->p1;
									edge_now->p1->PtStab = Stable;
									edge_now->p1->i_loop = i_loop;
									continue;
								}
							}
							
							edge_now->p2 = cornerPt;
							edge_now->p2->PtStab = Stable;
							edge_now->p1->i_loop = i_loop;
							if (edge_now->p2->PtStab != Stable)
							{
								
								CCVector3 pro_2_c(nv_ori.x*(pro-dis_1_2), nv_ori.y*(pro-dis_1_2), nv_ori.z*(pro-dis_1_2));
								edge_now->p1->m_p = cen -  pro_2_c- srcPt_2 + srcPt_1;
							}
							continue;
						}			
					}
					if (errorCount <2)
					{
						cornerPt->PtStab = Stable;
						for ( k=0; k< n_ridges; k++)
						{
							int pl_id=list_loop->data()[(k)];
							int id_before=list_loop->data()[((k+n_ridges-1)% n_ridges)];
							int id_after=list_loop->data()[((k+1)% n_ridges)];
							TP_Plane *pl=model_now->planes.data()[(pl_id)];
							TP_Plane_LoopMessage m_msg;
							m_msg.cornerPt=cornerPt;
							m_msg.edge1=model_now->tpGraph_initial->getEdge(id_before,pl_id)->ID;
							m_msg.edge2=model_now->tpGraph_initial->getEdge(pl_id,id_after)->ID;
							m_msg.loopID=j;
							pl->m_loopMessage.push_back(m_msg);
						}
					}
				}
			}
		}
	}

	
}
TP_Vertex*  TP_Model::MultiplyPlanesAtOnePoint(IDList* planeIDs, double Thre)
{
	int i,j;
	vector<CmpType<long > > ptNums;
	for (i=0;i<planeIDs->size();i++)
	{
		TP_Plane * pl= planes.data()[(planeIDs->data()[(i)])];
		CmpType<long > CT_num(pl->getPointNumber(),planeIDs->data()[(i)]);		
		ptNums.push_back(CT_num);
	}
	qsort(&ptNums.data()[(0)],ptNums.size(),sizeof(CmpType<long >),cmp1<long>); 

	Eigen::Matrix3d ABC;
	Eigen::Matrix<double, 3, 1> D;
	Eigen::Matrix<double, 3, 1> back_X;
	int H_planeCount = 0;
	for (i = 0; i < 3; i++)
	{
		TP_Plane * pl = planes.data()[(ptNums.data()[(i)].id)];
		ABC(i, 0) = pl->m_a;
		ABC(i, 1) = pl->m_b;
		ABC(i, 2) = pl->m_c;
		if (fabs(1 - pl->m_c) < 0.0001)
			H_planeCount++;
		D(i,0)    = -1 * pl->m_d;
	}
	if (H_planeCount > 1) return NULL;

	Eigen::Matrix3d ABC_in = ABC.inverse();
	back_X = ABC_in *D;
	TP_Vertex *outPut=new TP_Vertex;
	outPut->m_p.x = back_X(0, 0);
	outPut->m_p.y = back_X(1, 0);
	outPut->m_p.z = back_X(2, 0);

	double dis,dismax=0;
	for(i=3;i< planeIDs->size();i++)
	{
		TP_Plane * pl= planes.data()[(ptNums.data()[(i)].id)];
		dis = fabs(pl->m_a* outPut->m_p.x + pl->m_b*outPut->m_p.y +  pl->m_c*outPut->m_p.z + pl->m_d );
		dis = dis/sqrt(pl->m_a*pl->m_a+ pl->m_b*pl->m_b + pl->m_c* pl->m_c);
		if (dis > dismax)dismax =dis;
	}

	if (dismax < Thre)
	{
		for(i=3;i< planeIDs->size();i++)
		{
			TP_Plane * pl= planes.data()[(ptNums.data()[(i)].id)];
			pl->m_d = -1*(pl->m_a * outPut->m_p.x+pl->m_b * outPut->m_p.y+pl->m_c * outPut->m_p.z);
		}
        return outPut;
	}
	else return NULL;
}


void TP_Model::caculateBuildingMainDirection()
{
	int n_ridge=tpGraph_initial->getEdgeCount();
	vector<CmpType<int > > CmpData;
	for (int i=0;i< n_ridge;i++)
	{
		G_Edge* ed=tpGraph_initial->getEdgebyID(i);
		if (ed->edgeType == SS_H || ed->edgeType == HS_H )
		{			
			CmpType<int > CT_num(ed->weight,i);
			CmpData.push_back(CT_num);
		}
	}
	TP_Plane *pl =NULL;
	vector<G_Edge *> insideEgs;

	for (int i=0;i< planes.size();i++)
	{		
		if (planes.data()[(i)]->childPlanes.size() != 0)
		{		
			for(int j=0;j< planes.data()[(i)]->childPlanes.size();j++)
			{
				pl= planes.data()[(i)]->childPlanes.data()[(j)];
				if (pl->m_GEdges.size() == 1)
				{
					G_Edge* ed = pl->m_GEdges.front();
					double len = calDisP2P_2(&ed->p1->m_p,&ed->p2->m_p);
					double ang = fabs(ed->p1->m_p.z - ed->p2->m_p.z)/sqrt(len);
					if (fabs(ang)  < sin(3*PI/180.0))
					{
						CmpType<int > CT_num(ed->weight,n_ridge + insideEgs.size());
						CmpData.push_back(CT_num);
						insideEgs.push_back(pl->m_GEdges.front());

					}
				}				
			}
		}
		if (planes.data()[i]->flag_IsInsidePlane  && !planes.data()[i]->m_GEdges.empty())
		{	
			G_Edge* ed = planes.data()[i]->m_GEdges.front();
			double len = calDisP2P_2(&ed->p1->m_p,&ed->p2->m_p);
			double ang = fabs(ed->p1->m_p.z - ed->p2->m_p.z)/sqrt(len) ;
			if (fabs(ang)  < sin(3*PI/180.0))
			{
				CmpType<int > CT_num(ed->weight,n_ridge + insideEgs.size());
				CmpData.push_back(CT_num);
				insideEgs.push_back(planes.data()[(i)]->m_GEdges.front());
			}			

		}
	}

	if (CmpData.size() == 0){mainDirection=NULL;return;}
	qsort(&CmpData.data()[(0)],CmpData.size(),sizeof(CmpType<int >),cmp1<int>); 
	
	if (CmpData.size() == 0)return ;

	mainDirection =new CCVector2;
	G_Edge* ed_main1=NULL,* ed_main2=NULL;
	double a1,b1,a2,b2,length,cos_sita;
	if (CmpData.size()== 1 || (CmpData.data()[(0)].val)/2 > CmpData.data()[(1)].val)
	{
		if (CmpData.data()[(0)].id < n_ridge)
		{
			ed_main1=tpGraph_initial->getEdgebyID(CmpData.data()[(0)].id);
		}
		else ed_main1 = insideEgs.data()[(CmpData.data()[(0)].id - n_ridge)];

		a1=ed_main1->p1->m_p.x-ed_main1->p2->m_p.x;
		b1=ed_main1->p1->m_p.y-ed_main1->p2->m_p.y;
		length = sqrt(a1*a1+b1*b1);

		if (a1 < 0){a1 *= (-1); b1 *= (-1);}

		mainDirection->x= a1/length; mainDirection->y= b1/length; 
	}

	else
	{
		if (CmpData.data()[(0)].id < n_ridge)
		{
			ed_main1=tpGraph_initial->getEdgebyID(CmpData.data()[(0)].id);
		}
		else ed_main1 = insideEgs.data()[(CmpData.data()[(0)].id - n_ridge)];

		a1=ed_main1->p1->m_p.x-ed_main1->p2->m_p.x;
		b1=ed_main1->p1->m_p.y-ed_main1->p2->m_p.y;
		length = sqrt(a1*a1+b1*b1);
		a1 =a1/length;  b1 = b1/length;
		if (a1 < 0){a1 *= (-1); b1 *= (-1);}

		if (CmpData.data()[(1)].id < n_ridge)
		{
			ed_main2=tpGraph_initial->getEdgebyID(CmpData.data()[(1)].id);
		}
		else ed_main2 = insideEgs.data()[(CmpData.data()[(1)].id - n_ridge)];

		a2=ed_main2->p1->m_p.x-ed_main2->p2->m_p.x;
		b2=ed_main2->p1->m_p.y-ed_main2->p2->m_p.y;
		length = sqrt(a2*a2+b2*b2);
		a2 = a2/length;  b2 = b2/length;
		

		cos_sita = fabs(a1*a2+b1*b2);
		if (cos_sita > cos(5*PI/180) )
		{
			if (a2 < 0){a2 *= (-1); b2 *= (-1);}
			mainDirection->x = (a1 * ed_main1->weight + a2*ed_main2->weight)/(ed_main1->weight+ ed_main2->weight);
			mainDirection->y = (b1 * ed_main1->weight + b2*ed_main2->weight)/(ed_main1->weight+ ed_main2->weight);
		}
		else if (cos_sita < cos(85*PI/180))
		{
			if (b2 < 0){a2 *= (-1); b2 *= (-1);}
			mainDirection->x = (a1 * ed_main1->weight + b2*ed_main2->weight)/(ed_main1->weight+ ed_main2->weight);
			mainDirection->y = (b1 * ed_main1->weight - a2*ed_main2->weight)/(ed_main1->weight+ ed_main2->weight);
		}
		else if (cos_sita > cos(15*PI/180)  && cos_sita < cos(75*PI/180))mainDirection=NULL;		
		else
		{
	        mainDirection->x=a1;mainDirection->y=b1;
		}

	}	

}
/*
void TP_Model::caculateModelBounder()
{	
			
	n_plane=planes.size(); 

	aveDis =father->aveDis;
	for (int i=0;i<n_plane;i++) planes.data()[(i)]->ID_childModle = i;
	int n_outbd;
	TP_PlaneBoundary *model_BD=generateEdge(getPointCloud(),3*aveDis,&n_outbd);

	centerPt =&computeGravityCenter();
	caculateBuildingMainDirection();
	if (mainDirection == NULL)mainDirection=father->mainDirection;

	TP_Plane *plane_now=NULL;
	TP_PtList *list_outbd,*list_i;

	bdAdjustment *adjusts = new bdAdjustment [model_BD->size()];
	bdAdjustment *p_adjust=NULL;
	for (int i_outbd=0;i_outbd< model_BD->size() ;i_outbd++)
	{
		p_adjust = adjusts+i_outbd;
		if (mainDirection == NULL)continue;
		TP_PtList * the_pts = &model_BD->data()[(i_outbd)]->m_pts;
		for(int j=0;j< the_pts->size();j++)
		{
			TP_Vertex *tpV=&the_pts->data()[j];
			tpV->id_InComploop = -1;
			tpV->ID=j;			
		}
		p_adjust->InitialData(model_BD->data()[(i_outbd)],mainDirection,centerPt);

		p_adjust->MixModelBdAndEdgeEnds_main(tpGraph_initial);

		for (int i=0;i<n_plane;i++)
		{
			p_adjust->savePlaneParameters(planes.data()[(i)]->m_a,planes.data()[(i)]->m_b,planes.data()[(i)]->m_c,planes.data()[(i)]->m_d);
		}

	}

	for (int i=0;i< n_plane ;i++)
	{
		planes.data()[(i)]->MixBounduryWithRoofEdges();//	&p_adjust
	}		

	
	 
	for (int i_outbd=0;i_outbd< model_BD->size();i_outbd++)
	{
		if (mainDirection == NULL)continue;		
		list_outbd= &model_BD->data()[(i_outbd)]->m_pts;

		if (list_outbd->size() < 20)continue;
		
		p_adjust = adjusts+i_outbd;

		for (int i=0;i< n_plane ;i++)
		{
			plane_now=planes.data()[(i)];

			if (planes.data()[i]->flag_IsInsidePlane)				
			{
				planes.data()[i]->caculateSingleInsidePlane(p_adjust,planes.data()[plane_now->fatherID]);
				continue;
			}

			int count=0;
			for (int i_bd= 0;i_bd< plane_now->m_boundarys->size();i_bd++)
			{
				list_i=&plane_now->m_boundarys->data()[(i_bd)]->m_pts;
				compareTwoEdges(list_outbd,list_i,i+1,1);

				for (int j=0;j<list_outbd->size();j++)
				{
					if (list_outbd->data()[(j)].comp_flag == i+1)
					{
						CCVector3 *pt=&list_outbd->data()[(j)].m_p;						
						pt->z = -(plane_now->m_a * pt->x+plane_now->m_b * pt->y+plane_now->m_d)/(plane_now->m_c );						
						count++;
					}
				}
			}				
		}	
//		p_adjust->regularizationStepEdges();

		int n_stepPlanes =p_adjust->stepPlanes.size();

		for (int i_step=0; i_step< n_stepPlanes;i_step++)
		{
			father->stepPlanes.push_back(p_adjust->stepPlanes.data()[(i_step)]);
		}
	}

	if (tpGraph_initial->getEdgeCount() == 0 && planes.size() == 1)
	{		
		TP_PlaneBoundary *mbd_pl = planes.data()[(0)]->m_boundarys;
		for (int i_bd= 0;i_bd< mbd_pl->size();i_bd++)
		{
			p_adjust= adjusts+i_bd;
			if (mbd_pl->data()[(i_bd)]->type == OUTSIDE_EDGE)
			{
				if (p_adjust->corners_out.size() != 0)
				{
					mbd_pl->data()[(i_bd)]->mixBd.clear();
					for (int i=0; i< p_adjust->corners_out.size();i++)
					{					
						planes.data()[(0)]->Point2D_to_3D(&p_adjust->corners_out.data()[(i)]);
						mbd_pl->data()[(i_bd)]->mixBd.push_back(p_adjust->corners_out.data()[(i)]);			
						//mbd_pl->data()[(i_bd)->mixBd = mbd_pl->data()[(i_bd)->m_pts;
					}
				}
				else
				{
					mbd_pl->data()[(i_bd)]->mixBd = mbd_pl->data()[(i_bd)]->corners;
					for (int i=0; i< mbd_pl->data()[(i_bd)]->mixBd.size();i++)
					{					
						planes.data()[(0)]->Point2D_to_3D(&mbd_pl->data()[(i_bd)]->mixBd.data()[(i)]);		
					//	planes.data()[(0)]->Point2D_to_3D(&mbd_pl->data()[(i_bd)]->m_pts.data()[(i)]);
					}

				}
				
				
			}			
		}
	}

	if (m_insidePlanes.size() != 0)
	{
		for(int i=0;i<m_insidePlanes.size();i++)m_insidePlanes.data()[(i)]->caculateSingleInsidePlane(adjusts,planes.data()[(m_insidePlanes.data()[(i)]->fatherID)]);
	}

	for (int i=0;i< model_BD->size();i++)
	{
		father->m_testBD.push_back(model_BD->data()[(i)]);
	}
	for (int i=0;i< n_plane ;i++)
	if ((planes.data()[i]->m_boundarys->size() == 1  && !planes.data()[i]->m_boundarys->front()->mixBd.empty()))
	{
		
			TP_PtList *mixBD = &planes.data()[i]->m_boundarys->front()->mixBd;
			cutLongEdgeBD(planes.data()[i]->m_boundarys->front());
			for (int j = 0 ;j< mixBD->size();j++)
			{
				planes.data()[i]->Point2D_to_3D(&mixBD->data()[j]);
			}
	}
	delete []adjusts;
}
*/

ori_Type  TP_Model::testOrientation()
{
	int i,j;
	if (tpGraph_initial == NULL )return ori_none;
	
	int n_ridge=tpGraph_initial->getEdgeCount();
	ori_ridges = new int[n_ridge];for ( i=0;i< n_ridge;i++)ori_ridges[i]= -1;
//	vector<CCVector2 > ori_pools;
	vector<CmpType<double > > CmpData;
	for (i=0;i< n_ridge;i++)
	{
		G_Edge* ed=tpGraph_initial->getEdgebyID(i);

		if (ed->len < 2* aveDis)continue;
	
		if (ed->edgeType == SS_H || ed->edgeType == HS_H )
		{			
			CmpType<double > CT_num(ed->len,i);
			CmpData.push_back(CT_num);
			ori_ridges[i]=0;
		}
	}
	int n_hRidges = CmpData.size();
	if (n_hRidges == 0)return ori_none;
	qsort(&CmpData.data()[(0)],CmpData.size(),sizeof(CmpType<double >),cmp1<double>); 
//	int *f_ridgeOri = new int[n_hRidges];for (int i=0;i< n_hRidges;i++)f_ridgeOri[i]= -1;
	for (i= 0;i< n_hRidges ; i++)
	{
		int _rid = CmpData.data()[(i)].id;
		G_Edge *eg_i =tpGraph_initial->getEdgebyID(_rid);
		CCVector2 ori_i = getRidgeOri(eg_i);
		if (ori_pools.empty()) 
		{
			ori_pools.push_back(ori_i);
			ori_ridges[_rid]=0;
			continue;
		}
		
		bool f_found = false;
		double cos_ang,max_val = -9999,id = -1;
		for(j=0;j< ori_pools.size(); j++)
		{
			CCVector2 ori_pool = ori_pools.data()[(j)];
			cos_ang = cmpTwoOritations(ori_i,ori_pool);
			if (cos_ang > cos_angleSmall && cos_ang > max_val)
			{
				id=j;
				max_val = cos_ang;
				f_found =true;			
			}
		}

		if (f_found == false)
		{
			ori_pools.push_back(ori_i);
			ori_ridges[_rid]=ori_pools.size()-1;
		}
		else ori_ridges[_rid] = id;
	}

	if (ori_pools.size() == 1) return ori_single;
	else return ori_multiply;

}

void TP_Model::decideModelOri()
{
	int i;
//	m_oriType = testOrientation();
	m_oriType = ori_none;
	if (m_oriType == ori_none)
	{
		/*
		CornerDetection_BD(bd_all->front(),0.5);
		TP_PtList *outBD = &bd_all->data()[0]->corners;
		if (outBD->empty())return;

		int npt= outBD->size();
		CCVector3 pt1,pt2;
		double len_max=0,len;
		int id_max=0;
		for(int i =0; i< outBD->size();i++)
		{
			pt1 = outBD->data()[i].m_p;
			pt2 = outBD->data()[(i+1)%npt].m_p; 
			len = calDisP2P_xy_sqrt(&pt1,&pt2);
			if (len > len_max)
			{
				len_max = len;
				id_max = i;
			}
		}
		pt1 = outBD->data()[id_max].m_p;pt2 = outBD->data()[(id_max+1)%npt].m_p; 
		CCVector2 ori_new =  CCVector2(pt1.x - pt2.x, pt1.y - pt2.y)/calDisP2P_xy_sqrt(&pt1,&pt2);
		m_oriType = ori_single;
		ori_pools.push_back(ori_new);
		*/
//		CCVector2 ori_new = generateEdgeOri_byMaxProjDensity(&bd_all->front()->m_pts,2,1);
//		ori_pools.push_back(ori_new);
        int count_ori =0;
		long largestPlane =0;int id_lP=0;
		for (int i =0 ; i< n_plane; i++ )
		{

			TP_Plane *pl = planes.data()[(i)];
			if (pl->getPointCloud()->size() > largestPlane)
			{
				largestPlane = pl->getPointCloud()->size();
				id_lP = i;
			}
			if (!pl->isUnRoboustPlane   && pl->getPointCloud()->size() > 100)
			{
				long id_largest=0;
				long n_count = 0,npt_bd=0;
				for (int k = 0; k < pl->m_boundarys->size();k++)
				{
					long n_count = pl->m_boundarys->at(k)->m_pts.size();
					if (n_count > npt_bd && pl->m_boundarys->at(k)->type == OUTSIDE_EDGE)
					{
						npt_bd = n_count;
						id_largest = k;
					}
				}
				CCVector2 ori_new = generateEdgeOri_byMaxProjDensity(&pl->m_boundarys->at(id_largest)->m_pts,0.5,1);
				ori_pools.push_back(ori_new);
				IDList l_new;
				l_new.push_back(count_ori);
				pl->ori_type_set(ori_single);
				pl->ori_set(l_new);
				count_ori ++;
			}	
		}

		TP_Plane *plarP = planes.data()[(id_lP)];
		for (int i =0 ; i< n_plane; i++ )
		{

			TP_Plane *pl = planes.data()[(i)];
			if (pl->isUnRoboustPlane || pl->getPointCloud()->size() < 301)
			{
				pl->ori_type_set(ori_single);
				IDList l_new =plarP->ori_id;
				pl->ori_set(l_new);
			}
		}
		return;
	}

	for (i =0 ; i< tpGraph_initial->getEdgeCount(); i++ )
	{
		if (ori_ridges[i] == -1 )continue;
		G_Edge *eg_i =tpGraph_initial->getEdgebyID(i);
		eg_i->ori_group = ori_ridges[i];
		TP_Plane *pl;
		pl = planes.data()[(eg_i->ID_1)]; pl->ori_add(eg_i->ori_group );
		pl = planes.data()[(eg_i->ID_2)]; pl->ori_add(eg_i->ori_group );

		int id1 = eg_i->fatherID;
		if (id1 != -1)
		{
			father->tpGraph_initial->getEdgebyID(id1)->ori_group = eg_i->ori_group;
		}
		

	}
	for (i =0 ; i< n_plane; i++ )
	{
		m_ori_flags.push_back(planes.data()[(i)]->ori_get());
	}
	for (i =0 ; i< n_plane; i++ )
	{
		if (!m_ori_flags.at(i).empty()) planes.data()[(i)]->f_expanded = false;
		else planes.data()[(i)]->f_expanded = true;
	}
	

	tpGraph_initial->expansionGraphFlags(&m_ori_flags);

	for (i =0 ; i< n_plane; i++ )
	{
		TP_Plane *pl = planes.data()[(i)];
		IDList lst = m_ori_flags.data()[(i)];
		pl->ori_set(lst);

		if (lst.empty()) pl->ori_type_set(ori_none);
		else if (lst.size() == 1)
		{
			int id = lst.front();
			if(!pl->f_expanded)pl->ori_type_set(ori_single);
		    else pl->ori_type_set(ori_exSingle);

			pl->show_val = ori2double(ori_pools.data()[(id)]);
		}
		else 
		{
			if(!pl->f_expanded)pl->ori_type_set(ori_multiply);
			else pl->ori_type_set(ori_exmultiply);
		}
	}
}

void TP_Model::PrepareChildMessage()
{
	pl_As_a_Whole = new TP_Plane;
	pl_As_a_Whole->setPointCloud(getPointCloud());
	pl_As_a_Whole->aveDis = father->aveDis; 
	pl_As_a_Whole->caculatePlaneMessage(1);

	bd_all = new TP_PlaneBoundary;
	bd_all->push_back( pl_As_a_Whole->m_outsideBD);
	markModelOusideBd();
}



void TP_Model::markModelOusideBd()
{
	n_plane = planes.size();
	TP_PtList *l_all = &bd_all->front()->m_pts; if (l_all == NULL)return;

	TP_PtList *l_now;
	for(int i =0; i < l_all->size();i ++)l_all->data()[i].id_InComploop = -1;

	for(int i =0; i < n_plane;i ++)
	{
		l_now = &planes.data()[i]->m_outsideBD->m_pts;
		
		compareTwoEdges(l_all,l_now,planes.data()[i]->ID,1);
	}

}

void TP_Model::caculateM2M_relation(TP_Model *child_1,TP_Model * child_2)
{
	if (child_1->planes.size() == 1 && child_2->planes.size() == 1) return;
	
	vector <Plane_Plane_Relation *> m_stepPPR;
	vector <G_Edge *>  m_stepEgs;

	tpGraph_childs->getEdge_Multiply(child_1->id_ifIschildmodel,child_2->id_ifIschildmodel,&m_stepEgs);

	for(int i =0; i < m_stepEgs.size();i ++)
	{
		Plane_Plane_Relation *ppr_i = (Plane_Plane_Relation*) (m_stepEgs.at(i)->attr1);
		if (ppr_i->m_eg->edgeType == Step)m_stepPPR.push_back((Plane_Plane_Relation*) (m_stepEgs.at(i)->attr1));		
	}
	Wall_between_ChildModels *wcm_add = new Wall_between_ChildModels;
	wcm_add->ppr_all  = new Plane_Plane_Relation(child_1->pl_As_a_Whole,child_2->pl_As_a_Whole,NULL);  
	wcm.push_back(wcm_add);
	Plane_Plane_Relation *ppr_all= wcm_add->ppr_all;
	vector<CCVector3 > *bdPts_now1,*bdPts_now2;

	for(int i =0; i < m_stepPPR.size();i ++)
	{
		bdPts_now1 = &m_stepPPR.at(i)->bdPts_L;
		bdPts_now2 = &m_stepPPR.at(i)->bdPts_R;
		if (m_stepPPR.at(i)->isModleID_1over2)
		{
			for(int j =0 ; j < bdPts_now2->size(); j++) ppr_all->bdPts_L.push_back(bdPts_now2->at(j));
			for(int j =0 ; j < bdPts_now1->size(); j++) ppr_all->bdPts_R.push_back(bdPts_now1->at(j));
		}
		else
		{
			for(int j =0 ; j < bdPts_now1->size(); j++) ppr_all->bdPts_L.push_back(bdPts_now1->at(j));
			for(int j =0 ; j < bdPts_now2->size(); j++) ppr_all->bdPts_R.push_back(bdPts_now2->at(j));
		}
		
	}
    ppr_all->markCommonPtsBetweenTwoClouds();
	ppr_all->m_eg = new G_Edge;
	ppr_all->m_eg->edgeType = Step;
	ppr_all->m_sigma = 1;
	int npt1 = ppr_all->back_bd1.size();
	int npt2 = ppr_all->back_bd2.size();
	if (m_stepPPR.empty() || npt1 <2 || npt2 <2)return;

	double z1,z2;
	CCVector3 bb1,bb2;
	getBBofCCVector3list(&ppr_all->bdPts_L, &bb1, &bb2); z1 = bb1.z + bb2.z;
	getBBofCCVector3list(&ppr_all->bdPts_R, &bb1, &bb2); z2 = bb1.z + bb2.z;
	vector< Plane_ConnectiveEdgeList* > *newPCEs;
	newPCEs = &wcm_add->m_egs;
	if (z1 > z2)
	{
		replaceModelBdByStepEdges(ppr_all,&ppr_all->back_bd1,&m_stepPPR,&mcd,true,newPCEs);
	    replaceAnotherSide(ppr_all,true,&mcd,newPCEs);
	}
	else	
	{
		replaceModelBdByStepEdges(ppr_all,&ppr_all->back_bd2,&m_stepPPR,&mcd,false,newPCEs);
		replaceAnotherSide(ppr_all,false,&mcd,newPCEs);
	}

		
	//先按相同主方向的进行分段，在相同分段内考虑共线调整;
	for (int i =0;i < newPCEs->size();i++)
	{
		int pl_id = newPCEs->at(i)->pl_id;
		 TP_Plane *pl_now = getPlaneByID(pl_id);
		if (pl_now!= NULL)
		{
			newPCEs->at(i)->m_type = insideStep;
			pl_now->out_PCE.push_back(newPCEs->at(i));
		}
	}
	if (z1 > z2)
	{
		child_1->pl_As_a_Whole->m_markedSegments.push_back(ppr_all->ID_onlist_1);
		child_2->pl_As_a_Whole->m_markedSegments.push_back(ppr_all->ID_onlist_2);
	}
	else
	{
		child_1->pl_As_a_Whole->m_markedSegments.push_back(ppr_all->ID_onlist_2);
		child_2->pl_As_a_Whole->m_markedSegments.push_back(ppr_all->ID_onlist_1);
	}



	
}
void TP_Model::caculateModelBounduryOnWall()
{
	TP_Plane *pl_all = pl_As_a_Whole;
	vector<CCVector2i >  usedRanges =  pl_As_a_Whole->m_markedSegments;
	vector<CCVector2i >  restRanges;
	TP_PtList *bd_modelAll = &pl_As_a_Whole->m_outsideBD->m_pts;
	TP_PtList *bd =new TP_PtList;
	cutLoopIntoSegsByMarkedPts(bd_modelAll->size(),usedRanges,&restRanges);
	if (restRanges.empty())return;
	
	int sg_stID;
	for(int i_part =0; i_part < restRanges.size();i_part++)
	{
		bd->clear();
		sg_stID = restRanges.at(i_part).x;
		getPartOfPtsFromLoop(bd_modelAll,bd,restRanges.at(i_part).x,restRanges.at(i_part).y);
		int npt = bd->size();
		int plID = bd->front().comp_flag;
		int st = bd->front().id_InComploop;
		TP_Vertex *pt_now,*pt_after;
		int flag_same,len =0,id1 =0,id2;
		bool fg_dif = false,fg_end= false;

		vector <TP_ModelBDSegments > tpmbs;
		for(int i =0;i < npt-1; i++)
		{
			len ++;
			pt_after = &bd->data()[i+1];
			if ( i == (npt-2)) fg_end = true;
			if (pt_after->comp_flag != plID )fg_dif = true;
			if (!fg_dif && !fg_end)continue;
					
			TP_ModelBDSegments mbs_add;
			mbs_add.id_st= st;
			mbs_add.id_end = bd->at(i).id_InComploop;
			mbs_add.id_plane = plID;
			mbs_add.id1 = (sg_stID +id1)%bd_modelAll->size();
			mbs_add.id2 =(i+sg_stID)%bd_modelAll->size();

			if (!fg_dif && fg_end)//最后一?
			{
				mbs_add.id_end = bd->at(i+1).id_InComploop;
				mbs_add.id2 =(i+1+sg_stID)%bd_modelAll->size();
			}			

			if (len >1 )tpmbs.push_back(mbs_add);
			st = bd->at(i+1).id_InComploop;
			id1 = i+1;
			plID = pt_after->comp_flag;		
			fg_dif = false;		
			len =0;
		}
		/*if (tpmbs.size() != 1 &&  tpmbs.back().id_plane == tpmbs.front().id_plane)
		{
			tpmbs.front().id_st = tpmbs.back().id_st;
			tpmbs.front().id1 = tpmbs.back().id1 ;
			tpmbs.pop_back();
		}*/
		 TP_Plane * pl_now;
		TP_ModelBDSegments *mbs_now;
		vector <Plane_ConnectiveEdgeList*> newPCEs;
		for (int i = 0 ; i< tpmbs.size();i++)
		{
			mbs_now = &tpmbs.data()[i];
			pl_now = getPlaneByID(mbs_now->id_plane);
			if (pl_now == NULL || pl_now->ori_get().empty())continue;	
			Plane_ConnectiveEdgeList *pce_add = new Plane_ConnectiveEdgeList;
			pce_add->isPCEStepEg = false;
			vector<int> ori = pl_now->ori_get();
			getOneSideStepRidges(bd_modelAll, CCVector2i(mbs_now->id1,mbs_now->id2), &father->ori_pools, &ori, pce_add);	
			if (pce_add->isPCEStepEg)
			{
				pce_add->m_type = outsideBD;
				pl_now->out_PCE.push_back(pce_add);
				mbs_now->pce = pce_add;
			}
		}	
	}
	TP_Vertex *pt1,*pt2;
	for (int i =0; i< bd_modelAll->size();i++)
		{
			pt1 = &bd_modelAll->data()[i];
			pt2 = &bd_modelAll->data()[(i+1)%bd_modelAll->size()];
			if (pt1->comp_flag != pt2->comp_flag)
			{
				if (pt1->comp_flag == -1 || pt2->comp_flag == -1 )continue;

				TP_ModelCorner *cor_add = new TP_ModelCorner;
				cor_add->pt_l =pt1;
				cor_add->pt_r =pt2;
				father->mcd.push_back(cor_add);
				//if (cor_add->pt_l == NULL || cor_add->pt_r == NULL)continue;				
				 TP_Plane *p1= getPlaneByID(cor_add->pt_l.comp_flag);
				 TP_Plane *p2= getPlaneByID(cor_add->pt_r.comp_flag);				
				 p1->m_outsideBD->m_pts.data()[pt1->id_InComploop].id_ifisModelCorner = father->mcd.size()-1;
				 p2->m_outsideBD->m_pts.data()[pt2->id_InComploop].id_ifisModelCorner = father->mcd.size()-1;

				if (p1 == NULL || p2 == NULL)continue;		
				G_Edge *eg_now =father->tpGraph_initial->getEdge(p1->FacadeCount,p2->FacadeCount);

				if (eg_now!= NULL && eg_now->edgeType == Undecided)
				{
					Plane_Plane_Relation *ppr_now = *(father->m_ppr + eg_now->ID);
					if (ppr_now->m_sigma  <  0.3)
					{
						ppr_now->decideEdgeType();
					}				
				}
			}	
		}
}


void TP_Model::AdjustModelCorners()
{
	TP_ModelCorner *tmc_now=NULL;
	TP_PtList *MixBD1,*MixBD2;

	for (int i =0 ; i< mcd.size();i++)
	{
		tmc_now = mcd.data()[i];
		TP_Plane *p1= getPlaneByID(tmc_now->pt_l.comp_flag);
		TP_Plane *p2= getPlaneByID(tmc_now->pt_r.comp_flag);
		if (p1 == NULL || p2 == NULL)continue;
		G_Edge *eg_now =tpGraph_initial->getEdge(p1->FacadeCount,p2->FacadeCount);

		if (eg_now!= NULL && eg_now->edgeType > Step)
		{
			MixBD1 = &p1->m_outsideBD->mixBd;
			MixBD2 = &p2->m_outsideBD->mixBd;
			CornerEdgeSegment_Describer CES_D1 ,CES_D2;
			CES_D1.add_pt = CES_D2.add_pt = NULL;
			if (p1->getCornerEdgeSegment_Describer(i,&CES_D1) && p2->getCornerEdgeSegment_Describer(i,&CES_D2))
			{
				if (CES_D1.bd_in->PtType == CES_D1.rg_in->PtType  || CES_D2.bd_in->PtType == CES_D2.rg_in->PtType )continue;
				double dis_l = calDisP2P_xy_sqrt(&CES_D1.bd_in->m_p,&CES_D1.bd_out->m_p);
				double dis_r = calDisP2P_xy_sqrt(&CES_D2.bd_in->m_p,&CES_D2.bd_out->m_p);
				if (dis_l < 0.1 || dis_r < 0.1)continue;
			

				int keepPt1 = 0,keepPt2 = 0;
				CCVector3 pt1,pt2,m_bias;
				double dis1, dis2;
				if (!CES_D1.isPara && !CES_D2.isPara)
				{
					pt1 = *(LineIntersectLine(CES_D1.rg_out->m_p,CES_D1.rg_in->m_p,CES_D1.bd_out->m_p,CES_D1.bd_in->m_p));
					pt2 = *(LineIntersectLine(CES_D2.rg_out->m_p,CES_D2.rg_in->m_p,CES_D2.bd_out->m_p,CES_D2.bd_in->m_p));
					dis1 = calDisP2P_xy_sqrt(&pt1,&CES_D1.rg_in->m_p);
					dis2 = calDisP2P_xy_sqrt(&pt2,&CES_D1.rg_in->m_p);
					if (fabs(dis1)> 10 || fabs(dis2) >10)continue;
	
					m_bias = pt2- pt1;
					if (dis1 > dis2) m_bias = Vector3_lf(0, 0, 0) - m_bias;
				}
				else continue;
				p1->Point2D_to_3D(&tmc_now->pt_l);
				p2->Point2D_to_3D(&tmc_now->pt_r);
				double deltHeight = tmc_now->pt_l.m_p.z  - tmc_now->pt_r.m_p.z ;
				bool isP1BdUpper = false; //if (deltHeight < 0)isP1BdUpper = false;
		        if (deltHeight < 0)isP1BdUpper = false;
				else isP1BdUpper = true;
				//bool isIntersectPtsAccepted =false;
				int outOriTest = decideRelationshipBetweentwoNormals(CES_D1.bd_nv,CES_D2.bd_nv);
				if (outOriTest == 1)
				{	
					double dis_pt12 = calDisP2P_xy_sqrt(&pt1,&pt2);	
					CCVector3 nv_addLine; nv_addLine.x = - CES_D1.bd_nv.y; nv_addLine.y =  CES_D1.bd_nv.x;
					CCVector3 ptAss =  CES_D1.bd_in->m_p  + nv_addLine;
					if (calProPt2LineSegment_2d(&CES_D1.rg_out->m_p, &CES_D1.bd_in->m_p, &ptAss) < 0)nv_addLine = Vector3_lf(0, 0, 0) - nv_addLine;
					nv_addLine.z = 0 ;  nv_addLine  /= sqrt(nv_addLine.x * nv_addLine.x +nv_addLine.y*nv_addLine.y);

					if (CES_D1.isVertical)
					{																
						if (dis_pt12 < 2*aveDis)
						{
							if (dis1 < dis2)
							{							
								CES_D1.bd_out->m_p += m_bias ;
								CES_D1.bd_in->m_p += m_bias ;
								CES_D1.rg_in->m_p = pt2;
								CES_D2.rg_in->m_p = pt2;
								
							}
							else{						
								CES_D2.bd_out->m_p += m_bias;
								CES_D2.bd_in->m_p += m_bias;
								CES_D1.rg_in->m_p = pt1;
								CES_D2.rg_in->m_p = pt1;
							}
						}
						else 
						{
							CES_D1.rg_in->m_p = pt1;
							CES_D2.rg_in->m_p = pt2;
							
						}												
					}
					else
					{
						
						CCVector3 pt_out;
						if (dis1 < dis2)pt_out = pt2;
						else pt_out = pt1;
						bool fg_addLine = true;
						if (!CES_D1.isPara && dis_pt12 < 2*aveDis)
						{
							double dis_temp = calDisPt2LineSegment_2d(&pt_out,&CES_D1.bd_in->m_p,&CES_D2.bd_in->m_p);
							if (dis_temp < 2*aveDis)
							{
								CES_D1.rg_in->m_p = pt_out;
								CES_D2.rg_in->m_p = pt_out;
								if (dis1 < dis2)
								{		
									double dis_bd1a= calDisPt2LineSegment_2d(&CES_D1.bd_in->m_p,&CES_D2.bd_in->m_p,&CES_D2.bd_out->m_p,1);
									double dis_bd1b= calDisPt2LineSegment_2d(&CES_D1.bd_out->m_p,&CES_D2.bd_in->m_p,&CES_D2.bd_out->m_p,1);
									
									CES_D1.bd_in->m_p -= nv_addLine*dis_bd1a;
									CES_D1.bd_out->m_p -= nv_addLine * dis_bd1b;
								}
								else
								{
									double dis_bd1a= calDisPt2LineSegment_2d(&CES_D2.bd_in->m_p,&CES_D1.bd_in->m_p,&CES_D1.bd_out->m_p,1);
									double dis_bd1b= calDisPt2LineSegment_2d(&CES_D2.bd_out->m_p,&CES_D1.bd_in->m_p,&CES_D1.bd_out->m_p,1);
																	
									CES_D2.bd_in->m_p -= nv_addLine *dis_bd1a;
									CES_D2.bd_out->m_p -= nv_addLine * dis_bd1b;
								}								
								fg_addLine =false;
							}
						}
						if (fg_addLine)
						{
							CCVector3 keyPt1,keyPt2;double m_pro ;
							if (isP1BdUpper)keyPt1 = CES_D1.bd_nv *CES_D1.pro_max + CES_D1.bd_out->m_p;
							else keyPt1 = CES_D2.bd_nv*CES_D2.pro_max + CES_D2.bd_out->m_p;
							keyPt2 = keyPt1  + nv_addLine;
							
							CCVector3 pt_intersect1 = (*LineIntersectLine(CES_D1.bd_in->m_p, CES_D1.bd_out->m_p, keyPt1, keyPt2));						
							CCVector3 pt_intersect2 = (*LineIntersectLine(CES_D2.bd_in->m_p, CES_D2.bd_out->m_p, keyPt1, keyPt2));	
							CCVector3 pt_intersect3 = (*LineIntersectLine(CES_D1.rg_in->m_p, CES_D1.rg_out->m_p, keyPt1, keyPt2));						
							CCVector3 pt_intersect4 = (*LineIntersectLine(CES_D2.rg_in->m_p, CES_D2.rg_out->m_p, keyPt1, keyPt2));
							
							if (calDisP2P_xy_sqrt(&CES_D1.bd_in->m_p, &pt_intersect1) < 5 && calDisP2P_xy_sqrt(&CES_D2.bd_in->m_p, &pt_intersect2) < 5
								&& calDisP2P_xy_sqrt(&CES_D1.rg_in->m_p, &pt_intersect3) < 5 && calDisP2P_xy_sqrt(&CES_D2.rg_in->m_p, &pt_intersect4) < 5)
							{
								CES_D1.bd_in->m_p = pt_intersect1;
								CES_D2.bd_in->m_p = pt_intersect2;
								CES_D1.rg_in->m_p = pt_intersect3;
								CES_D2.rg_in->m_p = pt_intersect4;
							}

						   /* CES_D1.bd_in->m_p	= (* LineIntersectLine(CES_D1.bd_in->m_p,CES_D1.bd_out->m_p,keyPt1,keyPt2));
							CES_D2.bd_in->m_p	= (* LineIntersectLine(CES_D2.bd_in->m_p,CES_D2.bd_out->m_p,keyPt1,keyPt2));
							CES_D1.rg_in->m_p	= (* LineIntersectLine(CES_D1.rg_in->m_p,CES_D1.rg_out->m_p,keyPt1,keyPt2));
							CES_D2.rg_in->m_p	= (* LineIntersectLine(CES_D2.rg_in->m_p,CES_D2.rg_out->m_p,keyPt1,keyPt2));	*/					

						}
					}		
				}
				else
				{
					CCVector3  pt_cor = (* LineIntersectLine(CES_D1.bd_in->m_p,CES_D1.bd_out->m_p,CES_D2.bd_in->m_p,CES_D2.bd_out->m_p));
					double dis_2_ridge = calDisPt2LineSegment_2d(&pt_cor,&CES_D1.rg_in->m_p,&CES_D1.rg_out->m_p,1);
					double dis_ext1 = calDisP2P_xy_sqrt(&pt_cor, &CES_D1.rg_in->m_p);
					double dis_ext2 = calDisP2P_xy_sqrt(&pt_cor, &CES_D2.rg_in->m_p);
					if (dis_ext1 > 5 || dis_ext2 > 5)continue;
					

					if (dis_2_ridge < aveDis )
					{
						    if (dis1 < dis2)pt_cor = pt2;
							else pt_cor = pt1;
							if (calDisP2P_xy_sqrt(&pt_cor,&CES_D1.rg_in->m_p) < 5*aveDis )
							{
								CES_D1.bd_in->m_p = pt_cor;
								CES_D1.rg_in->m_p = pt_cor;
								CES_D2.bd_in->m_p = pt_cor;
								CES_D2.rg_in->m_p = pt_cor;			
							}							
					}
					else
					{						
						if (isP1BdUpper)
						{						     
							{
								CCVector3 keyPt1,keyPt2;double m_pro ;
								keyPt1 = CES_D1.bd_nv * CES_D1.pro_max + CES_D1.bd_out->m_p;

								CCVector3 nv_addLine; nv_addLine.x = - CES_D1.bd_nv.y; nv_addLine.y =  CES_D1.bd_nv.x;
								CCVector3 ptAss =  CES_D1.bd_in->m_p  + nv_addLine;
								if (calProPt2LineSegment_2d(&CES_D1.rg_out->m_p,&CES_D1.bd_in->m_p,&ptAss) < 0  )nv_addLine = Vector3_lf(0,0,0)- nv_addLine;
								nv_addLine.z = 0 ;  nv_addLine  /= sqrt(nv_addLine.x * nv_addLine.x +nv_addLine.y*nv_addLine.y);
								keyPt2 = keyPt1  + nv_addLine;
								
								if (calDisP2P_xy_sqrt(&CES_D1.bd_in->m_p,&keyPt1) >  3 || calDisP2P_xy_sqrt(&CES_D2.bd_in->m_p,&pt_cor) >  3)
									continue;												
								CCVector3 pt_new = (* LineIntersectLine(CES_D1.rg_in->m_p,CES_D1.rg_out->m_p,keyPt1,keyPt2));




								if (calDisP2P_xy_sqrt(&pt_new,&CES_D1.rg_in->m_p)< 3 /*&& calProPt2LineSegment_2d(&pt_new,&CES_D1.bd_in->m_p,&ptAss ) > 0*/)
								{
									CES_D1.bd_in->m_p= keyPt1;			
									CES_D2.bd_in->m_p	= pt_cor;   	
									CES_D1.rg_in->m_p	= pt_new ;  
									CES_D2.rg_in->m_p	= pt_new ;  
									
									CES_D2.add_pt = new TP_Vertex;
									CES_D2.add_pt->m_p = keyPt1;
									CES_D2.add_pt->ID = -1;	
									CES_D2.add_pt->PtStab = Stable;
								}	
								else continue;
							}
						}
						else
						{
							CCVector3 keyPt1,keyPt2;double m_pro ;
							keyPt1 = CES_D2.bd_nv * CES_D2.pro_max + CES_D2.bd_out->m_p;

							CCVector3 nv_addLine; nv_addLine.x = - CES_D2.bd_nv.y; nv_addLine.y =  CES_D2.bd_nv.x;
							CCVector3 ptAss =  CES_D2.bd_in->m_p  + nv_addLine;
							if (calProPt2LineSegment_2d(&CES_D2.rg_out->m_p, &CES_D2.bd_in->m_p, &ptAss) < 0)nv_addLine = Vector3_lf(0, 0, 0) - nv_addLine;
							nv_addLine.z = 0 ;  nv_addLine  /= sqrt(nv_addLine.x * nv_addLine.x +nv_addLine.y*nv_addLine.y);
							keyPt2 = keyPt1  + nv_addLine;

							if (calDisP2P_xy_sqrt(&CES_D2.bd_in->m_p,&keyPt1) >  3 || calDisP2P_xy_sqrt(&CES_D1.bd_in->m_p,&pt_cor) >  3)
								continue;							
							CCVector3 pt_new = (* LineIntersectLine(CES_D1.rg_in->m_p,CES_D1.rg_out->m_p,keyPt1,keyPt2));
							if (calDisP2P_xy_sqrt(&pt_new,&CES_D1.rg_in->m_p)   < 3 /* && calProPt2LineSegment_2d(&pt_new,&CES_D1.bd_in->m_p,&ptAss ) > 0*/)
							{
								CES_D2.bd_in->m_p	= keyPt1;
								CES_D1.bd_in->m_p	= pt_cor;
								CES_D1.rg_in->m_p	= pt_new ;
								CES_D2.rg_in->m_p	= pt_new ;
								
								CES_D1.add_pt = new TP_Vertex;
								CES_D1.add_pt->m_p = keyPt1;
								CES_D1.add_pt->ID = -1;	
								CES_D1.add_pt->PtStab = Stable;
							}
							else continue;
						}
					}
				}
				if (CES_D1.add_pt != NULL && CES_D1.id_ifAddPts!= -1)
				{
					TP_PtList temp = *MixBD1;
					MixBD1->clear();
					for (int i_pt =0 ;i_pt < CES_D1.id_ifAddPts ;i_pt++)
					{
						MixBD1->push_back(temp.at(i_pt));
					}				
				
					MixBD1->push_back(*CES_D1.add_pt);
					for (int i_pt =CES_D1.id_ifAddPts ;i_pt < temp.size() ;i_pt++)
					{
						MixBD1->push_back(temp.at(i_pt));
					}
				}
				if (CES_D2.add_pt != NULL && CES_D2.id_ifAddPts!= -1)
				{
					TP_PtList temp = *MixBD2;
					MixBD2->clear();
					for (int i_pt =0 ;i_pt < CES_D2.id_ifAddPts ;i_pt++)
					{
						MixBD2->push_back(temp.at(i_pt));
					}
					
					MixBD2->push_back(*CES_D2.add_pt);
					for (int i_pt =CES_D2.id_ifAddPts ;i_pt < temp.size() ;i_pt++)
					{
						MixBD2->push_back(temp.at(i_pt));
					}
				}

				CES_D1.rg_in->PtStab = CES_D2.rg_in->PtStab = CES_D1.bd_in->PtStab = CES_D2.bd_in->PtStab =Stable;
				CES_D1.rg_in->onBD = CES_D2.rg_in->onBD = CES_D1.bd_in->onBD = CES_D2.bd_in->onBD =true;
				CES_D1.bd_in->ID= CES_D2.bd_in->ID = -2;
				refreshTP_ListByDeleteFlag(MixBD1);
				refreshTP_ListByDeleteFlag(MixBD2);
				
			}
		}		
	}

}

void TP_Model::findPrimitivesInModel()
{
	Graph *tp_model = tpGraph_initial;
	int n_edge = tp_model->getEdgeCount();
	TP_Plane *pl1, *pl2;;
	for (int i = 0; i < n_edge; i++)
	{
		G_Edge *eg = tp_model->getEdgebyID(i);
		if (eg->edgeType != SS_H)continue;

		pl1 = planes.at(eg->ID_1);
		pl2 = planes.at(eg->ID_2);
		if (is_normal_Tw_outside(pl1->centerPt, CCVector3(pl1->m_a, pl1->m_b, pl1->m_c), eg->p1->m_p, eg->p2->m_p)
			&& is_normal_Tw_outside(pl2->centerPt, CCVector3(pl2->m_a, pl2->m_b, pl2->m_c), eg->p1->m_p, eg->p2->m_p))//convex
		{
			if (eg->p1->i_loop == eg->p2->i_loop && eg->p1->i_loop == -1)//type 1
			{
				printf("Find a gable");
			}
			if (eg->p1->i_loop == eg->p2->i_loop && eg->p1->i_loop == 3)//type 2
			{

			}
		}

	}
}
