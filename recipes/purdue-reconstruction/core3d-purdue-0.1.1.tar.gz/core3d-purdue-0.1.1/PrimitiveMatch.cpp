//#include "stdafx.h"
#include "PrimitiveMatch.h"

PrimitiveMatch::PrimitiveMatch()
{
	detect_Shed = true;
	detect_Flat = true;
	detect_Gable = true;
	detect_Gambrel = false;
	detect_Hipped = true;
	detect_Mansard = false;

	g_Gable = NULL;
	g_Gambrel = NULL;
	g_Hipped = NULL;
	g_Mansard = NULL;


}


void PrimitiveMatch::InitialMatch(TP_Model *md)
{
	m_model = md;

	n_pls = md->tpGraph_initial->getVertexCount();
	n_for_pri = n_pls;
	int n_edges = md->tpGraph_initial->getEdgeCount();
	
	flag_used = new int[n_pls]; memset(flag_used, 0, sizeof(int)*n_pls);
	
	for (int i = 0; i < n_pls; i++)
	{
		if (md->planes.at(i)->isUnRoboustPlane)
		{
			flag_used[i] = -1;
			n_for_pri--;
			continue;
		}

		if (md->tpGraph_initial->getDegreeOfaVertex_noneStep(i) == 0)
		{
			if (md->planes.at(i)->m_c > cos(3 * PI / 180.0))
			{
				flag_used[i] = -1;
			}
			else flag_used[i] = -2;
			n_for_pri--;
		}


	}

	m_Graph = new Graph;
	m_Graph->graphInitial(n_pls);
	for (long i = 0; i < n_pls; i++)
	{
		TP_Plane *pl = md->planes.at(i);
		if (pl->m_type == H) m_Graph->setVertexType(i,0);
		else m_Graph->setVertexType(i, 1);
	}

	for (long i = 0; i < n_edges; i++)
	{
		G_Edge * eg = md->tpGraph_initial->getEdgebyID(i);
		int egType = 2;
		if (eg->edgeType == NotExist)continue;
	
		if (eg->edgeType == SS_H )//|| eg->edgeType == HS_H)
		{
			TP_Plane *pl1 = md->planes.at(eg->ID_1);
			TP_Plane *pl2 = md->planes.at(eg->ID_2);
			if (is_normal_Tw_outside(pl1->centerPt, CCVector3(pl1->m_a, pl1->m_b, pl1->m_c), eg->p1->m_p, eg->p2->m_p)
				&& is_normal_Tw_outside(pl2->centerPt, CCVector3(pl2->m_a, pl2->m_b, pl2->m_c), eg->p1->m_p, eg->p2->m_p))
				egType = 0;
			else egType = 2;
		}
		else if (eg->edgeType == SS_S_convex)// ||egType == SS_S_concave )
		{
			TP_Plane *pl1 = md->planes.at(eg->ID_1);
			TP_Plane *pl2 = md->planes.at(eg->ID_2);
			
			if (is_normal_Tw_outside(pl1->centerPt, CCVector3(pl1->m_a, pl1->m_b, pl1->m_c), eg->p1->m_p, eg->p2->m_p)
				&& is_normal_Tw_outside(pl2->centerPt, CCVector3(pl2->m_a, pl2->m_b, pl2->m_c), eg->p1->m_p, eg->p2->m_p))
				egType = 1;
			else egType = 2;
		}
		else egType = 2;

		if (egType != 2)
		{
			m_Graph->insert_Edge_withType(eg->ID_1, eg->ID_2,egType);
			m_Graph->setEdgeType(eg->ID_1, eg->ID_2, eg->edgeType);
		}		
	}
	
	//  plane / graph node :  0 for H, 1 for S;
	//  edge  / graph edge :  0 for H and convex, 1 for S and convex, 2 for the rest;
	if (detect_Mansard)
	{
		g_Mansard = new Graph;
		g_Mansard->graphInitial(8);
		for (int i = 0; i < 8; i++)g_Mansard->setVertexType(i, 1);
		g_Mansard->insert_Edge_withType(0, 1, 1);
		g_Mansard->insert_Edge_withType(0, 3, 1);
		g_Mansard->insert_Edge_withType(0, 4, 0);

		g_Mansard->insert_Edge_withType(1, 2, 1);
		g_Mansard->insert_Edge_withType(1, 3, 0);
		g_Mansard->insert_Edge_withType(1, 5, 0);

		g_Mansard->insert_Edge_withType(2, 3, 1);
		g_Mansard->insert_Edge_withType(2, 6, 0);

		g_Mansard->insert_Edge_withType(3, 7, 0);

		g_Mansard->insert_Edge_withType(4, 5, 1);
		g_Mansard->insert_Edge_withType(4, 6, 1);
		g_Mansard->insert_Edge_withType(5, 6, 1);
		g_Mansard->insert_Edge_withType(6, 7, 1);

	}
	if (detect_Hipped)
	{
		g_Hipped = new Graph;
		g_Hipped->graphInitial(4);
		for (int i = 0; i < 4; i++)g_Hipped->setVertexType(i, 1);
		g_Hipped->insert_Edge_withType(0, 1, 1);
		g_Hipped->insert_Edge_withType(0, 3, 1);
		g_Hipped->insert_Edge_withType(1, 2, 1);
		g_Hipped->insert_Edge_withType(1, 3, 0);
		g_Hipped->insert_Edge_withType(2, 3, 1);

	}
	if (detect_Gambrel)
	{
		
		Graph *g_Gambrel = new Graph;
		g_Gambrel->graphInitial(4);
		for (int i = 0; i < 4; i++)g_Gambrel->setVertexType(i, 1);
		g_Gambrel->insert_Edge_withType(0, 1, 0);
		g_Gambrel->insert_Edge_withType(1, 2, 0);
		g_Gambrel->insert_Edge_withType(2, 3, 0);
	}

	if (detect_Gable)
	{
		Graph *g_Gable = new Graph;
		g_Gable->graphInitial(2);
		g_Gable->setVertexType(0, 1); g_Gable->setVertexType(1, 1);
		g_Gable->insert_Edge_withType(0, 1, 0);

	}
}

int PrimitiveMatch::do_search()
{
	int n_pri = 0;
	n_pri = do_search_node_four();
	n_pri += do_search_node_two();
	n_pri += do_search_node_one();
	return n_pri;
}

void get_child_graph(Graph* all, Graph* cld, IDList m_vertex)
{
	int n_v = m_vertex.size();
	G_Edge *eg = NULL;
	for (int i = 0; i < n_v; i++)
		for (int j = 0; j < n_v; j++)
	{
		eg = all->getEdge(m_vertex.at(i), m_vertex.at(j));
		if (eg != NULL)
		{
			cld->insert_Edge_withType(i, j, eg->m_type);
			cld->setEdgeType(i, j, eg->edgeType);
		}
	}

}
bool check_Gambrel(G_Edge *g1, G_Edge *g2, G_Edge *g3)
{
	if (fabs(g2->len) < 0.5) return false;
	if (!(fabs(g1->len / g2->len) > 0.5 && fabs(g1->len / g2->len) < 2)) return false;
	if (!(fabs(g3->len / g2->len) > 0.5 && fabs(g3->len / g2->len) < 2)) return false;

	CCVector3 p1, p2, p3, p4, p5, p6;
	p1 = g1->p1->m_p; p2 = g1->p2->m_p;
	p2 = g2->p1->m_p; p3 = g2->p2->m_p;
	p4 = g3->p1->m_p; p5 = g3->p2->m_p;

	if (IsParallelLines(p1, p2, p3, p4) && IsParallelLines(p1, p2, p5, p6))return true;
	else return false;
	

}


int PrimitiveMatch::do_search_node_four()
{
	if (!detect_Gambrel  && !detect_Hipped || n_for_pri < 4) return 0;
	
	int n_prim = 0;
	Graph *cmp = new Graph;
	
	int v_1, v_2, v_3, v_4;
	IDList ids;
//	if (detect_Hipped )
	{
		for (int v_1 = 0; v_1 < n_pls; v_1++)
		{
			if (flag_used[v_1] != 0)continue;
			for (int v_2 = v_1+1 ; v_2 < n_pls; v_2++)
			{
				if (flag_used[v_2] != 0 || flag_used[v_1] != 0)continue;
				for (int v_3 = v_2 + 1; v_3 < n_pls; v_3++)
				{
					if (flag_used[v_3] != 0 || flag_used[v_2] != 0)continue;
					for (int v_4 = v_3 + 1; v_4 < n_pls; v_4++)
					{
						if (flag_used[v_4] != 0 || flag_used[v_3] != 0)continue;
						ids.clear();
						ids.push_back(v_1); ids.push_back(v_2); ids.push_back(v_3); ids.push_back(v_4);
						
						cmp->graphInitial(4);
						get_child_graph(m_Graph, cmp, ids);
						if (cmp->getEdgeCount() != 5 && cmp->getEdgeCount() != 3)continue;
						else if (cmp->getEdgeCount() == 5)
						{
							// 4 vertex, 2,3,2,3, max 5 edge, enough to make sure a Hipped;	
							bool flag_error = false;
							CCVector3 pt1, pt2, pt3, pt4;
							int id1 = -1, id2 = -1, id3 = -1, id4 = -1;
							int n_vDeg = 0;
							for (int i = 0; i < 4; i++)// get the order of planes
							{
								n_vDeg = cmp->getDegreeOfaVertex(i);
								if (n_vDeg == 1)
								{
									flag_error = true; break;
								}
								if (n_vDeg == 2)
								{
									if (id1 == -1)id1 = i;
									else if (id2 == -1)id2 = i;
									else
									{
										flag_error = true; break;
									}
								}
								else
								{
									if (id3 == -1)id3 = i;
									else if (id4 == -1)id4 = i;
									else
									{
										flag_error = true; break;
									}
								}
							}

							if (flag_error) continue;

							id1 = ids.at(id1); id2 = ids.at(id2); id3 = ids.at(id3); id4 = ids.at(id4);
							Primitive_infor_Hipped hip;
							{
								hip.nodes_ids[0] = id1; hip.nodes_ids[1] = id3; hip.nodes_ids[2] = id2; hip.nodes_ids[3] = id4;
								hip.ridge_ids[0] = m_model->tpGraph_initial->getEdge(id1, id3)->ID;
								hip.ridge_ids[1] = m_model->tpGraph_initial->getEdge(id1, id4)->ID;
								hip.ridge_ids[2] = m_model->tpGraph_initial->getEdge(id3, id2)->ID;
								hip.ridge_ids[3] = m_model->tpGraph_initial->getEdge(id3, id4)->ID;
								hip.ridge_ids[4] = m_model->tpGraph_initial->getEdge(id2, id4)->ID;
							}

							if (hip.ridge_ids[0] != -1 && hip.ridge_ids[1] != -1 && hip.ridge_ids[2] != -1
								&& hip.ridge_ids[3] != -1 && hip.ridge_ids[4] != -1)
							{
								//printf("find a Gambrel\n");
								hips.push_back(hip);
							}


							n_prim++;
							bool flag_is_Mansard = true;
							if (detect_Mansard)
							{
								G_Edge *eg_now = NULL;
								int id1, id2;
								for (int i = 0; i < 5; i++)
								{
									eg_now = cmp->getEdgebyID(i);
									id1 = ids.at(eg_now->ID_1);
									id2 = ids.at(eg_now->ID_2);
									eg_now = m_model->tpGraph_initial->getEdge(id1, id2);
									if (eg_now->p1->i_loop < 3 && eg_now->p1->i_loop < 3)
									{
										flag_is_Mansard = false;
										break;
									}
								}
								if (flag_is_Mansard)
								{
									printf("find a Mansard\n"); 
								}
							}

							if (!flag_is_Mansard)
							{
								for (int i = 0; i < 4; i++)
								{
									printf("find a Hipped\n");									
								}
							}
							flag_used[v_1] = flag_used[v_2] = flag_used[v_3] = flag_used[v_4] = -4;
						}
						else
						{
						//1 2 2 1, 3 edges
						if (cmp->getEdgebyID(0)->edgeType == cmp->getEdgebyID(1)->edgeType
								&& cmp->getEdgebyID(1)->edgeType == cmp->getEdgebyID(2)->edgeType
								&& cmp->getEdgebyID(1)->edgeType == SS_H)
							{
								bool flag_error = false;
								CCVector3 pt1, pt2, pt3, pt4;
								int id1= -1, id2 = -1, id3 = -1, id4 = -1;
								int n_vDeg = 0;
								for (int i = 0; i < 4; i++)// get the order of planes
								{
									n_vDeg = cmp->getDegreeOfaVertex(i);
									if (n_vDeg == 3)
									{
										flag_error = true; break;
									}
									if (n_vDeg == 1) 
									{
										if (id1 == -1)id1 = i;
										else if (id2 == -1)id2 = i;
										else
										{
											flag_error = true; break;
										}
									}
									else
									{
										if (id3 == -1)id3 = i;
										else if (id4 == -1)id4 = i;
										else
										{
											flag_error = true; break;
										}
									}
								}

								if (flag_error) continue;
								
								id1 = ids.at(id1); id2 = ids.at(id2); id3 = ids.at(id3); id4 = ids.at(id4);
								Primitive_infor_Gambrel gam;
								G_Edge *eg_now1 = cmp->getEdge(id1, id3);
								G_Edge *eg_now2 = cmp->getEdge(id1, id4);
								if (eg_now1 != NULL && eg_now2 == NULL)
								{
									gam.nodes_ids[0] = id1; gam.nodes_ids[1] = id3; gam.nodes_ids[2] = id4; gam.nodes_ids[3] = id2;

									G_Edge *g1, *g2, *g3;
									g1 = m_model->tpGraph_initial->getEdge(id1, id3);
									g2 = m_model->tpGraph_initial->getEdge(id3, id4);
									g3 = m_model->tpGraph_initial->getEdge(id4, id2);
									if (g1 == NULL || g1 == NULL || g1 == NULL)continue;
								    if (!check_Gambrel(g1,g2,g3)) continue;

									gam.ridge_ids[0] = g1->ID;
									gam.ridge_ids[1] = g2->ID;
									gam.ridge_ids[2] = g3->ID;
									if (gam.ridge_ids[0] != -1 && gam.ridge_ids[1] != -1 && gam.ridge_ids[2] != -1)
									{
										//printf("find a Gambrel\n");
										gams.push_back(gam);
										n_prim++;
										flag_used[v_1] = flag_used[v_2] = flag_used[v_3] = flag_used[v_4] = -4;
									}
								}
								else if (eg_now1 == NULL && eg_now2 != NULL)
								{
									gam.nodes_ids[0] = id1; gam.nodes_ids[1] = id4; gam.nodes_ids[2] = id3; gam.nodes_ids[3] = id2;
									G_Edge *g1, *g2, *g3;
									g1 = m_model->tpGraph_initial->getEdge(id1, id4);
									g2 = m_model->tpGraph_initial->getEdge(id4, id3);
									g3 = m_model->tpGraph_initial->getEdge(id3, id2);
									if (g1 == NULL || g1 == NULL || g1 == NULL)continue;
									if (!check_Gambrel(g1, g2, g3)) continue;
									gam.ridge_ids[0] = g1->ID;
									gam.ridge_ids[1] = g2->ID;
									gam.ridge_ids[2] = g3->ID;
									if (gam.ridge_ids[0] != -1 && gam.ridge_ids[1] != -1 && gam.ridge_ids[2] != -1)
									{
										//printf("find a Gambrel\n");
										gams.push_back(gam);
										n_prim++;
										flag_used[v_1] = flag_used[v_2] = flag_used[v_3] = flag_used[v_4] = -4;
									}
								}
								
								
								
							}								
							
						}
						
					}
				}
			}
		}

	}
	n_for_pri -= (n_prim * 4);
	return n_prim;
}
int PrimitiveMatch::do_search_node_two()
{
	if (!detect_Gable || n_for_pri < 2)return 0;
	int n_prim = 0, v_1, v_2;
	int *f_use_temp = new int[n_pls]; memset(f_use_temp, 0, sizeof(int)*n_pls);

	for (int v_1 = 0; v_1 < n_pls; v_1++)
	{
		if (flag_used[v_1] != 0)continue;
		for (int v_2 = v_1 + 1; v_2 < n_pls; v_2++)
		{
			if (flag_used[v_2] != 0 || flag_used[v_1] != 0)continue;

			G_Edge *eg_now = m_Graph->getEdge(v_1, v_2);
			if (eg_now == NULL)continue;

			if (eg_now->m_type == 0 && m_Graph->getVertexbyID(v_1)->m_type == 1 && m_Graph->getVertexbyID(v_2)->m_type == 1)
			{
				Primitive_infor_Gable gab;
				gab.nodes_ids[0] = v_1;
				gab.nodes_ids[1] = v_2;
				gab.ridge_id = eg_now->ID;
				gabs.push_back(gab);
				//printf("find a Gabled, plane 1 : %d plane 2:%d\n",v_1,v_2);
				f_use_temp[v_1] = f_use_temp[v_2] = 1;
				n_prim++;
			}

		}
	}

	for (int i = 0; i < n_pls; i++)
	{
		if (f_use_temp[i] == 1)
			flag_used[i] = -3;
	}

	return n_prim;
}
int PrimitiveMatch::do_search_node_one()
{
	if (!detect_Flat || !detect_Shed)return 0;
	int n_prim = 0;

	for (int i = 0; i < n_pls; i++)
	{
		if (flag_used[i] == 0 || flag_used[i] == -2)
		{
			n_prim++;
			if (m_model->planes.at(i)->m_c > cos(3 * PI / 180.0))
			{
				flats.push_back(i);
				//printf("find a Flat\n");
			}
			else
			{
				sheds.push_back(i);
				//printf("find a Shed\n");
			}

		}
		else if (flag_used[i] == -1)
		{
			flats.push_back(i);
			//printf("find a Flat \n");
		}
	}



	return n_prim;
}