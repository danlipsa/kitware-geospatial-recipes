//#include "stdafx.h"
#include "Plane_Plane_Relationship.h"

bool  getBdListbetweenOnePlaneAndAll(TP_Plane *p1,ccPointCloud *c_comb,TP_PtList *back_bd)
{
	int n_bdComb=0,nbd_p1=1;
	TP_PlaneBoundary *bdComb=generateEdge(c_comb,p1->alpha_scale,&n_bdComb);
	TP_PlaneBoundary *bd_p1_new = p1->m_boundarys;
	float m_alpha = p1->alpha_scale;
	while (n_bdComb > 1 || nbd_p1>1)
	{
		bdComb->clear();
		if (m_alpha > p1->alpha_scale)
		{
			bd_p1_new->clear();
		}
		n_bdComb=nbd_p1=0;
		m_alpha *= 2;
		bdComb=generateEdge(c_comb,m_alpha,&n_bdComb);
		bd_p1_new=generateEdge(p1->getPointCloud(),m_alpha,&nbd_p1);
		if (bdComb == NULL  || bd_p1_new == NULL)return false;
	}
	if (bdComb == NULL  || bd_p1_new == NULL)return false;
	
	TP_PlaneBoundary bd_get;
	TP_PtList *plist=NULL,*plistComb=NULL;
	//plist = &p1->m_outsideBD->m_pts;
	for(int i=0;i<bd_p1_new->size();i++)
	{
		if (bd_p1_new->at(i)->type == OUTSIDE_EDGE)
		{
			plist=&(bd_p1_new->data()[i]->m_pts);break;
		}
	}
	for(int i=0;i<bdComb->size();i++)
	{
		if (bdComb->at(i)->type == OUTSIDE_EDGE)
		{
			plistComb=&(bdComb->data()[i]->m_pts);break;
		}
	}
	if (plistComb == NULL || plistComb->size() < 2) return false;	
	compareEdgeLists(plistComb,plist,&bd_get);
	if (bd_get.size() == 0)return false;

	int id_get =0;
	if (bd_get.size() > 1)//含有多个链,取最长的链;
	{
		int n_seg, n_seg_max;
		n_seg_max = bd_get.front()->m_pts.size();
		for (int i= 1;i< bd_get.size();i++ )
		{
			n_seg = bd_get.data()[i]->m_pts.size();
			if (n_seg > n_seg_max)
			{
				n_seg_max = n_seg;
				id_get = i;
			}
		}
	}	
	TP_PtList *l_now = &bd_get.data()[id_get]->m_pts;
	for (int i = 0 ; i < l_now->size();i++ )
	{
		int id_pt = findPtInPtList(&p1->m_outsideBD->m_pts,l_now->at(i).m_p);
		if (id_pt== -1)continue;
		if (i == 0 && id_pt != 0)
		{
			back_bd->push_back(p1->m_outsideBD->m_pts.at(id_pt -1));
		}		
		l_now->data()[i].ID = id_pt;back_bd->push_back(l_now->at(i));
		if (i == l_now->size()-1 && id_pt != p1->m_outsideBD->m_pts.size()-1)
		{
			int id_add_back = (id_pt +1)%p1->m_outsideBD->m_pts.size();
			back_bd->push_back(p1->m_outsideBD->m_pts.at(id_add_back));
		}
		
	}


	//(*back_bd) = bd_get.data()[id_get]->m_pts;
	return true;

}
CCVector2i getBdIDofRidgeEnds(TP_Plane *pl,TP_PtList *m_list,CCVector3 m_sPt,CCVector3 m_nv,float disThreshold)
{
	int npt = m_list->size();
	double dis,pro,pro_min = -1 ,pro_max = -1;
	CCVector2i m_back; m_back.x =m_back.y = -1;
	
	for (int i=0;i < npt ; i++)
	{
		pl->Point2D_to_3D(&m_list->data()[i]);
		CCVector3 pt = m_list->data()[i].m_p;
		

		pro=calProDis_P2L_3d(&m_sPt,&m_nv,&pt);
		dis=calDisP2P_2(&m_sPt,&pt);
		dis= dis-pro*pro;
		
		if (dis < disThreshold )
		{
			if ( m_back.x == -1) m_back.x = i;			
			m_back.y = i;
		}
	}


	return m_back;
}
/*
CCVector2i getBdIDofStepEdgeEnds(TP_Plane *pl,TP_PtList *m_list,float disThreshold)//到另外一个面的距离是否太大;
{
	int npt = m_list->size();
	double dis,pro,pro_min = -1 ,pro_max = -1;
	CCVector2i m_back; m_back.x =m_back.y = -1;

	for (int i=0;i < npt ; i++)
	{
		pl->Point2D_to_3D(&m_list->data()[i]);
		CCVector3 pt = m_list->data()[i].m_p;


		pro=calProDis_P2L_3d(&m_sPt,&m_nv,&pt);
		dis=calDisP2P_2(&m_sPt,&pt);
		dis= dis-pro*pro;

		if (dis < disThreshold )
		{
			if ( m_back.x == -1) m_back.x = i;			
			m_back.y = i;
		}
	}


	return m_back;
}*/
void replacePartOfList(TP_PtList *m_src,TP_PtList *m_add,CCVector2i m_place,TP_PtList *dst)// if dst == NULL, then m_src is replaced.
{
	if (m_place.x == -1 ) return;
//	assert(m_place.x < m_src->size() && m_place.x >= 0 && m_place.y < m_src->size() && m_place.y >= 0 );
	TP_PtList m_src_copy = (*m_src);
	dst->clear();
	TP_PtList m_temp;
	//dst->clear();
	int l_id,r_id,l_id_mix,r_id_mix;
	l_id= m_place.x; r_id = m_place.y;
	l_id_mix =findIDinList(&m_src_copy,l_id,0,m_src_copy.size());
	r_id_mix =findIDinList(&m_src_copy,r_id,0,m_src_copy.size());
	int len = m_src_copy.size();

	if (l_id_mix == -1  || r_id_mix == -1)return;

	getPartOfPtsFromLoop(&m_src_copy,dst,(r_id_mix+1)%len,(l_id_mix-1+len)%len);
	for (int i=0;i < m_add->size();i++)dst->push_back(m_add->at(i));
}

bool caculateRelatationBetwweenLoopsAndEdge(TP_PtList *m_bd, CCVector3 l_Pt, CCVector3 l_nv,CCVector2i *Id_onlist,CCVector2 *m_pro)
{
	int npt = m_bd->size();
	double dis, pro,dis1,pro_min= 999999.0,pro_max= -999999.0;
	CCVector3 pt_now;
	int i,id1,id2; id1 = id2 = -1;
	double *m_data = new double[npt];
	for (i=0;i<npt;i++)
	{
		pt_now = m_bd->data()[i].m_p;
		pro = calProDis_P2L_3d(&l_Pt,&l_nv,&pt_now);
		dis1 = calDisP2P_xyz_sqrt(l_Pt,pt_now);
		dis = sqrt(dis1*dis1 - pro*pro+0.00001);
		m_data[i] = dis *dis;

		if (dis < 1)
		{
			if (pro < pro_min){pro_min = pro; id1 = i;}
			if (pro > pro_max){pro_max = pro; id2 = i;}
		}
	}
	if (id1 == -1 || id2 == -1)return false;

	int id_min = fmin(id1,id2);
	int id_max = fmax(id1,id2);
	double in_sigama=0,out_sigama=0;

	for (i=0;i<id_min;i++)out_sigama += fabs(m_data[i]);

	for (i=id_min;i<id_max;i++) in_sigama += fabs(m_data[i]);

	for (i=id_max;i<m_bd->size();i++)out_sigama += fabs(m_data[i]);

	in_sigama= (in_sigama / (id2-id1+1))  ;
	out_sigama= (out_sigama / (npt-(id2-id1+1)));
	delete []m_data;

	//认为内部面为小面，故屋脊线端点标记与边界链方向相反，这样就与常规方法一致了;
	if (in_sigama  <  out_sigama){Id_onlist->x = id_min;Id_onlist->y  = id_max;}
	else{Id_onlist->x = id_max;Id_onlist->y = id_min;}

	m_pro->x  = calProDis_P2L_3d(&l_Pt,&l_nv,&m_bd->data()[Id_onlist->x].m_p);
	m_pro->y  = calProDis_P2L_3d(&l_Pt,&l_nv,&m_bd->data()[Id_onlist->y].m_p);

	dis = fabs(m_pro->y-m_pro->x);
	if ( dis < 1)return false;
	else return true;

}

void testConsistencybetweenRidgeandPlanes()
{
	//ptInRectCheck
}
//void decideRidgeEndsByBothClouds(TP_Plane *m_p1,TP_Plane *m_p2,CCVector3 r_para,G_Edge *m_eg)
void decideRidgeEndsByBothClouds(TP_PtList *bd_all,CCVector3 r_para,G_Edge *m_eg)
{
	int npt = bd_all->size();
	CCVector3 pt1,pt2;
	double temp1,temp2;
	vector <CCVector3> interSectPts;

	for(int i = 0; i< npt ;i++)
	{
		pt1 = bd_all->data()[i].m_p;
		pt2 = bd_all->data()[(i+1)%npt].m_p;
		if (calDisP2P_xyz_sqrt(pt1,pt2) < 0.05)continue;//重复点会出问题;
		
		temp1 = r_para.x *pt1.x + r_para.y *pt1.y + r_para.z;
		temp2 = r_para.x *pt2.x + r_para.y *pt2.y + r_para.z;
		CCVector3 pt_intSect;
		if (temp1 * temp2 < 0)
		{
			double m_t = r_para.x *(pt2.x - pt1.x) +  r_para.y *(pt2.y - pt1.y);
			m_t = -temp1/m_t;
			pt_intSect.x = pt1.x + m_t*(pt2.x - pt1.x);
			pt_intSect.y = pt1.y + m_t*(pt2.y - pt1.y);
			pt_intSect.z = 0;
			interSectPts.push_back(pt_intSect);
		}
	}

	 npt  = interSectPts.size();
	 if (npt < 2)return;

	 double len = 0,lenMax= 0;
	 int maxID = -1;
	 for(int i = 0; i< npt ;i++)
	 {
		 pt1 = interSectPts.data()[i];
		 pt2 = interSectPts.data()[(i+1)%npt];
		 len = calDisP2P_xyz_sqrt(pt1,pt2);
		 if (len > lenMax)
		 {
			 lenMax = len;
			 maxID = i;
		 }
	 }
	 m_eg->p1 = new TP_Vertex; m_eg->p2 = new TP_Vertex;
	 m_eg->p1->m_p = interSectPts.data()[maxID];
	 m_eg->p2->m_p = interSectPts.data()[(maxID+1)%npt];
     m_eg->edgeType = SS_S_convex;
}


CCVector2 caculateCloudRanges(TP_Plane *pl,CCVector3 r_srcPt,CCVector3 r_nv)
{
	CCVector2 m_return(99999.0,-99999.0);
	TP_PtList *plist = &pl->m_outsideBD->m_pts;  
	
	for(int i = 0; i< plist->size(); i++)
	{
		double pro = calProDis_P2L_3d(&r_srcPt,&r_nv,&plist->data()[i].m_p);
		if (pro < m_return.x)m_return.x = pro;
		if (pro > m_return.y)m_return.y = pro;
	}

	assert (m_return.x < m_return.y);

	return m_return;
}
int divideCloudsByline_2D(CCVector3 proj,ccPointCloud *pl,vector<CCVector3 > *pts,
	CCVector3 r_srcPt,CCVector3 r_nv,CCVector2 r_range,double &m_ratio)
{
	vector<CCVector3 > pts_L,pts_R;

	long npt = pl->size(),count_inside=0,count=0;
	const CCVector3 *pt;
	for (long i = 0; i< npt; i++)
	{
		pt =&pl->at(i);
		CCVector3 pt_add = *pt;

		double pro = calProDis_P2L_3d(&r_srcPt,&r_nv,&pt_add );
		if (pro > r_range.x && pro < r_range.y)
		{
			count_inside++;		
			if (proj.x * pt->x + proj.y * pt->y + proj.z  < 0 )
			{
				count++;
				pts_L.push_back(pt_add);
			}
			else pts_R.push_back(pt_add);
		}
	}
	m_ratio = count/ (double)count_inside;		
	pts->clear();
	if (m_ratio > 0.5) {(*pts) = pts_R; return 1;}
	else {m_ratio  = 1-m_ratio; (*pts) = pts_L;return 2;}
}


void checkPtsByPlanesAndRidgeRanges(TP_Plane *pl_src,TP_Plane *pl_dst,vector <CCVector3 > *pts_in,
	 vector <CCVector3 > *pts_out)
{
	double pro,d1,d2,d_th=0.2;
	for(int i = 0 ; i< pts_in->size();i++ )
	{

		d1 = pl_src->calDisPt2Plane(pts_in->data()[i]);
		d2 = pl_dst->calDisPt2Plane(pts_in->data()[i]);
		if (!(/*d2 < 2*d1  && */d2 < d_th))
		{
			pts_out->push_back(pts_in->data()[i]);
		}
	}
}


void addPt2Vectors_noRepick(vector<CCVector3 > &p_list, CCVector3 v_add)
{
	if (p_list.empty()){ p_list.push_back(v_add);return;}
	else
	{
		for(int i = 0;i< p_list.size(); i++)
		{
			if (calDisP2P_xy_sqrt(&p_list.data()[i],&v_add) < 0.0001)return;
		}
	}
	p_list.push_back(v_add);

}
int findPtInVectors(vector<CCVector3 > *p_list, CCVector3 v_add)
{
	if (p_list->empty()){ return -1;}
	else
	{
		for(int i = 0;i< p_list->size(); i++)
		{
			if (calDisP2P_xy_sqrt(&p_list->data()[i],&v_add) < 0.0001)
			{
				p_list->data()[i].z = v_add.z;
				return i;
			}
		}
	}
	return -1;

}
CCVector2i checkPtlistByPtsPool(TP_PtList *bd, vector < CCVector3 > ptsPool/*,vector <CCVector2i> *rgs*/ )
{
	int i,l_id = -1,r_id= -1;
	int *fg = new int[bd->size()];memset(fg,0,sizeof(int)* bd->size());
	for (i= 0; i< bd->size();i++)
	{
		if (findPtInVectors(&ptsPool,bd->data()[i].m_p) != -1)fg[i] = 1;
		else continue;

		if (l_id == -1) l_id =i;
		r_id = i;
	}
	if (r_id == -1)r_id = l_id;
	return CCVector2i(l_id,r_id); 
		
}


void pt_i_o_change(CCVector3 *in, CCVector3 *out, int type,CCVector2 m_ori)
{
	if (type == 0) 
	{
		out->x = m_ori.x * in->x + m_ori.y * in->y;
		out->y = - m_ori.y * in->x + m_ori.x * in->y;
		out->z = in->z;
	} 
	else
	{
		out->x = m_ori.x * in->x + m_ori.y * in->y;
		out->y = - m_ori.y * in->x + m_ori.x * in->y;
		out->z = in->z;
	}
}


void PtList_IO(TP_PtList *_in,TP_PtList *_out, CCVector2 m_ori,bool m_type)
{
	if (_in == NULL || _out == NULL || _in->empty())return;
	
	if (_in != _out)
	{
		_out->clear();(*_out) = (*_in);
	}

	CCVector3 pt,pt1;
	if (!m_type)
	{
		for (int i = 0;i< _out->size();i++)
		{
			pt= _out->data()[i].m_p;
			pt1.x = m_ori.x * pt.x + m_ori.y * pt.y;
			pt1.y = - m_ori.y * pt.x + m_ori.x * pt.y;
			pt1.z = pt.z;
			_out->data()[i].m_p = pt1;
		}
	}
	else
	{
		for (int i = 0;i< _in->size();i++)
		{
			pt= _out->data()[i].m_p;
			pt1.x = m_ori.x * pt.x - m_ori.y * pt.y;
			pt1.y = m_ori.y * pt.x + m_ori.x * pt.y;
			pt1.z = pt.z;
			_out->data()[i].m_p = pt1;
		}
	}
}
void fitArrayIntoTwoGroups(int *pData, int num, IDList *type1,IDList *type2,IDList *outs)
{
	if (type1 == NULL || type2 == NULL)return;
	for (int i=0;i < num ;i++){if (!(pData[i]==0 || pData[i]==1))return;}
	type1->clear();type2->clear();
	
	int id_before,n_outCount=0;
	if (pData[0]== 0){type2->push_back(0);type2->push_back(0);id_before=0;}
	else {type1->push_back(0);type1->push_back(0);id_before=1;}

	for (int i=1;i < num ;i++)
	{
		if (pData[i] == id_before)
		{
			if (id_before == 0)
			{
				type2->pop_back();type2->push_back(i);n_outCount++;
			}
			else
			{
				type1->pop_back();type1->push_back(i);
			}
		}
		else
		{
			if (id_before == 0)
			{
				if (n_outCount < 2)
				{
					outs->push_back(type2->back());
					type2->pop_back();
					type2->pop_back();
					if (!type1->empty())
					{
						type1->pop_back();type1->push_back(i);
					}
					else
					{
						type1->push_back(i);type1->push_back(i);
					}
					
				}
				else
				{
					type1->push_back(i);
					type1->push_back(i);
				}				
				id_before=1;
				n_outCount =0;
			}
			else
			{				
				type2->push_back(i);
				type2->push_back(i);
				id_before=0;
				n_outCount ++;
			}
		}

	}

}

void replacePtListByPolyLine(TP_PtList *plist_in,TP_PtList *plist_out,CCVector2i *id_bd,double dTh)
{
	if (plist_out == NULL)plist_out = new TP_PtList;
	else plist_out->clear();
	id_bd->x = 0; id_bd->y = plist_in->size() -1;

	*plist_out = *plist_in;
	TP_PtList *plist = nullptr; plist = plist_out;

	CCVector3 bb1,bb2; 
	int _type;
	getBBofPtlist(plist,&bb1,&bb2);
	if (bb2.y - bb1.y > bb2.x - bb1.x)_type =1;
	else _type = 2;
	

	vector <TP_stepEdge > *m_StepEgs=new vector <TP_stepEdge >;
	int npt = plist->size(),i,j;
	int *f_cmp_x = new int[npt*npt]; memset(f_cmp_x,0,sizeof(int)*npt*npt);
	int *f_cmp_y = new int[npt*npt]; memset(f_cmp_y,0,sizeof(int)*npt*npt);
	CCVector3 pt1,pt2;
	for( i = 0; i< npt ;i++)plist->data()[i].delete_flag = false;
	for( i = 0; i< npt ;i++)
	{
		pt1 = plist->data()[i].m_p;
       for(j = i; j< npt ;j++)
	   {
		   pt2 = plist->data()[j].m_p;
		   if (fabs(pt1.x - pt2.x) < dTh)f_cmp_x[i*npt +j] =f_cmp_x[j*npt +i] = 1;
		   if (fabs(pt1.y - pt2.y) < dTh)f_cmp_y[i*npt +j] =f_cmp_y[i*npt +j] = 1;
	   }
	}

	int f_count = npt,maxID_x, maxCount_x,maxID_y, maxCount_y;
	int *x_count = new int[npt];memset(x_count,0,sizeof(int)*npt);
	int *y_count = new int[npt];memset(y_count,0,sizeof(int)*npt);	
	int *temp_count = new int[npt];memset(temp_count,false,sizeof(int)*npt);
	bool *f_mark = new bool[npt];memset(f_mark,false,sizeof(bool)*npt);
	int n_stepEgs=0;

	while (f_count > 1)
	{
		memset(x_count,0,sizeof(int)*npt);
		memset(y_count,0,sizeof(int)*npt);
		memset(temp_count,false,sizeof(int)*npt);
		maxID_x = 0; maxCount_x = 1;
		maxID_y = 0; maxCount_y = 1;
		for( i = 0; i< npt ;i++)
			for(j = 0; j< npt ;j++)
		{
			if (!f_mark[i]&& !f_mark[j])
			{
				if (f_cmp_x[i*npt +j] == 1)x_count[i]++;
				if (f_cmp_y[i*npt +j] == 1)y_count[i]++;
			}
		}
        
	    for( i = 0; i< npt ;i++)
		{
			if (x_count[i] > maxCount_x){maxCount_x = x_count[i]; maxID_x = i;}
			if (y_count[i] > maxCount_y){maxCount_y = y_count[i]; maxID_y = i;}
		}
		if (maxCount_x < 3 && maxCount_y< 3)//找不到，所有的都是outliers，直接dauglas拟合;
		{
			break;
		}

		IDList l_acc,l_out,outs;
		int type_now=2;
		if (maxCount_x > maxCount_y || (maxCount_x== maxCount_y && _type == 1 ))
		{
			type_now =1;
			memcpy(temp_count,f_cmp_x + maxID_x*npt,sizeof(int)*npt);
			for( i = 0; i< npt ;i++)
			{
				if (f_mark[i])temp_count[i]=0;
			}
			fitArrayIntoTwoGroups(temp_count,npt,&l_acc,&l_out,&outs);
		}
		else 
		{
			memcpy(temp_count,f_cmp_y + maxID_y*npt,sizeof(int)*npt);
			for( i = 0; i< npt ;i++)
			{
				if (f_mark[i])temp_count[i]=0;
			}
			fitArrayIntoTwoGroups(temp_count,npt,&l_acc,&l_out,&outs);
		}
	    
		int large_id = -1,large_len = 1;
		if (l_acc.empty())return;

		for( i = 0; i< l_acc.size()/2 ;i++)
		{
			int id1 = l_acc.at(i*2);
			int id2 = l_acc.at(i*2+1);
			if (large_len < (id2-id1+1))
			{
				large_id =i;
				large_len = (id2-id1+1);
			}
		}
		if (large_id != -1 && large_len > 3)
		{
			int id_s = l_acc.at(large_id*2);
			for (i=id_s;i< id_s+large_len;i++ )
			{				
				f_mark[i] = true;	
				
			}
			for (i=id_s+1;i< id_s+large_len-1;i++ )plist->data()[i].PtStab = StepInside;

			if (type_now == 1)
			{	
				plist->data()[id_s].dis_to_edge = plist->data()[id_s].m_p.x - plist->data()[maxID_x].m_p.x;
				plist->data()[id_s].PtStab = StepEdgeEnd_X;
				plist->data()[id_s+large_len-1].PtStab = StepEdgeEnd_X;
				plist->data()[id_s].m_p.x = plist->data()[maxID_x].m_p.x;
				plist->data()[id_s+large_len-1].m_p.x  = plist->data()[maxID_x].m_p.x;
			}
			else
			{
				plist->data()[id_s].dis_to_edge = plist->data()[id_s].m_p.y - plist->data()[maxID_y].m_p.y;
				plist->data()[id_s].PtStab = StepEdgeEnd_Y;
				plist->data()[id_s+large_len-1].PtStab = StepEdgeEnd_Y;
				plist->data()[id_s].m_p.y = plist->data()[maxID_y].m_p.y;
				plist->data()[id_s+large_len-1].m_p.y  = plist->data()[maxID_y].m_p.y;
			}
			f_count -= large_len;
			n_stepEgs++;
		}
		else break;
	}
	delete []f_mark;delete []f_cmp_x;delete []f_cmp_y;
	delete []x_count;delete []y_count;delete []temp_count;

	if (n_stepEgs == 0)return;


	int id1a,id1b,id2a,id2b,pos_count=0;
	TP_Vertex *Pt1a,*Pt1b,*Pt2a,*Pt2b;
	int *id_stepPosition = new int[n_stepEgs * 2]; memset(id_stepPosition, 0, sizeof(int)*n_stepEgs * 2);
//	for (int i= 0;i < n_stepEgs*2;i++)id_stepPosition[i] = -1;

	for(int i= 0;i < npt;i++)
	{

		if (plist->data()[i].PtStab == StepEdgeEnd_X || plist->data()[i].PtStab == StepEdgeEnd_Y)
		{
			id_stepPosition[pos_count] = i;
			pos_count++;
		}
	}
	assert(pos_count == n_stepEgs*2);
	id_bd->x = id_stepPosition[0];
	id_bd->y = id_stepPosition[n_stepEgs*2-1];

	if (n_stepEgs > 1)		
	{			
		int npt_between;			
		for (int i=0;i< n_stepEgs-1;i++)
		{	
			id1a = id_stepPosition[i*2];id1b = id_stepPosition[i*2+1];
			id2a = id_stepPosition[i*2+2];id2b = id_stepPosition[i*2+3];
			Pt1a = &plist->data()[id1a];Pt1b =&plist->data()[id1b];
			Pt2a = &plist->data()[id2a];Pt2b =&plist->data()[id2b];

			npt_between = id2a- id1b-1;
			if (npt_between <6)//间隔小则强行规格化;
			{
				if (Pt1b->PtStab != Pt2a->PtStab)
				{
					Pt1b->PtStab = StepInside;
					if (Pt2a->PtStab == StepEdgeEnd_X)Pt2a->m_p.y = Pt1b->m_p.y;
					else Pt2a->m_p.x=  Pt1b->m_p.x;
						
					Pt2a->PtStab = StepEdgeCorner;
				}
				else
				{
					if (Pt1b->PtStab == StepEdgeEnd_X)
					{
						double val = Pt1b->m_p.y;
						if (fabs(Pt1b->m_p.x - Pt2b->m_p.x)>1)
						{						
							if (npt_between != 0 )val = plist->at(id1b+1).m_p.y;
							Pt1b->m_p.y =val;
							Pt2a->m_p.y =val;
						}
						else//合并到后面一条边
						{
							val = (Pt1b->m_p.x + Pt2b->m_p.x)/2;
							Pt1a->m_p.x =val;
							Pt2b->m_p.x =val;
							Pt1b->PtStab = StepInside;
							Pt2a->PtStab = StepInside;
						}
					}
					else
					{
						double val = Pt1b->m_p.x;
						if (fabs(Pt1b->m_p.y - Pt2b->m_p.y)>1)
						{						
							if (npt_between != 0 )val = plist->at(id1b+1).m_p.x;
							Pt1b->m_p.x =val;
							Pt2a->m_p.x =val;
						}
						else//合并到后面一条边
						{
							val = (Pt1b->m_p.y + Pt2b->m_p.y)/2;
							Pt1a->m_p.y =val;
							Pt2b->m_p.y =val;
							Pt1b->PtStab = StepInside;
							Pt2a->PtStab = StepInside;				
						}
					}
				}
			}
		}				
	}	
	delete []id_stepPosition;
}

void getAnotherSideofTheStepEdge(CCVector3 pt1,CCVector3 pt2,TP_PtList*downPts, CCVector2i *downRange,LineSegmentsList *plist,bool isLeftUpper)
{
	int nPairs = plist->size();
	CCVector3 pt_now;
	int id_now,id_min = downPts->size()-1,id_max=0;
	
	if (isLeftUpper)
	{
		for (int i = 0; i< nPairs; i++)
		{
			pt_now = plist->data()[i].pt1;
			if (calDisP2P_xy_sqrt(&pt1,&pt_now) < 0.01)
			{
				id_now = findPtInPtList(downPts,plist->data()[i].pt2);
				if (id_now != -1 && id_now < id_min)
				{
					id_min = id_now;
				}
			}
			if (calDisP2P_xy_sqrt(&pt2,&pt_now) < 0.01)
			{
				id_now = findPtInPtList(downPts,plist->data()[i].pt2);
				if (id_now != -1 && id_now > id_max)
				{
					id_max = id_now;
				}
			}


		}
	}
	else
	{
		for (int i = 0; i< nPairs; i++)
		{
			pt_now = plist->data()[i].pt2;
			if (calDisP2P_xy_sqrt(&pt1,&pt_now) < 0.01)
			{
				id_now = findPtInPtList(downPts,plist->data()[i].pt1);
				if (id_now != -1 && id_now < id_min)
				{
					id_min = id_now;
				}
			}
			if (calDisP2P_xy_sqrt(&pt2,&pt_now) < 0.01)
			{
				id_now = findPtInPtList(downPts,plist->data()[i].pt1);
				if (id_now != -1 && id_now > id_max)
				{
					id_max = id_now;
				}
			}
		}
	}

	downRange->x = id_min;
	downRange->y = id_max;

}


double assertBDbyOriginBDPTs(TP_PtList *bdAll,CCVector2i pos,Plane_ConnectiveEdgeList *pce,bool isPlaneUpper)
{
	TP_PtList bd_ori, bd_new, bdAll_new; 
	bd_ori.clear(); bd_new.clear(); bdAll_new.clear();
	getPartOfPtsFromLoop(bdAll,&bd_ori,pos.x,pos.y,false);
	pce->getPts(&bd_new,!isPlaneUpper);
	if (bd_new.empty())return 99999;
	
	replacePartOfList(bdAll,&bd_new,pos,&bdAll_new);

	int npt_all = bdAll->size() ;
	int npt = bd_ori.size();
	int nRidge = bd_new.size()-1;
	CCVector3 pt,pt1,pt2;
	double dis,dMin,m_error= 0;
	for (int i = 0;i < npt;i++ )
	{
		pt = bd_ori.at(i).m_p;
		dMin= 2;		
		if (! IsPtInRectList(&bdAll_new,pt))
		{
			for (int j=0; j < nRidge;j++)
			{
				pt1 = bd_new.data()[j].m_p;
				pt2 = bd_new.data()[j+1].m_p;
				dis = calDisPt2LineSegment_2d(&pt,&pt1,&pt2) ;
				if (dis < dMin) {dMin = dis ;}
			}	
			m_error += dMin*dMin;			
		}	
	}

	return m_error;

}


void adjustStepBd(TP_PtList *bd, TP_PtList *bd_new, TP_PtList *bdAll,CCVector2i pos, double mvRange)
{
    int npt = pos.y - pos.x +1,i,j;
	assert(bd->size() == bd_new->size());
	CCVector2i ids(bd->at(pos.x).ID,bd->at(pos.y).ID);
	
	TP_PtList l_replace,bdAll_new;
	IDList id_replace;
	for (int i = 0;i < npt;i++ )
	{
		if (bd_new->data()[pos.x +i].PtStab > StepInside)
		{
			id_replace.push_back(pos.x+i); 
		    l_replace.push_back(bd_new->at(pos.x +i));
		}
	}
	replacePartOfList(bdAll,&l_replace,ids,&bdAll_new);
	int nLineSeg = l_replace.size() -1 ;
	if (nLineSeg < 1)return;
	
	//判断调整的方向，取中点向垂直方向延伸，判断内外;
	CCVector3 * rg_outs = new CCVector3[nLineSeg];
	CCVector3 * rg_mids = new CCVector3[nLineSeg];
	CCVector3 pt_mid, pt1,pt2,pt,ori,ori_1;
	for (i = 0;i < nLineSeg;i++ )
	{
		pt1 = l_replace.data()[i].m_p;
		pt2 = l_replace.data()[(i+1)].m_p;
		rg_mids[i] = (pt1+pt2)*0.5;rg_mids[i].z=0;		
        ori = (pt2-pt1); ori.z = 0;	
		double mod = sqrt(ori.x *ori.x + ori.y *ori.y); ori.x /= mod; ori.y /= mod;
		ori_1.x = ori.y; ori_1.y = - ori.x;		
		pt = rg_mids[i] + ori_1*0.1;
		if (IsPtInRectList(&bdAll_new, pt)){ ori_1 = ori_1* (-1); }//在内部，则反向;
		rg_outs[i] =  rg_mids[i] + ori_1;
	}

	int *ptID = new int[npt]; memset(ptID, 0, sizeof(int)*npt);
			
	double dis,dMin;
	for (i = 0;i < npt;i++ )
	{
		pt = bd->data()[pos.x+i].m_p;
		dMin= 99999;ptID[i] = -1;
		if (! IsPtInRectList(&bdAll_new,pt))
		{
			for (j=0; j < nLineSeg;j++)
			{
				pt1 = l_replace.data()[j].m_p;
				pt2 = l_replace.data()[j+1].m_p;
				dis = calDisPt2LineSegment_2d(&pt,&pt1,&pt2) ;
				if (dis < dMin) {dMin = dis  ;ptID[i] = j;}
			}	
		}
	}


	double pro_a;
	double *moveVal = new double[nLineSeg];
	for (i = 0; i < nLineSeg; i++)
	{
		moveVal[i] = 0;
	}

	for (i=0; i < npt;i++)
	{
		int r_id = ptID[i];	if (r_id == -1) continue;		
		pro_a = calProPt2LineSegment_2d(&bd->data()[pos.x+i].m_p,&rg_mids[r_id],&rg_outs[r_id]);
		if (fabs(pro_a) > moveVal[r_id]  && fabs(pro_a) < mvRange)moveVal[r_id] = pro_a;
	}
	
	/*
	int id_re;
	for (i=0; i < nLineSeg;i++)
	{	
		id_re = id_replace.at(i);
		bd_new->data()[id_re].m_p = bd_new->data()[id_re].m_p +(rg_outs[i] - rg_mids[i])* moveVal[i];
		id_re = id_replace.at(i+1);
		bd_new->data()[id_re].m_p = bd_new->data()[id_re].m_p +(rg_outs[i] - rg_mids[i])* moveVal[i];
	}
	*/
	 delete[]ptID ;delete[]moveVal ;delete []rg_mids;delete []rg_outs;
	 
}

bool DividingLinesBetweenTwoPtList(Plane_Plane_Relation *ppR,TP_PtList *l1,TP_PtList *l2, CCVector2 m_ori,
	Plane_ConnectiveEdgeList *stepBD1,Plane_ConnectiveEdgeList *stepBD2,double *m_error)
{
	TP_PtList pro1,pro2;	
	PtList_IO(l1,&pro1,m_ori,false);
	PtList_IO(l2,&pro2,m_ori,false);

	CCVector3 bb1a,bb1b,bb2a,bb2b,m_range;
	getBBofPtlist(&pro1,&bb1a,&bb1b);
	getBBofPtlist(&pro2,&bb2a,&bb2b);
	
	//首先找到较高的面
	bool isPlane1Upper;
	TP_PtList *p_upper=NULL,*p_downer = NULL;
	if (bb1b.z > bb2b.z){p_upper = &pro1;p_downer = &pro2;	m_range = bb1b- bb1a;isPlane1Upper = true;}
	else{	p_upper = &pro2;p_downer = &pro1;m_range = bb2b- bb2a;isPlane1Upper= false;}	
	

	CCVector2i id_stepPosition(-1,-1);
	TP_PtList bd_markList;
	replacePtListByPolyLine(p_upper,&bd_markList,&id_stepPosition,1.0);
	CCVector3 pt_l,pt_r,pta,ptb;
	if (id_stepPosition.x == -1)return false;


	if (isPlane1Upper)
	{
		stepBD1->flag_inverse = false;
		pt_l = l1->data()[id_stepPosition.x].m_p;
		pt_r = l1->data()[id_stepPosition.y].m_p;
		TP_PtList bd_all;
		PtList_IO(&ppR->m_p1->m_outsideBD->m_pts,&bd_all,m_ori,false);
	
		adjustStepBd(&pro1,&bd_markList,&bd_all,id_stepPosition,1.0);
				
		PtList_IO(&bd_markList,&ppR->tps_stbd,m_ori,true);
		stepBD1->InitialbyPtlist_stepEgs(&ppR->tps_stbd);stepBD1->isPCEStepEg = true;
		stepBD2->InitialbyPtlist_stepEgs(&ppR->tps_stbd);stepBD2->isPCEStepEg = true;
		
		CCVector2i m_rg;		
		getAnotherSideofTheStepEdge(pt_l,pt_r,l2,&m_rg,ppR->plist,true);
		stepBD2->l_id = l2->data()[m_rg.y].ID;
		stepBD2->r_id = l2->data()[m_rg.x].ID;
		stepBD2->flag_inverse = true;

		//for(int i= 0 ;i< p_upper->size();i++)l1->data()[i].delete_flag = p_upper->data()[i].delete_flag;
	}
	else
	{
		stepBD2->flag_inverse = false;
		pt_l = l2->data()[id_stepPosition.x].m_p;
		pt_r = l2->data()[id_stepPosition.y].m_p;

		TP_PtList bd_all;
		PtList_IO(&ppR->m_p2->m_outsideBD->m_pts,&bd_all,m_ori,false);

		adjustStepBd(&pro2,&bd_markList,&bd_all,id_stepPosition,1.0);


		PtList_IO(&bd_markList,&ppR->tps_stbd,m_ori,true);
		stepBD1->InitialbyPtlist_stepEgs(&ppR->tps_stbd);stepBD1->isPCEStepEg = true;
		stepBD2->InitialbyPtlist_stepEgs(&ppR->tps_stbd);stepBD2->isPCEStepEg = true;
		CCVector2i m_rg;	
		getAnotherSideofTheStepEdge(pt_l,pt_r,l1,&m_rg,ppR->plist,false);
		stepBD1->l_id = l1->data()[m_rg.y].ID;
		stepBD1->r_id = l1->data()[m_rg.x].ID;
		stepBD1->flag_inverse = true;
		//for(int i= 0 ;i< p_upper->size();i++)l2->data()[i].delete_flag = p_upper->data()[i].delete_flag;
	}
//	CCVector2i pos1(stepBD1->l_id,stepBD1->r_id);
	CCVector2i pos1(l1->front().ID,l1->back().ID);
	double m_error1 = assertBDbyOriginBDPTs(&ppR->m_p1->m_outsideBD->m_pts,pos1,stepBD1,isPlane1Upper);
//	CCVector2i pos2(stepBD2->l_id,stepBD2->r_id);
	CCVector2i pos2(l2->front().ID,l2->back().ID);
	double m_error2 = assertBDbyOriginBDPTs(&ppR->m_p2->m_outsideBD->m_pts,pos2,stepBD2,!isPlane1Upper);
	
	*m_error  = fmax(m_error1,m_error2);
	return true;
}

void Plane_Plane_Relation::caculateRobustStepEdges(vector< CCVector2> *m_oris)
{	
	if (m_eg->edgeType > Step)return;	
	if (back_bd1.empty() || back_bd2.empty()) {m_eg->edgeType = NotExist;return;}	
	double d1 = calDisP2P_xy_sqrt(&back_bd1.front().m_p,&back_bd1.back().m_p);
	double d2 = calDisP2P_xy_sqrt(&back_bd2.front().m_p,&back_bd2.back().m_p);
	bool p1_acc = false,p2_acc = false;
	if ( back_bd1.size() > 1 || bdPts_L.size() > 1)p1_acc = true;
	if ( back_bd2.size() > 1 || bdPts_R.size() > 1)p2_acc = true;
	
	if ((p1_acc && p2_acc  && m_sigma > 0.3)  || m_eg->edgeType == Step) 
	{
		double m_errorMax= 9999,m_error,n_step,n_stepMAx= 9999;
		
		int id_choose =0;
		if (m_oris->empty())return;
		if (m_oris->size() > 1)
		{		
			for (int i =0 ; i< m_oris->size(); i++)
			{
				m_error =0;
				Plane_ConnectiveEdgeList temp1,temp2;
				DividingLinesBetweenTwoPtList(this,&back_bd1,&back_bd2,m_oris->at(i),&temp1,&temp2,&m_error);
				n_step = temp1.get_List_v()->size()-1;
				if (n_step > 0 && n_step < n_stepMAx)
				{	
					id_choose = i;
					n_stepMAx = n_step;m_errorMax = m_error;
				}
				else if (m_error < m_errorMax)
				{
					id_choose = i;
					n_stepMAx = n_step;m_errorMax = m_error;
				}				
			}
		}		
		if (DividingLinesBetweenTwoPtList(this, &back_bd1, &back_bd2, m_oris->at(id_choose), &stepBD1, &stepBD2, &m_error))
		{
			stepBD1.l_nbd = m_p1->id_outside;
			stepBD2.l_nbd = m_p2->id_outside;
			m_p1->out_PCE.push_back(&stepBD1);
			m_p2->out_PCE.push_back(&stepBD2);
			m_eg->edgeType = Step;
			m_ori_ifStep = m_oris->at(id_choose);
			ori_id = id_choose;
		}
	
	}
//	 if (m_sigma > 0.5 && m_eg->edgeType == Undecided)m_eg->edgeType == NotExist;
	
	for (long i = 0; i < back_bd1.size(); i++)m_p1->Point2D_to_3D(&back_bd1.at(i));
	for (long i = 0; i < back_bd2.size(); i++)m_p2->Point2D_to_3D(&back_bd2.at(i));
	for (long i = 0; i < bdPts_L.size(); i++)
	{
		bdPts_L.at(i) = m_p1->Point2D_to_3D_ccVector3(bdPts_L.at(i));
	}
	for (long i = 0; i < bdPts_R.size(); i++)
	{
		bdPts_R.at(i) = m_p2->Point2D_to_3D_ccVector3(bdPts_R.at(i));
	}
}


//calculate line in 3D.  described by a point and line normal.
void Plane_Plane_Relation::caculateRidgeParameter()
{
	//	if (m_p1->m_boundarys == NULL || m_p1->m_boundarys->size() == 0)

	TP_Plane *p1= m_p1,*p2 = m_p2;
	double nx,ny,nz;
	nx=p1->m_b * p2->m_c - p1->m_c * p2->m_b;
	ny=p1->m_c * p2->m_a - p1->m_a * p2->m_c;
	nz=p1->m_a * p2->m_b - p1->m_b * p2->m_a;
	double vectorDis=sqrtf(nx*nx + ny*ny + nz*nz);
	r_nv.x=nx/vectorDis;
	r_nv.y=ny/vectorDis;
	r_nv.z=nz/vectorDis;


    const	CCVector3 *ptSample = &p1->getPointCloud()->at(0);
	//求交线在水平面上的投影方程，即消去Z值  ax+by+d=0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
	double a_Pro,b_Pro,d_Pro,a2plusb2;
	projection_para.x = a_Pro = p1->m_a * p2->m_c - p2->m_a * p1->m_c ;		
	projection_para.y = b_Pro = p1->m_b * p2->m_c - p2->m_b * p1->m_c ;
	projection_para.z = d_Pro = p1->m_d * p2->m_c - p2->m_d * p1->m_c ; 
	a2plusb2 = a_Pro *a_Pro + b_Pro*b_Pro;
	if (fabs(a_Pro) < fabs(b_Pro))
	{
		r_srcPt.x = ptSample->x;
		r_srcPt.y = (-1.0 * d_Pro - a_Pro*r_srcPt.x)/b_Pro;
		r_srcPt.z = (-1.0*p1->m_d- r_srcPt.x * p1->m_a -r_srcPt.y *p1->m_b)/p1->m_c;
	}
	else
	{
		r_srcPt.y = ptSample->y;
		r_srcPt.x = (-1.0 * d_Pro - b_Pro*r_srcPt.y)/a_Pro;
		r_srcPt.z = (-1.0*p1->m_d- r_srcPt.x * p1->m_a -r_srcPt.y *p1->m_b)/p1->m_c;
	}
}

void Plane_Plane_Relation::decideEdgeType()
{
	//return;
	//ridge 的范围约束在两侧点云的公共部分内;
	CCVector2 range1 = caculateCloudRanges(m_p1,r_srcPt,r_nv);
	CCVector2 range2 = caculateCloudRanges(m_p2,r_srcPt,r_nv);

	r_range.x = fmax(range1.x,range2.x);
	r_range.y = fmin(range1.y,range2.y);
	if (r_range.x >= r_range.y || fabs(r_range.y- r_range.x) < m_p1->aveDis){m_eg->edgeType = Undecided; return;}


	vector <CCVector3 > outPts1,outPts2,outPts1_checked,outPts2_checked;
	double m_ratio1,m_ratio2;
	int back1= divideCloudsByline_2D(projection_para,m_p1->getPointCloud(),&outPts1,r_srcPt,r_nv,r_range,m_ratio1);
	int back2= divideCloudsByline_2D(projection_para,m_p2->getPointCloud(),&outPts2,r_srcPt,r_nv,r_range,m_ratio2);

	if (back1 == back2)dType = Refuse;//划分在同侧或无法划分  则直接拒绝;
	else if (m_ratio1 > 0.9 && m_ratio2> 0.9)dType = Perfect;
	else
	{
		int count1,count2;
		count1 = outPts1.size()/m_ratio1;	count2= outPts2.size()/m_ratio2;
		checkPtsByPlanesAndRidgeRanges(m_p1,m_p2,&outPts1,&outPts1_checked);
		checkPtsByPlanesAndRidgeRanges(m_p2,m_p1,&outPts2,&outPts2_checked);

		outPts1.clear();outPts2.clear();
		/*outPts1_checked =outPts1;
		outPts2_checked =outPts2;*/
		m_ratio1 = (double)(outPts1_checked.size()) / (double)(count1);
		m_ratio2 = (double)(outPts2_checked.size()) / (double)(count2);
		if (m_ratio1 < 0.1 && m_ratio2< 0.1)dType = Perfect;

	    //区分同时包含阶跃和屋脊线  还是直接是阶跃;

		else dType = Refuse;
	
	}
	if (dType == Perfect)
	{
		ccPointCloud combPts;
		ccPointCloud  *c_comb = &combPts;
		long npt_1 = m_p1->getPointCloud()->size();
		long npt_comb = m_p1->getPointCloud()->size() + m_p2->getPointCloud()->size();
		c_comb->reserve(npt_comb);
		for (long i = 0; i < m_p1->getPointCloud()->size(); i++)
		{
			c_comb->push_back(m_p1->getPointCloud()->at(i));
		}
		for (long i = 0; i < m_p2->getPointCloud()->size(); i++)
		{
			c_comb->push_back(m_p2->getPointCloud()->at(i));
		}
		int n_bdComb =0;
		TP_PlaneBoundary *bdComb=generateEdge(c_comb,m_p1->alpha_scale,&n_bdComb);
		float m_alpha = m_p1->alpha_scale;
		while (n_bdComb > 1)
		{
			bdComb->clear();
			n_bdComb=0;
			m_alpha *= 1.5;
			bdComb=generateEdge(c_comb,m_alpha,&n_bdComb);
		}
		decideRidgeEndsByBothClouds(&bdComb->front()->m_pts,projection_para,m_eg);
		if (m_eg->p1 == NULL || m_eg->p2 == NULL) {m_eg->edgeType =Undecided;return;}
		
		m_p1->Point2D_to_3D(m_eg->p1);
		m_p1->Point2D_to_3D(m_eg->p2);
		double pro_1 = calProDis_P2L_3d(&r_srcPt,&r_nv,&m_eg->p1->m_p);
		double pro_2 = calProDis_P2L_3d(&r_srcPt,&r_nv,&m_eg->p2->m_p);
		CCVector2 range_new;
		if (pro_1 < pro_2)
		{
			
			range_new.x = fmax(pro_1,(double)r_range.x);
			range_new.y = fmin(pro_2,(double)r_range.y);
			if (range_new.x < range_new.y)
			{
				if (pro_1 < r_range.x)m_eg->p1=calPtInLine(&r_srcPt,&r_nv,range_new.x);
				if (pro_2 > r_range.y)m_eg->p2=calPtInLine(&r_srcPt,&r_nv,range_new.y);
				m_p1->Point2D_to_3D(m_eg->p1);
				m_p1->Point2D_to_3D(m_eg->p2);
				m_eg->edgeType = SS_S_convex;
			}
			else 
			{
				m_eg->edgeType = Undecided;
				m_eg->p1= m_eg->p2 = NULL;
			}
			//m_eg->p1->m_p.z = m_eg->p2->m_p.z =0;
		}
		else
		{
			range_new.x = fmax(pro_2,(double)r_range.x);
			range_new.y = fmin(pro_1,(double)r_range.y);

			if (range_new.x < range_new.y)
			{
				if (pro_1 > r_range.y)m_eg->p1=calPtInLine(&r_srcPt,&r_nv,range_new.y);
				if (pro_2 < r_range.x)m_eg->p2=calPtInLine(&r_srcPt,&r_nv,range_new.x);
				m_p1->Point2D_to_3D(m_eg->p1);
				m_p1->Point2D_to_3D(m_eg->p2);
				m_eg->edgeType = SS_S_convex;
			
			}
			else 
			{
				m_eg->edgeType = Undecided;
				m_eg->p1= m_eg->p2 = NULL;
			}
			//m_eg->p1->m_p.z = m_eg->p2->m_p.z =0;
		}
		c_comb->clear();
	}
	CCVector2i id_back1,id_back2;
	id_back1= getBdIDofRidgeEnds(m_p1,&back_bd1,r_srcPt,r_nv,5*m_p1->aveDis); 
	id_back2= getBdIDofRidgeEnds(m_p2,&back_bd2,r_srcPt,r_nv,5*m_p2->aveDis);

	
	if (id_back1.x == -1 || id_back1.y == -1)
	{
		CCVector2 m_pro;
		caculateRelatationBetwweenLoopsAndEdge(&m_p1->m_outsideBD->m_pts,r_srcPt,r_nv,&ID_onlist_1,&m_pro);
	}
	else
	{
		ID_onlist_1.x = findPtInPtList(&m_p1->m_outsideBD->m_pts,back_bd1.data()[id_back1.x].m_p);
		ID_onlist_1.y = findPtInPtList(&m_p1->m_outsideBD->m_pts,back_bd1.data()[id_back1.y].m_p);
	}

	if (id_back2.x == -1 || id_back2.y == -1)
	{
		CCVector2 m_pro;
		caculateRelatationBetwweenLoopsAndEdge(&m_p2->m_outsideBD->m_pts,r_srcPt,r_nv,&ID_onlist_2,&m_pro);
	}
	else
	{
		ID_onlist_2.x = findPtInPtList(&m_p2->m_outsideBD->m_pts,back_bd2.data()[id_back2.x].m_p);
		ID_onlist_2.y = findPtInPtList(&m_p2->m_outsideBD->m_pts,back_bd2.data()[id_back2.y].m_p);
	}
	if (m_eg->p1 == NULL || m_eg->p2 == NULL){m_eg->edgeType = Undecided; return;}

	    m_eg->flag_use = true;
		TP_Plane_ridgeMessage *mes1=new TP_Plane_ridgeMessage;
		TP_Plane_ridgeMessage *mes2=new TP_Plane_ridgeMessage;
		mes1->ridge=mes2->ridge=m_eg->ID;
		mes1->m_edge =mes2->m_edge =m_eg;
		mes1->n_bd=mes2->n_bd=0;
		mes1->list_start=ID_onlist_1.x;mes1->list_end=ID_onlist_1.y;mes1->isPlaneID_large = false;
		mes2->list_start=ID_onlist_2.x;mes2->list_end=ID_onlist_2.y;mes2->isPlaneID_large = true;
		m_p1->m_ridgesMessage.push_back(*mes1);
		m_p2->m_ridgesMessage.push_back(*mes2);
		m_p1->m_GEdges.push_back(m_eg);
		m_p2->m_GEdges.push_back(m_eg);
	
	
}
bool Plane_Plane_Relation::updataReplacedIDsbyRidgeRange( TP_PtList *bd, CCVector2i * idOnList,CCVector2i rg)
{
      int npt = bd->size(),min_id = npt,max_id=rg.x ;
	  double pro_now ;
	  for (int i =rg.x ;i <= rg.y;i ++ )
	  {
		pro_now =  calProDis_P2L_3d(&r_srcPt,&r_nv,&bd->data()[i].m_p);
		if (pro_now < ridgeProRange.x-0.2 || pro_now > ridgeProRange.y+0.2)continue;		
		if (min_id > i) min_id = i;
		if (max_id < i) max_id = i;
	  }
	  if (min_id > max_id)return false;
	  else
	  {
		  idOnList->x = bd->at(min_id ).ID;
		  idOnList->y = bd->at(max_id ).ID;
		  return true;
	  }

}
void Plane_Plane_Relation::caculateRidegeEnds()
{


	//1.凹凸性与是否在内部

	bool flag_convex=false,flag_planeInPlane=false;	
	double interAngle = m_p1->m_a*m_p2->m_a+m_p1->m_b*m_p2->m_b+m_p1->m_c*m_p2->m_c;
	if (interAngle > 0)flag_convex =true;

	//2.两水平平面直接为阶跃;
	if (m_p1->m_type == H && m_p2->m_type == H){m_eg->edgeType = Step;return;}
	
	 CCVector3 p1_l,p1_r,p2_l,p2_r;
	TP_PtList *plist1 = &m_p1->m_outsideBD->m_pts;
	TP_PtList *plist2 = &m_p2->m_outsideBD->m_pts;
	double pro1_l,pro1_r,pro2_l,pro2_r;

	if (ID_onlist_1.x != -1  && ID_onlist_2.x != -1)
	{
		p1_l = plist1->data()[ID_onlist_1.x].m_p;p1_r = plist1->data()[ID_onlist_1.y].m_p;
		pro1_l= calProDis_P2L_3d(&r_srcPt,&r_nv,&p1_l);
		pro1_r= calProDis_P2L_3d(&r_srcPt,&r_nv,&p1_r);

		p2_l = plist2->data()[ID_onlist_2.x].m_p;p2_r = plist2->data()[ID_onlist_2.y].m_p;
		pro2_l= calProDis_P2L_3d(&r_srcPt,&r_nv,&p2_l);
		pro2_r= calProDis_P2L_3d(&r_srcPt,&r_nv,&p2_r);

		double pro1,pro2;
		bool flag_out = false;
		if (pro1_l < pro1_r)// pro increase;
		{
			isRidgeProIncrease = true;
			pro1 = fmax(pro1_l,pro2_r);
			pro2 = fmin(pro1_r,pro2_l);
			if (pro1 > pro2) flag_out = true;					
		}
		else
		{	
			isRidgeProIncrease = false;
			pro1 = fmin(pro1_l,pro2_r);
			pro2 = fmax(pro1_r,pro2_l);
			if (pro1 < pro2) flag_out = true;			
		}
		if (flag_out == true ){/*decideEdgeType();*/m_eg->edgeType = Undecided;return;}


		m_eg->p1=calPtInLine(&r_srcPt,&r_nv,pro1);
		m_eg->p2=calPtInLine(&r_srcPt,&r_nv,pro2);

		double dis = fabs(pro2-pro1);
		if (dis > m_p1->aveDis)	
		{
			ridgeProRange.x = fmin(pro1,pro2);
			ridgeProRange.y = fmax(pro1,pro2);
			m_eg->p1->PtStab =m_eg->p2->PtStab = Extensible;
			m_eg->p1->onBD = m_eg->p2->onBD = false;
			m_eg->len = dis;
			int H_count=0;
			if (m_p1->m_type == H)H_count++;
			if (m_p2->m_type == H)H_count++;	

			if (H_count == 0)
			{
				if (fabs(r_nv.z) < sin(3*PI/180.0))m_eg->edgeType = SS_H;
				else
				{
					if (flag_convex == true )m_eg->edgeType =SS_S_convex;
					else m_eg->edgeType =SS_S_concave;
				}
			}
			else m_eg->edgeType = HS_H;
			
			//if (m_p1->flag_IsInsidePlane || m_p2->flag_IsInsidePlane)m_eg->edgeType =Inside;
		}
		else /*{decideEdgeType();return;}*/m_eg->edgeType = Undecided;
	
	}
	else m_eg->edgeType = Undecided;
	
	if (m_eg->edgeType == Step  || m_eg->edgeType == NotExist|| m_eg->edgeType == Undecided)
	{
			m_eg->p1 = m_eg->p2 = NULL;
	}
	else
	{	
		
		if (updataReplacedIDsbyRidgeRange(&back_bd1,&ID_onlist_1,id_back1) && updataReplacedIDsbyRidgeRange(&back_bd2,&ID_onlist_2,id_back2))
		{
			TP_Plane_ridgeMessage *mes1=new TP_Plane_ridgeMessage;
			TP_Plane_ridgeMessage *mes2=new TP_Plane_ridgeMessage;
			mes1->ridge=mes2->ridge=m_eg->ID;
			mes1->m_edge =mes2->m_edge =m_eg;
			mes1->n_bd=mes2->n_bd=0;
			mes1->list_start=ID_onlist_1.x;mes1->list_end=ID_onlist_1.y;mes1->isPlaneID_large = false;
			mes2->list_start=ID_onlist_2.x;mes2->list_end=ID_onlist_2.y;mes2->isPlaneID_large = true;
			m_p1->m_ridgesMessage.push_back(*mes1);
			m_p2->m_ridgesMessage.push_back(*mes2);
			m_p1->m_GEdges.push_back(m_eg);
			m_p2->m_GEdges.push_back(m_eg);
		}
		else
		{
			m_eg->p1 = m_eg->p2 = NULL;m_eg->edgeType = Undecided;
		}		
	}					
}

void Plane_Plane_Relation::markCommonPtsBetweenTwoClouds()
{
	TP_PtList bd1,bd2;
	int i;
	TP_PtList back_bd1_a,back_bd2_a;

	ccPointCloud combPts;
	ccPointCloud  *c_comb = &combPts;
	long npt_1 = m_p1->getPointCloud()->size();
	long npt_comb = m_p1->getPointCloud()->size() + m_p2->getPointCloud()->size();
		c_comb->reserve(npt_comb);
		for (long i = 0; i < m_p1->getPointCloud()->size(); i++)
		{
			c_comb->push_back(m_p1->getPointCloud()->at(i));
		}
		for (long i = 0; i < m_p2->getPointCloud()->size(); i++)
		{
			c_comb->push_back(m_p2->getPointCloud()->at(i));
		}

//	ccPointCloud *p1_temp = m_p1->getPointCloud();
//	ccPointCloud *p2_temp = m_p2->getPointCloud();
	getBdListbetweenOnePlaneAndAll(m_p1,c_comb,&back_bd1_a);
	getBdListbetweenOnePlaneAndAll(m_p2,c_comb,&back_bd2_a);

	ID_onlist_1s.x =ID_onlist_1s.y=ID_onlist_2s.x =ID_onlist_2s.y= -1;
	if (!back_bd1_a.empty() && !back_bd2_a.empty() )
	{
		ID_onlist_1s = checkPtlistByPtsPool(&back_bd1_a,bdPts_L);
		ID_onlist_2s = checkPtlistByPtsPool(&back_bd2_a,bdPts_R);
		if (bdPts_L.size() * 3 < back_bd1_a.size() || bdPts_R.size() * 3 < back_bd2_a.size())return;
		
		if (ID_onlist_1s.x == -1 || ID_onlist_2s.x == -1)return;
		for(i = ID_onlist_1s.x ; i< ID_onlist_1s.y+1 ;i++)back_bd1.push_back(back_bd1_a.data()[i]);
		for(i = ID_onlist_2s.x ; i< ID_onlist_2s.y+1 ;i++)back_bd2.push_back(back_bd2_a.data()[i]);

		ID_onlist_1s.x = back_bd1_a.data()[ID_onlist_1s.x].ID;ID_onlist_1s.y = back_bd1_a.data()[ID_onlist_1s.y].ID;
		ID_onlist_2s.x = back_bd2_a.data()[ID_onlist_2s.x].ID;ID_onlist_2s.y = back_bd2_a.data()[ID_onlist_2s.y].ID;
		back_bd1_a.clear();back_bd2_a.clear();
	}	
	c_comb->clear();
}

void Plane_Plane_Relation::caculateRobustRidgesFirst()
{
	if (m_p1->isUnRoboustPlane || m_p2->isUnRoboustPlane)
	{
		 m_eg->edgeType = Undecided;		
		 m_eg->p1 = m_eg->p2 = NULL;
		 return;
	}
	assert (m_p1 != NULL  && m_p2 != NULL);
	m_eg->p1=m_eg->p2 = NULL;
//	m_eg->edgeType = Undecided;
	ID_onlist_1.x = ID_onlist_1.y = ID_onlist_2.x = ID_onlist_2.y = -1;
	
	int nPtPairs = plist->size();
	double dis_1,dis_2;
	m_sigma=0;
	for(int i = 0;i< nPtPairs; i++)
	{
		dis_1 = fabs( m_p1->calDisPt2Plane(plist->data()[i].pt2));
        dis_2 = fabs( m_p2->calDisPt2Plane(plist->data()[i].pt1));
		addPt2Vectors_noRepick(bdPts_L,plist->data()[i].pt1);
		addPt2Vectors_noRepick(bdPts_R,plist->data()[i].pt2);
		dis_1 = fmin(dis_1,dis_2);

		m_sigma += dis_1 * dis_1;
	}
	m_sigma /= nPtPairs;

	caculateRidgeParameter();	
	markCommonPtsBetweenTwoClouds();
	
	
	if (! (m_p2->flag_IsInsidePlane && m_p2->fatherID == m_p1->ID))
	{	
		id_back1= getBdIDofRidgeEnds(m_p1,&back_bd1,r_srcPt,r_nv,4*m_p1->aveDis); 
		id_back2= getBdIDofRidgeEnds(m_p2,&back_bd2,r_srcPt,r_nv,4*m_p2->aveDis);
		if (id_back1.x != -1 && id_back2.x != -1)
		{
			ID_onlist_1.x = findPtInPtList(&m_p1->m_outsideBD->m_pts,back_bd1.data()[id_back1.x].m_p);
			ID_onlist_1.y = findPtInPtList(&m_p1->m_outsideBD->m_pts,back_bd1.data()[id_back1.y].m_p);
			ID_onlist_2.x = findPtInPtList(&m_p2->m_outsideBD->m_pts,back_bd2.data()[id_back2.x].m_p);
			ID_onlist_2.y = findPtInPtList(&m_p2->m_outsideBD->m_pts,back_bd2.data()[id_back2.y].m_p);
			
		}	
		
		caculateRidegeEnds();

	}
	else
	{
		CCVector2 m_pro;
		if (caculateRelatationBetwweenLoopsAndEdge(&m_p2->m_outsideBD->m_pts, r_srcPt,r_nv,&ID_onlist_2,&m_pro))
		{
			m_eg->p1=calPtInLine(&r_srcPt,&r_nv,m_pro.x);
			m_eg->p2=calPtInLine(&r_srcPt,&r_nv,m_pro.y);
			m_eg->p1->PtStab =m_eg->p2->PtStab = Extensible;
			m_eg->p1->onBD = m_eg->p2->onBD = false;
			m_eg->edgeType = Inside;
			TP_Plane_ridgeMessage *mes=new TP_Plane_ridgeMessage;
			mes->ridge=m_eg->ID;
			mes->m_edge=m_eg;
			mes->n_bd=mes->n_bd=0;
			mes->list_start=ID_onlist_2.x;mes->list_end=ID_onlist_2.y;mes->isPlaneID_large = false;//单个平面 当做小面 边界链方向为反向;
			m_p2->m_ridgesMessage.push_back(*mes);
			m_p2->m_GEdges.push_back(m_eg);
		}
	}


	
}