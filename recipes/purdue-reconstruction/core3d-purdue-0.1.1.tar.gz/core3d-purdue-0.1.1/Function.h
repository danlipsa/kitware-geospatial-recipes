#ifndef __LiDAR_POINT_PROCESS_FACADE_ALPHA_SHAPE_EDGE_H__
   #define __LiDAR_POINT_PROCESS_FACADE_ALPHA_SHAPE_EDGE_H__

#include "topologyDataStructure.h"
#include <exception>

struct ImageLine
{
	long ID;
	int img_id;
	double x1,y1,x2,y2;
	CCVector3 pt1,pt2;
};

template <class T> 
struct CmpType 
{ 
	T val;
	int id;
	CmpType(){};
	CmpType(T m_val,int m_id){val = m_val; id = m_id;}
}; 
template <class T> 
int cmp1( const void *a , const void *b) //for sort 1 down sort
{
	 return( (*(CmpType<T> *)b).val - (*(CmpType<T> *)a).val )> 0 ? 1: -1;
}
template <class T> 
int cmp2( const void *a , const void *b) //for sort  2 up
{
	 return ( (*(CmpType<T> *)a).val - (*(CmpType<T> *)b).val )> 0 ? 1: -1;
}


template <class T> 
int searchInVector(vector<T > m_data, T goal)
{
	for (int i=0;i< m_data.size();i++)
	{
		if (m_data.data()[(i)] == goal)
		{
			return i;
		}
	}
	return -1;
}

//boundary
TP_PlaneBoundary *generateEdge(ccPointCloud const *input,double alpha,int *n_outBD);
TP_PlaneBoundary * generateEdge_adaptedAlpha(ccPointCloud const *input,double *alpha,int *n_outBD);
//convex boundary
//void GetConvexBB(BoundaryPts *m_bd);
 void GetConvexBB(TP_PlaneBoundary *m_tpbd,TP_PtList *convexBD);

 //TP_PtList related
  bool getDistanceOfTwoList(TP_PtList *p1,TP_PtList *p2);
  void findEdgeBetweenTwoClouds(ccPointCloud * c1,ccPointCloud *c2,TP_PtList *back_1,TP_PtList*back_2,float m_alpha);
  void compareEdgeLists(TP_PtList *baselist,TP_PtList *testList,TP_PlaneBoundary * bd,int id=0);
  void compareTwoEdges(TP_PtList *baselist,TP_PtList *testList,int id_same=1,int type=0);
  void getPartOfPtsFromLoop(TP_PtList *m_list,TP_PtList *m_back, int id_start, int id_end,bool flag_inverse = false);
  void refreshTP_ListByDeleteFlag(TP_PtList *m_l);
  //void refreshTP_ListByDeleteFlag(TP_PtList &m_l);
  int findPtInPtList(TP_PtList *m_data,CCVector3 pt);
  void fitContinuePartsInLoop(int *m_flags,int n_pts,vector<CCVector2i > *list_in);
  int findIDinList(TP_PtList *pts,int ID,int id_min,int id_max);
  int findMixBDIDinList(TP_PtList *pts,int ID,int id_min,int id_max);
  CCVector3 caculateListCenter(TP_PtList *pts);
  void getBBofPtlist(TP_PtList *pts, CCVector3 *left_down, CCVector3 *right_up);
  void getBBofCCVector3list(vector<CCVector3> *pts, CCVector3 *left_down, CCVector3 *right_up);

 //distance
 double calDisPt2LineSegment_2d(CCVector3 *pt,CCVector3 *l1,CCVector3 *l2,int type=0);
 double calProPt2LineSegment_2d(CCVector3 *pt,CCVector3 *l1,CCVector3 *l2);
 double calDisP2P_2(CCVector3 * srcPt,const CCVector3 *pt);
 double calDisP2P_xyz_sqrt(const CCVector3 p1,const CCVector3 p2);
 double calDisP2P_xy_sqrt(CCVector3 * srcPt,const CCVector3 *pt);
 double calProDis_P2L_3d(CCVector3 * srcPt,CCVector3 *lineNv,const CCVector3 *pt);
 TP_Vertex *calPtInLine(CCVector3 * srcPt,CCVector3 *lineNv, double pro);
 int PtInList_2d(const CCVector3 *pt, TP_PtList *src);
 void pNormal(double *a,int n,double b,double *aa, double *ab,double p);
 void calProjectionPoint(CCVector3 l_end1,CCVector3 l_end2,const CCVector3 pt,CCVector3 *proPt);
 void calProjectionPoint_2d(CCVector3 l_end1, CCVector3 l_end2, const CCVector3 pt, CCVector3 *proPt);
 
 //line intersect line
 bool IsInterSect(CCVector3 p,CCVector3 q,CCVector3 arr1,CCVector3 arr2);
 bool IsInterSect_Seg_Line(CCVector3 p,CCVector3 q,CCVector3 arr1,CCVector3 arr2);
 CCVector3* LineIntersectLine(CCVector3 p1,CCVector3 p2,CCVector3 p3,CCVector3 p4);
 bool IsParallelLines(CCVector3 p,CCVector3 q,CCVector3 arr1,CCVector3 arr2);
 
 //rect related
 int IsPtInRectList(TP_PtList *list,const CCVector3 &p); 
 double areaInArea(TP_PtList *largeBD,TP_PtList *smallBD);
 double polygon_area(TP_PtList *m_list);
 double polygon_length(TP_PtList *m_list);
 
 //ridge
 double calculateRidgeSimilarity(CCVector3 Pt_a,CCVector3 Pt_b,CCVector3 Pt_c,CCVector3 Pt_d);
 

 int decideRelationshipBetweentwoNormals(CCVector3 nv1,CCVector3 nv2);
 void deleteRepickPtsInLoops(TP_PtList *m_input);


 CCVector2 generateEdgeOri_byMaxProjDensity(TP_PtList *eg,double sigma,int _type);

 bool is_normal_Tw_outside(CCVector3 cenPt, CCVector3 nv, CCVector3 eg_Pt1, CCVector3 eg_Pt2);

#endif