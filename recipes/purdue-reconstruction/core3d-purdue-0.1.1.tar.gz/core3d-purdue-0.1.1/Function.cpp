//#include "stdafx.h"
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/algorithm.h>
#include <CGAL/Delaunay_triangulation_2.h>
#include "CGAL/Alpha_shape_2.h"
#include <CGAL/convex_hull_2.h>

#include "Function.h"


typedef CGAL::Exact_predicates_inexact_constructions_kernel K;

typedef K::FT FT;
typedef K::Point_2  Point;
typedef K::Segment_2  Segment;

typedef CGAL::Alpha_shape_vertex_base_2<K> Vb;
typedef CGAL::Alpha_shape_face_base_2<K>  Fb;
typedef CGAL::Triangulation_data_structure_2<Vb,Fb> Tds;
typedef CGAL::Delaunay_triangulation_2<K,Tds> Triangulation_2;

typedef CGAL::Alpha_shape_2<Triangulation_2>  Alpha_shape_2;
typedef Alpha_shape_2::Alpha_shape_edges_iterator Alpha_shape_edges_iterator;

inline double calDis2_2(double x1,double y1,double x2,double y2)
{
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
/*
inline double calDis3_3(triPOINT *P1,triPOINT* P2)
{
	
	return sqrt((P1->x-P2->x)*(P1->x-P2->x)+(P1->y-P2->y)*(P1->y-P2->y)+(P1->attr-P2->attr)*(P1->attr-P2->attr));
}
*/

double calDisP2P_2(CCVector3 * srcPt,const CCVector3 *pt)//注意 没有开方！！
{
	double dx,dy,dz;
	dx = srcPt->x - pt->x;
	dy = srcPt->y - pt->y;
	dz = srcPt->z - pt->z;
	return (dx*dx+dy*dy+dz*dz);
}

double calDisP2P_xyz_sqrt(const CCVector3 p1,const CCVector3 p2)
{
	return sqrt(pow((p1.x-p2.x),2)+pow((p1.y-p2.y),2)+pow((p1.z-p2.z),2));
}


double calDisP2P_xy_sqrt(CCVector3 * srcPt,const CCVector3 *pt)
{
	double dx,dy;
	dx = srcPt->x - pt->x;
	dy = srcPt->y - pt->y;

	return sqrt(dx*dx+dy*dy);
}



double calProDis_P2L_3d(CCVector3 * srcPt,CCVector3 *lineNv,const CCVector3 *pt)
{
	double dx,dy,dz;
	dx = -srcPt->x + pt->x;
	dy = -srcPt->y + pt->y;
	dz = -srcPt->z + pt->z;
	double proDis= dx * lineNv->x + dy * lineNv->y +dz * lineNv->z;
	return proDis;	
}
void calProjectionPoint(CCVector3 l_end1,CCVector3 l_end2,const CCVector3 pt,CCVector3 *proPt)
{	
	CCVector3 delt_L = l_end2 - l_end1; 
	double dis = sqrt(delt_L.x * delt_L.x + delt_L.y * delt_L.y + delt_L.z * delt_L.z );
	CCVector3  nv = delt_L * (1/ dis);
	double pro = calProDis_P2L_3d(&l_end1,&nv,&pt);
	*proPt  = l_end1 + nv*pro;
}
void calProjectionPoint_2d(CCVector3 l_end1, CCVector3 l_end2, const CCVector3 pt, CCVector3 *proPt)
{
	CCVector3 pt1 = pt; 
	l_end1.z = l_end2.z = proPt->z = 0;
	pt1.z = 0;
	CCVector3 delt_L = l_end2 - l_end1;
	double dis = sqrt(delt_L.x * delt_L.x + delt_L.y * delt_L.y + delt_L.z * delt_L.z);
	CCVector3  nv = delt_L * (1 / dis);
	double pro = calProDis_P2L_3d(&l_end1, &nv, &pt1);
	*proPt = l_end1 + nv*pro;
}
TP_Vertex *calPtInLine(CCVector3 * srcPt,CCVector3 *lineNv, double pro)
{
	TP_Vertex *back_pt=new TP_Vertex ;

	back_pt->m_p.x =srcPt->x + lineNv->x * pro;
	back_pt->m_p.y  =srcPt->y + lineNv->y * pro;
	back_pt->m_p.z  =srcPt->z + lineNv->z * pro;

	return back_pt;
}


bool compareTP_Pt_2(CCVector3 *p1,CCVector3 *p2)
{
	return sqrt(pow((p1->x-p2->x),2)+pow((p1->y-p2->y),2)) < 0.001? true:false;
}
bool compareTP_Pt_2_v2(CCVector2 *p1,CCVector2 *p2)
{
	return sqrt(pow((p1->x-p2->x),2)+pow((p1->y-p2->y),2)) < 0.1? true:false;
}
bool compareTP_vertex(TP_Vertex *p1,TP_Vertex *p2)
{
	return compareTP_Pt_2(&p1->m_p,&p2->m_p);		
}

int PtInList_2d(const CCVector3 *pt, TP_PtList *src)
{
	if (src == NULL || src->size()== 0)return -1;
	int n_pts=src->size();

	CCVector3 *ptNow=new CCVector3;
	ptNow->x=pt->x;
	ptNow->y=pt->y;
	ptNow->z=pt->z;

	for (int i=0;i<n_pts;i++)
	{
		if (compareTP_Pt_2(ptNow,&src->data()[(i)].m_p) == true)
		{
			return i;
		}
	}
	return -1;
}


double calProPt2LineSegment_2d(CCVector3 *pt,CCVector3 *l1,CCVector3 *l2)
{
	return  ((pt->x - l1->x)*(l2->x-l1->x)+(pt->y - l1->y)*(l2->y-l1->y))/sqrt(pow((l2->x-l1->x),2)+ pow((l2->y-l1->y),2));
}
double calDisPt2LineSegment_2d(CCVector3 *pt,CCVector3 *l1,CCVector3 *l2,int type)
{
	double eps=0.00001; 
	double dis_line=calDis2_2(l1->x,l1->y,l2->x,l2->y);
	double dis_pt_line=calDis2_2(l1->x,l1->y,pt->x,pt->y);
	if (dis_line < eps)  return dis_pt_line;
	
	double pro=calProPt2LineSegment_2d(pt,l1,l2);
		 
	double dis;
	
	if (type == 1)//到直线距离
	{
		if (fabs(dis_pt_line - pro)  < eps ) dis= 0;
		else 
		{		
			dis = sqrt(fabs(dis_pt_line*dis_pt_line - pro*pro));
		}
	}
	else //到线段距离
	{
		if (pro > 0 && pro < dis_line)
		{
			if (fabs(dis_pt_line - pro)  < eps ) dis= 0;
			else 
				dis= sqrt(fabs(dis_pt_line*dis_pt_line - pro*pro));
		}
		else
		{			
			dis= min(dis_pt_line,calDis2_2(l2->x,l2->y,pt->x,pt->y));
		}
	}
	assert (dis >= 0);
	return dis;
}
int findPtInPtList(TP_PtList *m_data,CCVector3 pt)
{
	for (long i=0;i< m_data->size();i++)
	{
		if (compareTP_Pt_2(&m_data->data()[(i)].m_p,&pt))return i;
	}
	return -1;
}
int findPtInPtList_v2(vector<CCVector2 > *m_data,CCVector2 pt)
{
	for (long i=0;i< m_data->size();i++)
	{
		if (compareTP_Pt_2_v2(&m_data->data()[(i)],&pt))return i;
	}
	return -1;
}

bool getDistanceOfTwoList(TP_PtList *p1,TP_PtList *p2)
{
	int i,j;
	int nP1=p1->size();
	int nP2=p2->size();
	CCVector3 *pt_1,*pt_2a,*pt_2b;
	double dis,dismin;
	
	int *nearestPt=new int[nP1];
	memset(nearestPt,-1,sizeof(int)*nP1);
	
		
		for (i=0;i<nP1;i++)
		{
			pt_1=&p1->data()[(i)].m_p;
			dismin=9999;
			for(j=0;j<nP2-1;j++)
			{
				pt_2a=&p2->data()[(j)].m_p;
				pt_2b=&p2->data()[(j+1)].m_p;
				dis=calDisPt2LineSegment_2d(pt_1,pt_2a,pt_2b);	   
				if(dis < 1 && dis <dismin)
				{
					dismin=dis;
					nearestPt[i]=j;
				}
			}
		}
		int count=0;
		for (i=0;i<nP1;i++)
		{
			
			if (nearestPt[i] != -1)
			{
				delete []nearestPt;
				return true;
			}
		}
		delete []nearestPt;
		return false;	
}

void getPartOfPtsFromLoop(TP_PtList *m_list,TP_PtList *m_back, int id_start, int id_end,bool flag_inverse)
{	
	int i,n_pts=m_list->size();
	assert(min(id_start,id_end) >=0 && max(id_start,id_end) <= n_pts );

	if (flag_inverse == false)
	{
		if (id_start <= id_end)
		{
			for (i=id_start;i< (id_end+1) && i != n_pts;i++)
			{
				m_back->push_back(m_list->data()[(i)]);
			}
		}
		else
		{
			for (i=id_start;i<n_pts ;i++)
			{
				m_back->push_back(m_list->data()[(i)]);
			}
			for (i=0;i<(id_end+1)&& i != n_pts;i++)
			{
				m_back->push_back(m_list->data()[(i)]);
			}
		}
	}
	else
	{
		if (id_start <= id_end)
		{
			for (i=id_end-1;i != id_start-1;i--)
			{
				m_back->push_back(m_list->data()[(i)]);
			}
		}
		else
		{

			for (i=id_end-1;i != -1 ;i--)
			{
				m_back->push_back(m_list->data()[(i)]);
			}
			for (i=n_pts-1 ;i!= id_start-1;i--)
			{
				m_back->push_back(m_list->data()[(i)]);
			}
		}
	}
		
}
 double cross(CCVector3 pi,CCVector3 pj,CCVector3 pk)
 { 
	 return (pj.x-pi.x)*(pk.y-pi.y)-(pj.y-pi.y)*(pk.x-pi.x);  
 }  
 int InPolygon(const CCVector3 *arr,const int &len,const CCVector3 &p,int on_edge=1)
 {  
	 CCVector3 q; 
	 int offset=1000;  
	 double eps=0.00001;  
	 int i=0,counter;  
	 while(i<len){  
		 q.x=rand()+offset;//随机取一个足够远的点q  
		 q.y=rand()+offset;//以p为起点q为终点做射线L  
		 for(counter=i=0;i<len;i++){//依次对多边形的每条边进行考察  
			 if(fabs(cross(p,arr[i],arr[(i+1)%len]))<eps &&  
				 (arr[i].x-p.x)*(arr[(i+1)%len].x-p.x)<eps && (arr[i].y-p.y)*(arr[(i+1)%len].y-p.y)<eps)  
				 return on_edge; //点p在边上,返回on_edge  
			 else if(fabs(cross(p,q,arr[i]))<eps) break; //点arr[i]在射线pq上，停止本循环，另取q  
			 else if(cross(p,arr[i],q)*cross(p,arr[(i+1)%len],q)<-eps &&  
				 cross(arr[i],p,arr[(i+1)%len])*cross(arr[i],q,arr[(i+1)%len])<-eps)  
				 counter++;  
		 }  
	 }  
	 return counter&1;  
 }

 int IsPtInRectList(TP_PtList *list,const CCVector3 &p)
 {
	 CCVector3 q; 
	 int on_edge=1;
	 long len = list->size();
	 int offset=1000;  
	 double eps=0.00001;  
	 int i=0,counter;  
	 while(i<len){  
		 q.x=rand()+offset;//随机取一个足够远的点q  
		 q.y=rand()+offset;//以p为起点q为终点做射线L  
		 for(counter=i=0;i<len;i++){//依次对多边形的每条边进行考察  
			 if(fabs(cross(p,list->data()[(i)].m_p,list->data()[((i+1)%len)].m_p))<eps &&  
				 (list->data()[(i)].m_p.x-p.x)*(list->data()[((i+1)%len)].m_p.x-p.x)<eps && (list->data()[(i)].m_p.y-p.y)*(list->data()[((i+1)%len)].m_p.y-p.y)<eps)  
				 return on_edge; //点p在边上,返回on_edge  
			 else if(fabs(cross(p,q,list->data()[(i)].m_p))<eps) break; //点arr[i]在射线pq上，停止本循环，另取q  
			 else if(cross(p,list->data()[(i)].m_p,q)*cross(p,list->data()[((i+1)%len)].m_p,q)<-eps &&  
				 cross(list->data()[(i)].m_p,p,list->data()[((i+1)%len)].m_p)*cross(list->data()[(i)].m_p,q,list->data()[((i+1)%len)].m_p)<-eps)  
				 counter++;  
		 }  
	 }  
	 return counter&1; 
 }


void pNormal(double *a,int n,double b,double *aa, double *ab,double p)
{
	int  i,j;

	for (i=0; i<n; i++) 
	{
		for (j=0; j<n; j++) 
			*aa++ += p* a[i] * a[j];

		*ab++ += p* a[i] * b;
	}

}
 //  alpha_edges


template <class OutputIterator>
void alpha_edges( const Alpha_shape_2&  A,OutputIterator out)
{
	for(Alpha_shape_edges_iterator it =  A.alpha_shape_edges_begin();
		it != A.alpha_shape_edges_end();
		++it){
			*out++ = A.segment(*it);
	}
}

bool is_bd_clockwise(TP_PtList *pList)
{
	bool is_clockwise = false;
	double m_area = 0;
	for (int i=0; i< (pList->size()-1) ; i++)
	{
		m_area += (pList->data()[(i+1)].m_p.x - pList->data()[(i)].m_p.x) *(pList->data()[(i+1)].m_p.y + pList->data()[(i)].m_p.y)/2;
	}
	m_area += (pList->front().m_p.x - pList->back().m_p.x) *(pList->front().m_p.y + pList->back().m_p.y)/2;
	if ( m_area < 0) return false;
	else return true;
	
}


 bool connectLineSegments(vector<Segment> segments,TP_PlaneBoundary *boundary)
{
	int n_seg=segments.size();
	if (n_seg == 0)return false;

	Segment seg_result;	
	TP_PlaneBoundary m_temp;
	BoundaryPts *bd_src=new BoundaryPts;
	BoundaryPts *pbdNow=bd_src;
	m_temp.push_back(pbdNow);

	long i,j;
	double x1,y1,x2,y2;
	double *pPts=new double[n_seg*4];
	bool *flag_segChoosed=new bool[n_seg];
	
	for (i=0;i<n_seg;i++)
	{
		flag_segChoosed[i]=false;
		seg_result=segments.data()[(i)];
		pPts[4*i]=seg_result.point(0).x();
		pPts[4*i+1]=seg_result.point(0).y();
		pPts[4*i+2]=seg_result.point(1).x();
		pPts[4*i+3]=seg_result.point(1).y();
	}
	
	TP_Vertex pStart;
	pStart.m_p.x=pPts[0];
	pStart.m_p.y=pPts[1];
	pbdNow->m_pts.push_back(pStart);
	x1=pPts[2];
	y1=pPts[3];
	flag_segChoosed[0]=true;
	int n_segChoosed=1;

	bool flag_findPt= true;
	while (n_segChoosed < n_seg)
	{
		if (flag_findPt == false)//上一轮中没找到点，即可能有多个环
		{
			if(!(n_segChoosed < n_seg)) break;		
			BoundaryPts *bd_new=new BoundaryPts;
			pbdNow=bd_new;
			m_temp.push_back(pbdNow);
			for (i=0;i<n_seg;i++)
			{
				if (flag_segChoosed[i] == true)continue;
				pStart.m_p.x=pPts[4*i];pStart.m_p.y=pPts[4*i+1];
				pbdNow->m_pts.push_back(pStart);
				x1=pPts[4*i+2],y1=pPts[4*i+3];
				n_segChoosed++;
				flag_segChoosed[i]=true;
				break;
			}

		}
		flag_findPt = false;
		for (i=0;i<n_seg;i++)
		{				
			if (flag_segChoosed[i] == true)continue;

			x2=pPts[4*i];
			y2=pPts[4*i+1];
			if (calDis2_2(x1,y1,x2,y2) < 0.01)
			{
				pStart.m_p.x=x2;pStart.m_p.y=y2;
				pbdNow->m_pts.push_back(pStart);
				flag_segChoosed[i]=true;
				x1=pPts[4*i+2],y1=pPts[4*i+3];
				n_segChoosed++;
				flag_findPt=true;
				break;				
			}
			x2=pPts[4*i+2];
			y2=pPts[4*i+3];
			if (calDis2_2(x1,y1,x2,y2) < 0.01)
			{
				pStart.m_p.x=x2;pStart.m_p.y=y2;
				pbdNow->m_pts.push_back(pStart);
				flag_segChoosed[i]=true;
				x1=pPts[4*i],y1=pPts[4*i+1];
				n_segChoosed++;
				flag_findPt=true;
				break;
			}

		}

	}

	for (i=0;i<m_temp.size();i++)
	{
		if (m_temp.data()[(i)]->m_pts.size() > 5)
		{						
			if ( is_bd_clockwise(&m_temp.data()[(i)]->m_pts))	//保证边界按逆时针排列;
			{
				TP_PtList L_temp = m_temp.data()[(i)]->m_pts;
				m_temp.data()[(i)]->m_pts.clear();

				for (j = L_temp.size()-1; j >=0 ; j--)
				{
					m_temp.data()[(i)]->m_pts.push_back(L_temp.data()[(j)]);
				}
			}

			boundary->push_back(m_temp.data()[(i)]);
		}

	}
	delete []pPts;
	delete []flag_segChoosed;

	return true;
}

//convex
void GetConvexBB(TP_PlaneBoundary *m_tpbd,TP_PtList *convexBD)
//void GetConvexBB(BoundaryPts *m_bd)
{
	assert(m_tpbd != NULL);
	vector<Point> points, result;
	CCVector3 *pt=NULL;
	BoundaryPts *m_bd = NULL;
	for(int i_bd=0;i_bd<m_tpbd->size();i_bd++)
	{
		m_bd = m_tpbd->data()[(i_bd)];
		for(long i=0;i<m_bd->m_pts.size();i++)
		{
			pt=&m_bd->m_pts.data()[(i)].m_p;
			points.push_back(Point(pt->x,pt->y));
		}
	}
	
	CGAL::convex_hull_2( points.begin(), points.end(), std::back_inserter(result) );

	for(long i=0;i<result.size();i++)
	{
		CCVector3 ptAdd(result.data()[(i)].x(),result.data()[(i)].y(),0);
		
		for(int i_bd=0;i_bd<m_tpbd->size();i_bd++)
		{
			m_bd = m_tpbd->data()[(i_bd)];
			int id=findPtInPtList(&m_tpbd->data()[(i_bd)]->m_pts,ptAdd);
			if (id != -1)
			{
				convexBD->push_back(m_bd->m_pts.data()[(id)]);
				break;
			}
		}
	}	
}

//methods

double cross1(CCVector3 pi,CCVector3 pj,CCVector3 pk)
{ 
	return (pj.x-pi.x)*(pk.y-pi.y)-(pj.y-pi.y)*(pk.x-pi.x);  
}  
double polygon_area(TP_PtList *m_list)
{
	double area = 0.0;
	CCVector3 temp(0,0,0);
	for (int i = 0; i < m_list->size(); i++)
	{
		area += cross1(temp, m_list->data()[(i)].m_p, m_list->data()[((i+1)%m_list->size())].m_p);
	}
	return fabs(area/2);
 }
double polygon_length(TP_PtList *m_list)
{
	double len = 0;
	CCVector3 pt1,pt2;
	long npt = m_list->size();
	for (int i = 0; i < npt; i++)
	{
		pt1 = m_list->at(i).m_p;
		pt2 = m_list->at((i+1)%npt).m_p;
		len += calDis2_2(pt1.x,pt1.y,pt2.x,pt2.y);
	}
	return len;
}




bool IsInterSect(CCVector3 p,CCVector3 q,CCVector3 arr1,CCVector3 arr2)
{
	double eps = 0.0001;
	if(cross1(p,arr1,q)*cross1(p,arr2,q)<-eps &&  cross1(arr1,p,arr2)*cross1(arr1,q,arr2)<-eps)return true;

	else return false;
}

bool IsInterSect_Seg_Line(CCVector3 p,CCVector3 q,CCVector3 arr1,CCVector3 arr2)//后面两点在前面两点的两侧;
{
	double eps = 0.0001;
	if(cross1(arr1,p,arr2)*cross1(arr1,q,arr2)<-eps)return true;

	else return false; 
}

bool IsParallelLines(CCVector3 p,CCVector3 q,CCVector3 arr1,CCVector3 arr2)
{
	if (calDisP2P_xy_sqrt(&p,&q) < 0.2 || calDisP2P_xy_sqrt(&arr1,&arr2) < 0.2)return false;
	
	CCVector3 n_1=q-p;
	CCVector3 n_2=arr2-arr1;
	double sita = fabs (n_1.x*n_2.x + n_1.y * n_2.y)/sqrt((n_1.x*n_1.x + n_1.y*n_1.y)*(n_2.x*n_2.x + n_2.y*n_2.y));
	if (sita> cos(3*PI / 180))return true;
	else return false;
}



CCVector3* LineIntersectLine(CCVector3 p1,CCVector3 p2,CCVector3 p3,CCVector3 p4)
{
	CCVector3 *m_back=new CCVector3;
	m_back->y = ((p3.x-p1.x)*(p2.y-p1.y)*(p4.y-p3.y) + ((p4.y-p3.y)*(p2.x-p1.x)*p1.y
		-(p2.y-p1.y)*(p4.x-p3.x)*p3.y))/((p4.y-p3.y)*(p2.x-p1.x)-(p2.y-p1.y)* (p4.x-p3.x));
	if (fabs(p2.y-p1.y)> fabs(p4.y-p3.y) )
	{
		m_back->x = (m_back->y- p1.y)*(p2.x-p1.x)/(p2.y-p1.y)+p1.x;
	}
	else m_back->x = (m_back->y- p3.y)*(p4.x-p3.x)/(p4.y-p3.y)+p3.x;

	m_back->z = 0;
	return m_back;
}

void fitContinuePartsInLoop(int *m_flags,int n_pts,vector<CCVector2i > *list_in)
{	
	int i;
	std::list<int > startpts;
	std::list<int > endpts;
	std::list<int >::iterator  itr1,itr2;
	for(i=0;i<n_pts;i++)
	{
		if (m_flags[i]- m_flags[(i-1+n_pts)%n_pts] == 1)  startpts.push_back(i);
		if (m_flags[(i+1)%n_pts]-m_flags[i] == (-1)) endpts.push_back(i);			
	}
	assert(startpts.size() == endpts.size());
	if (startpts.size()==0)return;

	if (startpts.front() > endpts.front())//首尾相连
	{
		int i_first=endpts.front();endpts.pop_front();endpts.push_back(i_first);
	}

	for (itr1=startpts.begin(),itr2=endpts.begin();itr1 != startpts.end();itr1++,itr2++)
	{
		CCVector2i segs; segs.x = (*itr1);segs.y = (*itr2);list_in->push_back(segs);
	}


}

TP_Vertex* Line_insert_Rect(TP_PtList *m_rectPts,CCVector3 p1,CCVector3 p2)
{
	TP_Vertex *m_back =new TP_Vertex;
	CCVector3 *p_back=NULL;
	for (int i=0;i<m_rectPts->size();i++)
	{
		CCVector3 rpt1=m_rectPts->data()[(i)].m_p;
		CCVector3 rpt2=m_rectPts->data()[((i+1)%m_rectPts->size())].m_p;
		if (IsInterSect(rpt1,rpt2,p1,p2))
		//if (IsIntersectLine(rpt1,rpt2,p1,p2))				
		{
			m_back->m_p = *(LineIntersectLine(rpt1,rpt2,p1,p2));
			m_back->ID = i;
			return m_back;
		}
	}
	delete m_back;
	return NULL;
}


double commonPartOftwoRect(TP_PtList *R_large,TP_PtList *R_small,CCVector2i inside_ids/*在大边界内部的点的id*/)
{
	CCVector3 in_1,in_2,out_1,out_2;
	int id1,id2;
	int n_large=R_large->size(),n_small = R_small->size();
	id1= inside_ids.x;id2=inside_ids.y;

	in_1 = R_small->data()[(id1)].m_p;out_1 =R_small->data()[((id1+n_small-1)%n_small)].m_p;
	in_2 = R_small->data()[(id2)].m_p;out_2 =R_small->data()[((id2+n_small+1)%n_small)].m_p;

	TP_Vertex *lar_1= Line_insert_Rect(R_large,in_1,out_1);
	TP_Vertex *lar_2= Line_insert_Rect(R_large,in_2,out_2);

	if (lar_1 == NULL || lar_2 == NULL )return 0;

	TP_PtList commonRect;
	commonRect.push_back(*lar_1);
	
	if (lar_1->ID != lar_2->ID)//大边界上有点在小环内部,需要判断哪边是对的;
	{
		TP_PtList temp1,temp2;
		CCVector3 *rectPts_small=new CCVector3 [n_small];
		for (int i=0;i<n_small;i++)rectPts_small[i]= (R_small->data()[(i)].m_p);
		int count1,count2;count1 = count2 = 0;
        getPartOfPtsFromLoop(R_large,&temp1,(lar_2->ID+1)%n_large,lar_1->ID,false);
		getPartOfPtsFromLoop(R_large,&temp2,(lar_1->ID+1)%n_large,lar_2->ID,false);
		int *flag_1=new int[n_large];memset(flag_1,0,sizeof(int)*n_large);
		for(int i=0;i< n_large;i++) if (InPolygon(rectPts_small,n_small,R_large->data()[i].m_p)){flag_1[i]= 1;}
		for(int i=0;i< temp1.size();i++)if (flag_1[i]== 0){count1++;}	
		for(int i=0;i< temp2.size();i++)if (flag_1[i]== 0){count2++;}
		if(count1 == 0  && count2 == 0)return 0;
		
		if (count1 < count2)getPartOfPtsFromLoop(R_large,&commonRect,(lar_2->ID+1)%n_large,lar_1->ID,false);//选外部点少的;
		else getPartOfPtsFromLoop(R_large,&commonRect,(lar_1->ID+1)%n_large,lar_2->ID,false);
		temp1.clear();temp2.clear();delete []rectPts_small;delete[]flag_1;
	}	
	commonRect.push_back(*lar_2);
	getPartOfPtsFromLoop(R_small,&commonRect,id1,(id2+1)%n_small,false);	
	return polygon_area(&commonRect);

}
/*
double commonAreaRatio(TP_PtList *l_1,TP_PtList *l_2)
{
	long npt1=l_1->size();
	long npt2=l_2->size();
	CCVector3 *rectPts1=new CCVector3 [npt1];
	CCVector3 *rectPts2=new CCVector3 [npt2];
	int *flag_1=new int[npt1];memset(flag_1,0,sizeof(int)*npt1);
	int *flag_2=new int[npt1];memset(flag_1,0,sizeof(int)*npt1);

	long i,count1,count2;	
	for (i=0;i<npt1;i++)rectPts1[i]= (l_1->data()[(i)].m_p);
	for (i=0;i<npt2;i++)rectPts2[i]= (l_2->data()[(i)].m_p);
	
	for(i=0;i< npt1;i++)
	{
		if (InPolygon(rectPts2,npt2,l_1->data()[i].m_p)){flag_1[i] = 1;count1++;}		
	}
	for(i=0;i< npt2;i++)
	{
		if (InPolygon(rectPts1,npt1,l_2->data()[i].m_p)){flag_2[i] = 1;count2++;}		
	}
	//全在内部;
	if (count1 == npt1 || count2 == npt2)return 1.0;
	//至少有一个点在彼此内部;
	if (count1 == 0 && count2 == 0)return 0;
	//
	vector<CCVector2i > list_in_1,list_in_2;
	fitContinuePartsInLoop(flag_1,npt1,&list_in_1);
	fitContinuePartsInLoop(flag_2,npt2,&list_in_2);
}
*/

 double areaInArea(TP_PtList *largeBD,TP_PtList *smallBD)//公共部分面积占小面的比例;
 {
	 double area1 =  polygon_area(largeBD);
	 double area2 =  polygon_area(smallBD);
	 TP_PtList *l_1=NULL,*l_2=NULL;
	 l_1 = largeBD;
	 l_2 = smallBD;

	 double ratio=0;
	 long n_large=l_1->size();
	 long n_small=l_2->size();
	 CCVector3 *rectPts=new CCVector3 [n_large];
	 long i;	
	 for (i=0;i<n_large;i++)
	 {
		 rectPts[i]= (l_1->data()[(i)].m_p);
	 }
	 int count=0;

	 int *flag_in=new int[n_small];memset(flag_in,0,sizeof(int)*n_small);
	 for(i=0;i<n_small;i++)
	 {
		 if (InPolygon(rectPts,n_large,l_2->data()[(i)].m_p))
		 {flag_in[i] = 1;count++;}
	 }

	 if (count == n_small)ratio = 1;
	 else if (count == 0)ratio = 0;
	 else//计算内部的面积;
	 {
		 vector<CCVector2i > list_in;
		 fitContinuePartsInLoop(flag_in,n_small,&list_in);
		 //ratio = count/n_small;
		 double m_area=0;
		 for (i=0;i<list_in.size();i++)
		 {
			 m_area += commonPartOftwoRect(l_1,l_2,list_in.data()[(i)]);
		 }

		 ratio = m_area /min(area1,area2);
	 }
	 delete []rectPts;
	 delete []flag_in;
	 
	 return ratio;

 }
TP_PlaneBoundary * generateEdge(ccPointCloud const *input,double alpha,int *n_outBD)
{	
	TP_PlaneBoundary *boundary=new TP_PlaneBoundary;
	long i,m_npts=input->size();

//	std::list<Point> points;
	
	vector<Point> points;
	points.clear();
//	points.reserve(m_npts);
	for (i=0;i<m_npts;i++)
	{
		const CCVector3 *pt=&input->at(i);
		Point addPt((double)pt->x,(double)pt->y);			   
		points.push_back(addPt);
	}	

	vector<Segment> segments;
	
//	std::vector <Segment> segments;
//	try
	{
		Alpha_shape_2 A(points.begin(), points.end(),FT(10000),Alpha_shape_2::REGULARIZED);
		A.set_alpha(alpha);
		alpha_edges( A, std::back_inserter(segments));
	}	
//	catch (exception* e)s
	{
		//alpha-shape may crash in some situation, use convex hull instead 
		//vector<Point>  result;
		//CGAL::convex_hull_2( points.begin(), points.end(), std::back_inserter(result) );
		//BoundaryPts *newbd = new BoundaryPts;
		//
		//for(long i=0;i<result.size();i++)
		//{
		//	TP_Vertex ptAdd;
		//	CCVector3 ptTemp(result.data()[(i)].x(),result.data()[(i)].y(),0);
		//	ptAdd.m_p = ptTemp; ptAdd.ID = i;
		//	newbd->m_pts.push_back(ptAdd);			
		//}
		//newbd->ID =0;
		//newbd->type = OUTSIDE_EDGE;
		//boundary->push_back(newbd);
		//return boundary;
	}
	
	
	connectLineSegments( segments,boundary);
	if (boundary->size() == 0)return NULL;

	int n_edge=boundary->size();
	for (i=0;i<n_edge;i++)boundary->data()[(i)]->ID=i;

	if (n_edge > 1)
	{		
		long maxCount=boundary->data()[(0)]->m_pts.size(),maxID=0;
		for (i=1;i<n_edge;i++)
		{
			
			if (boundary->data()[(i)]->m_pts.size() > maxCount)
			{
				maxCount=boundary->data()[(i)]->m_pts.size();
				maxID=i;
			}
		}
		TP_PtList *largeBD=&boundary->data()[(maxID)]->m_pts;
		boundary->data()[(maxID)]->type=OUTSIDE_EDGE;
		TP_PtList *smallBD=NULL;
		for (i=0;i<n_edge;i++)
		{
			if (i != maxID)
			{
				smallBD=&boundary->data()[(i)]->m_pts;
				if (areaInArea(largeBD,smallBD))
				{
					boundary->data()[(i)]->type=INNER_HOLE;
				}
				else boundary->data()[(i)]->type=OUTSIDE_EDGE;
				
			}
		}
	}
	else  boundary->data()[(0)]->type=OUTSIDE_EDGE;
	for (i=0;i<n_edge;i++)
	{
		boundary->data()[(i)]->alpha_scale = alpha;
		if (boundary->data()[(i)]->type == INNER_HOLE)continue;
		(*n_outBD)++;
		//CornerDetection_BD(boundary->data()[(i)],0.2);
	}
	

	return boundary;
}

TP_PlaneBoundary * generateEdge_adaptedAlpha(ccPointCloud const *input,double *alpha,int *n_outBD)
{
//	if (alpha_0 == 0) alpha_0 = alpha;
	long i;int n_outbd;
	TP_PlaneBoundary *m_boundarys =generateEdge(input,*alpha,&n_outbd);
	//alpha_scale = alpha;
	if (m_boundarys == NULL)return NULL;
	int bdCount = m_boundarys->size();
	if (bdCount > 1)
	{
		int out_count = 0;
		for (i=0;i< bdCount;i++) if (m_boundarys->data()[(i)]->type == OUTSIDE_EDGE)out_count ++;
		if (out_count > 1)
		{
			for (i=0;i< bdCount;i++) delete m_boundarys->data()[(i)];
			m_boundarys->clear();
			(*alpha) *= 2;
			return generateEdge(input,*alpha,&n_outbd);				
		}
		
	}
	return m_boundarys;
}



void findEdgeBetweenTwoClouds(ccPointCloud * c1,ccPointCloud *c2,TP_PtList *back_1,TP_PtList*back_2,float m_alpha)
{
	ccPointCloud combPts;
	ccPointCloud  *c_comb = &combPts;	
	long npt_comb = c1->size() + c2->size();
	c_comb->reserve(npt_comb);
	for (long i = 0; i < c1->size(); i++)
	{
		c_comb->push_back(c1->at(i));
	}
	for (long i = 0; i < c2->size(); i++)
	{
		c_comb->push_back(c2->at(i));
	}
	
	int n_outbd;
	TP_PlaneBoundary *bd1=generateEdge(c1,m_alpha,&n_outbd);
	TP_PlaneBoundary *bd2=generateEdge(c2,m_alpha,&n_outbd);
	TP_PlaneBoundary *bdComb=generateEdge(c_comb,m_alpha,&n_outbd);

	int n_e1=bd1->size();
	int n_e2=bd2->size();
	int n_comb=bdComb->size();
	int i,j;
	TP_PtList *plist1=NULL,*plist2=NULL,*plistComb=NULL;

	TP_PtList*returnList=NULL;

	for(i=0;i<n_e1;i++)
	{
		if (bd1->data()[(i)]->type == OUTSIDE_EDGE)
		{
			plist1=&(bd1->data()[(i)]->m_pts);
			break;
		}
	}
	for(i=0;i<n_e2;i++)
	{
		if (bd2->data()[(i)]->type == OUTSIDE_EDGE)
		{
			plist2=&(bd2->data()[(i)]->m_pts);
			break;
		}
	}
	for(i=0;i<n_comb;i++)
	{
		if (bdComb->data()[(i)]->type == OUTSIDE_EDGE)
		{
			plistComb=&(bdComb->data()[(i)]->m_pts);
			break;
		}
	}
	TP_PlaneBoundary back_bd1;
	TP_PlaneBoundary back_bd2;
	compareEdgeLists(plistComb,plist1,&back_bd1);
	compareEdgeLists(plistComb,plist2,&back_bd2);
	
	TP_PtList *listBack=new TP_PtList;
	plist1=NULL;plist2=NULL;

	int n_bd1=back_bd1.size();
	int n_bd2=back_bd2.size();


	for(i=0;i<n_bd1;i++)
	{
		BoundaryPts *m_bd1=back_bd1.data()[(i)];
        for(j=0;j<n_bd2;j++)
		{
			BoundaryPts *m_bd2=back_bd2.data()[(j)];
			if (true == getDistanceOfTwoList(&m_bd1->m_pts,&m_bd2->m_pts))
			{
				for(int k=0;k<m_bd1->m_pts.size();k++)back_1->push_back(m_bd1->m_pts.data()[(k)]);
				for(int k=0;k<m_bd2->m_pts.size();k++)back_2->push_back(m_bd2->m_pts.data()[(k)]);
			}
		}	
	}
	return ;

}
void compareTwoEdges(TP_PtList *baselist,TP_PtList *testList,int id_same,int type)//改变  要标注保存在对方中的位置
{
	if (baselist == NULL || testList == NULL)return;

	long n_basePts=baselist->size();
	long n_testpts=testList->size();
	long i,j;

	TP_Vertex *t1,*b1,*b2=NULL,*pBefore=NULL;
	long id_before= -1,id1,id2;

	int *flag_test=new int[n_testpts];
	int *flag_base=new int[n_basePts];

	memset(flag_test,0,sizeof(int)*n_testpts);
	memset(flag_base,0,sizeof(int)*n_basePts);

	for (i=0;i<n_testpts;i++) 
	{
		testList->data()[(i)].id_InComploop = -1;
	}

	for (i=0;i<n_testpts;i++)
	{
		t1=&testList->data()[(i)];

		if (pBefore != NULL)
		{
			id1=(id_before+n_basePts-1) % n_basePts;
			id2=(id_before+n_basePts+1) % n_basePts;
			b1=&baselist->data()[(id1)];
			b2=&baselist->data()[(id2)];
			if (flag_base[id1] == 0 && compareTP_vertex(t1,b1) == true)
			{
				pBefore=b1;
				id_before=id1;
				flag_base[id1]=1;
				flag_test[i]=1;	
				if (type == 1)
				{
					t1->id_InComploop = id1;
					b1->id_InComploop = i;
				}
				

				continue;
			}
			if (flag_base[id1] == 0 && compareTP_vertex(t1,b2) == true)
			{
				pBefore=b2;
				id_before=id2;
				flag_base[id2]=1;
				flag_test[i]=1;	
				if (type == 1)
				{
					t1->id_InComploop = id2;
					b2->id_InComploop = i;
				}
				

				continue;
			}
		}

		for(j=0;j<n_basePts;j++)
		{
			if (flag_base[j] == 1)continue;
			else
			{
				if(compareTP_vertex(t1,&baselist->data()[(j)]) == true)
				{
					pBefore=&baselist->data()[(j)];
					id_before=j;
					flag_base[j]=1;
					flag_test[i]=1;
					if (type == 1)
					{
						t1->id_InComploop = j;			
						baselist->data()[(j)].id_InComploop=i;
					}				
					break;
				}
			}
		}
	}

	for (i=0;i<n_testpts;i++)
	{
		if (flag_test[i] == 1)
		{
			testList->data()[(i)].comp_flag = id_same;
		}
		
	}

	for (i=0;i<n_basePts;i++)
	{
		if (flag_base[i] == 1)
		{
			baselist->data()[(i)].comp_flag = id_same;
		}
	}
	delete []flag_test;
	delete []flag_base;
}

void compareEdgeLists(TP_PtList *baselist,TP_PtList *testList,TP_PlaneBoundary * bd,int id)
{
	long n_basePts=baselist->size();
	long n_testpts=testList->size();
	long i,j;

	TP_Vertex *t1,*b1,*b2=NULL,*pBefore=NULL;
	long id_before= -1,id1,id2;

	int *flag_test=new int[n_testpts];
	int *flag_base=new int[n_basePts];

	memset(flag_test,0,sizeof(int)*n_testpts);
	memset(flag_base,0,sizeof(int)*n_basePts);

	for (i=0;i<n_testpts;i++)
	{
		t1=&testList->data()[(i)];
		
		if (pBefore != NULL)
		{
			id1=(id_before+n_basePts-1) % n_basePts;
			id2=(id_before+n_basePts+1) % n_basePts;
			b1=&baselist->data()[(id1)];
			b2=&baselist->data()[(id2)];
			if (flag_base[id1] == 0 && compareTP_vertex(t1,b1) == true)
			{
				pBefore=b1;
				id_before=id1;
				flag_base[id1]=1;
				flag_test[i]=1;	
				continue;
			}
			if (flag_base[id1] == 0 && compareTP_vertex(t1,b2) == true)
			{
				pBefore=b2;
				id_before=id2;
				flag_base[id2]=1;
				flag_test[i]=1;	
		
				continue;
			}
		}
		
		for(j=0;j<n_basePts;j++)
		{
			if (flag_base[j] == 1)continue;
			else
			{
				if(compareTP_vertex(t1,&baselist->data()[(j)]) == true)
				{
					pBefore=&baselist->data()[(j)];
					id_before=j;
					flag_base[j]=1;
					flag_test[i]=1;



					break;
				}
			}
		}
		
		
	}

	

	int *m_flages=new int[n_testpts];

	vector<long > edgeStart; 
	m_flages[0]=flag_test[0]-flag_test[n_testpts-1];
	if (m_flages[0]== -1)edgeStart.push_back(0);	
	for(i=1;i<n_testpts;i++)
	{
		m_flages[i]=flag_test[i]-flag_test[i-1];
		if (m_flages[i]== -1)edgeStart.push_back(i);			
	}


	int n_edgelist=edgeStart.size();
	long id_start,id_now;
	for (i=0;i<n_edgelist;i++)
	{		
		id_start=edgeStart.data()[(i)];
		id_now=id_start;
		BoundaryPts *bd_i=new BoundaryPts;
		while (m_flages[id_now] != 1)
		{
			bd_i->m_pts.push_back(testList->data()[(id_now)]);
			id_now++;
			if (id_now == n_testpts)
			{
				id_now -= n_testpts;
			}
		}

		if (bd_i->m_pts.size()< 1)continue;
		
		bd_i->corners.push_back(bd_i->m_pts.data()[(0)]);
		for (j=1;j<bd_i->m_pts.size()-1;j++)
		{
			if(bd_i->m_pts.data()[(j)].PtStab == 1)bd_i->corners.push_back(bd_i->m_pts.data()[(j)]);
		}
		bd_i->corners.push_back(bd_i->m_pts.data()[(bd_i->m_pts.size()-1)]);

		bd_i->ID =id;

		bd->push_back(bd_i);
	}

	delete []flag_test;
	delete []flag_base;
	delete []m_flages;

}
 

void refreshTP_ListByDeleteFlag(TP_PtList *m_l)
{	
	if (m_l->empty())return;
	TP_PtList *temp =new TP_PtList;
	for (size_t i = 0; i < m_l->size();i++)
	{
		temp->push_back(m_l->at(i));
	}
	m_l->clear();
	for (size_t i = 0; i<temp->size(); i++)
	{
		if (temp->at(i).delete_flag == false)m_l->push_back(temp->at(i));
	} 
	temp->clear();
	delete temp;
}

int findMixBDIDinList(TP_PtList *pts,int ID,int id_min,int id_max)
{
	if (!(id_min >= 0 && id_max <= pts->size()))return -1;
	for (int i=id_min;i < id_max;i++)
	{
		if (pts->data()[(i)].id_inMixBd == ID)return i;		
	}
	return -1;
}

int findIDinList(TP_PtList *pts,int ID,int id_min,int id_max)
{
	if (!(id_min >= 0 && id_max <= pts->size()))return -1;
	for (int i=id_min;i < id_max;i++)
	{
		if (pts->data()[(i)].ID == ID)return i;		
	}
	return -1;
}

CCVector3 caculateListCenter(TP_PtList *pts)
{
	CCVector3 centerPt(0,0,0);

	for (int i=0;i< pts->size();i++)
	{
		centerPt.x += pts->data()[(i)].m_p.x;
		centerPt.y += pts->data()[(i)].m_p.y;
		centerPt.z += pts->data()[(i)].m_p.z;
	}
	centerPt.x /= pts->size();
	centerPt.y /= pts->size();
	centerPt.z /= pts->size();

	return centerPt;
}

void getBBofCCVector3list(vector<CCVector3> *pts, CCVector3 *left_down, CCVector3 *right_up)
{
	assert (pts->size() > 0);
	left_down->x = right_up->x = pts->front().x;
	left_down->y = right_up->y = pts->front().y;
	left_down->z = right_up->z = pts->front().z;
	CCVector3 *pt_now= NULL;
	for (int i=0;i< pts->size();i++)
	{
		pt_now = &pts->data()[(i)];
		if (pt_now->x < left_down->x) left_down->x = pt_now->x;
		if (pt_now->y < left_down->y) left_down->y = pt_now->y;
		if (pt_now->z < left_down->z) left_down->z  = pt_now->z;
		if (pt_now->x > right_up->x ) right_up->x  = pt_now->x;
		if (pt_now->y > right_up->y ) right_up->y  = pt_now->y;
		if (pt_now->z > right_up->z ) right_up->z  = pt_now->z;
	}
}


void getBBofPtlist(TP_PtList *pts, CCVector3 *left_down, CCVector3 *right_up)
{
	assert (pts->size() > 0);
	left_down->x = right_up->x = pts->front().m_p.x;
	left_down->y = right_up->y = pts->front().m_p.y;
	left_down->z = right_up->z = pts->front().m_p.z;
	CCVector3 *pt_now= NULL;
	for (int i=0;i< pts->size();i++)
	{
		pt_now = &pts->data()[(i)].m_p;
		if (pt_now->x < left_down->x) left_down->x = pt_now->x;
		if (pt_now->y < left_down->y) left_down->y = pt_now->y;
		if (pt_now->z < left_down->z) left_down->z  = pt_now->z;
		if (pt_now->x > right_up->x ) right_up->x  = pt_now->x;
		if (pt_now->y > right_up->y ) right_up->y  = pt_now->y;
		if (pt_now->z > right_up->z ) right_up->z  = pt_now->z;
	}
}


double calculateRidgeSimilarity(CCVector3 Pt_a,CCVector3 Pt_b,CCVector3 Pt_c,CCVector3 Pt_d)
{
	double d_t=0.1,an_t=5;
	double oc,dc,pc;
	double dx1,dy1,dz1,dx2,dy2,dz2;
	double alpha,pro_1,pro_2;
	dx1 = Pt_b.x - Pt_a.x;	dx2 = Pt_d.x - Pt_c.x;
	dy1 = Pt_b.y - Pt_a.y;	dy2 = Pt_d.y - Pt_c.y;
	dz1 = Pt_b.z - Pt_a.z;	dz2 = Pt_d.z - Pt_c.z;
	alpha = (dx1*dx2 + dy1*dy2 +dz1*dz2)/sqrt((dx1*dx1+dy1*dy1+ dz1*dz1)*(dx2*dx2+dy2*dy2+ dz2*dz2));
	alpha = acos(alpha)*180/PI;
	oc =exp(- alpha*alpha/an_t/an_t);

	pro_1 = (dx1 *(Pt_c.x - Pt_a.x)+dy1 *(Pt_c.y - Pt_a.y)+dz1 *(Pt_c.z - Pt_a.z))/sqrt(dx1*dx1+dy1*dy1+ dz1*dz1);
	pro_2 = (dx1 *(Pt_d.x - Pt_a.x)+dy1 *(Pt_d.y - Pt_a.y)+dz1 *(Pt_d.z - Pt_a.z))/sqrt(dx1*dx1+dy1*dy1+ dz1*dz1);
	double cc1_2,dd1_2,dis,AB;
	AB = calDisP2P_xyz_sqrt(Pt_a,Pt_b);
	cc1_2 = fabs(pow(calDisP2P_xyz_sqrt(Pt_a,Pt_c),2)- pro_1 *pro_1);
	dd1_2 = fabs(pow(calDisP2P_xyz_sqrt(Pt_a,Pt_d),2)- pro_2 *pro_2);
	dis = (cc1_2 + dd1_2)/2; 
	dc = exp(-dis*dis/d_t/d_t);

	if ((pro_1 <= 0 && pro_2 <= 0) ||(pro_1 >= AB && pro_2 >= AB))return 0;
	
	vector<CmpType<double > > CmpData;
	CmpType<double > CT_num1(pro_1,0);CmpType<double > CT_num2(pro_2,1);
	CmpType<double > CT_num3(0,2);CmpType<double > CT_num4(AB,3);
	CmpData.push_back(CT_num1);CmpData.push_back(CT_num2);CmpData.push_back(CT_num3);CmpData.push_back(CT_num4);
	qsort(&CmpData.front(),CmpData.size(),sizeof(CmpType<int >),cmp1<int>);

	pc= (CmpData.data()[(0)].val - CmpData.data()[(3)].val)/(CmpData.data()[(1)].val - CmpData.data()[(2)].val);

	return oc*dc*pc;

}

//1 平行;2 垂直;
int decideRelationshipBetweentwoNormals(CCVector3 nv1,CCVector3 nv2)
{
	double cos_ang = fabs(nv1.x *nv2.x+nv1.y * nv2.y)/(sqrt(nv1.x*nv1.x+nv1.y*nv1.y)*sqrt(nv2.x*nv2.x+nv2.y*nv2.y));
	if (cos_ang > cos(5*PI / 180))return 1;//平行;
	else if (cos_ang < cos(85*PI / 180))return 2;//垂直;
	else return 0;
}

void deleteRepickPtsInLoops(TP_PtList *m_input)
{
	int n_pt=m_input->size();
	TP_Vertex *p1=NULL,*p2=NULL;

	for (int i=0;i<n_pt;i++)m_input->data()[(i)].delete_flag = false;

	for (int i=0;i<n_pt;i++)
	{
		p1=&m_input->data()[(i)];
		p2=&m_input->data()[((i+1)%n_pt)];
		if (calDisP2P_xy_sqrt(&p1->m_p,&p2->m_p) > 0.00001) continue;
		if (p1->PtStab < p2->PtStab || ((p1->PtStab == p2->PtStab) && p1->PtType <= p2->PtType))p1->delete_flag = true;		
		else {p2->delete_flag = true;}	
		i++;
	}

	refreshTP_ListByDeleteFlag(m_input);
}

double getProDensity(TP_PtList *eg, CCVector2 ori,double sigma,int _type)
{
	long npt = eg->size();
	CCVector2 *pts = new CCVector2[npt];
	const CCVector3 *pt_now;
	double *den_i = new double [npt];
	for (long i =0 ; i< npt; i++)
	{
         pt_now = &eg->at(i).m_p;
		 pts[i].x = ori.x * pt_now->x+ori.y * pt_now->y;
		 pts[i].y= -ori.y * pt_now->x+ori.x * pt_now->y;
	}

	double den_x,den_y,aveDen=0,dx,dy;
	long id1, id2;
	for (long i =0 ; i< npt; i++)
	{
		den_x = 0; 
		den_y = 0;
		if (npt > 30)
		{
			id1 = (i - 15 + npt) % npt;
			id2 = (i + 15 + npt) % npt;
			if (id2 == 0) id2++;
		}
		else
		{
			id1 = 0;
			id2 = npt;
		}
		for (long j = id1; j != id2; j++)
		{
			j = j % npt;
			dx = fabs(pts[j].x - pts[i].x) ;
			dy = fabs(pts[j].y - pts[i].y) ;
			if(_type == 0)
			{
				den_x += dx < sigma ? 1 : 0;
				den_y += dy < sigma ? 1 : 0;
			}
			else
			{
				den_x += exp(-dx * dx / sigma / sigma);
				den_y += exp(-dy * dy / sigma / sigma);
			}
		}
		den_i[i] =  max(den_x,den_y);
		aveDen  += den_i[i] ;
	}
	delete []pts; pts = nullptr;
	delete []den_i; den_i = nullptr;
	return aveDen/npt;	
}


 CCVector2 generateEdgeOri_byMaxProjDensity(TP_PtList *eg,double sigma,int _type)
 {
	 if (eg->empty())return CCVector2(1,0);
	 CCVector2 m_ori;
	 double den,den_max = 0,angle_best1,angle_best2;

	/* QString fileName1 = "output.txt";
	 FILE *fpOutput=NULL;
	 fpOutput = fopen(qPrintable(fileName1),"a+");*/

	 for(double angle = 0.0; angle < 90; angle += 1.0)
	 {
		 m_ori.x = cos(angle * PI/180.0);
		 m_ori.y = sin(angle * PI/180.0);
		 den = getProDensity(eg,m_ori,sigma,_type);
		 if (den > den_max)
		 {
			 den_max = den;
			 angle_best1 = angle;
		 }
		// fprintf(fpOutput,"%lf %lf\n",angle,den);
	 }
	 angle_best2 = angle_best1;
	 for(double angle = angle_best1 - 0.5; angle < angle_best1 + 0.5; angle += 0.1)
	 {
		 m_ori.x = cos(angle * PI/180.0);
		 m_ori.y = sin(angle * PI/180.0);
		 den = getProDensity(eg,m_ori,sigma,_type);
		 if (den > den_max)
		 {
			 den_max = den;
			 angle_best2 = angle;
		 }
		// fprintf(fpOutput,"%lf %lf\n",angle,den);
	 }
	 m_ori.x = cos(angle_best2 * PI/180.0);
	 m_ori.y = sin(angle_best2 * PI/180.0);
	// fclose(fpOutput);
	 return m_ori;
 }
 bool is_normal_Tw_outside(CCVector3 cenPt, CCVector3 nv, CCVector3 eg_Pt1, CCVector3 eg_Pt2)
 {
	 double a, b, c;//ax+by+c =0; 2D;
	 a = eg_Pt1.y - eg_Pt2.y;
	 b = -eg_Pt1.x + eg_Pt2.x;
	 c = eg_Pt1.y*(eg_Pt1.x - eg_Pt2.x) - eg_Pt1.x*(eg_Pt1.y - eg_Pt2.y);

	 CCVector3 cen_Ex = cenPt + nv * 5;
	 double cross1 = a* cenPt.x + b*cenPt.y + c;
	 double cross2 = a* cen_Ex.x + b*cen_Ex.y + c;
	 if (cross1 * cross2 < 0) return false; //different sides

	 double dis1 = calDisPt2LineSegment_2d(&cenPt, &eg_Pt1, &eg_Pt2, 1);
	 double dis2 = calDisPt2LineSegment_2d(&cen_Ex, &eg_Pt1, &eg_Pt2, 1);
	 if (dis1 > dis2) return false;
	 else	return true;
 }