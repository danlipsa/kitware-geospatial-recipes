#ifndef __LiDAR_POINT_PROCESS_TOPOLOGY_BOUNDURY_LOOP_METHOD_CLASS_DEFINE_H__
#define __LiDAR_POINT_PROCESS_TOPOLOGY_BOUNDURY_LOOP_METHOD_CLASS_DEFINE_H__


#include "Function.h"

class Plane_ConnectiveEdgeList
{
private:
	std::list<TP_Edge*> m_Edges;
	std::list<TP_Vertex* > m_Pts;

public:
	int l_nbd,r_nbd;
	int l_id,r_id;
	bool flag_inverse;
	bool isPCEStepEg;
	bool isPCECanceled;
	int combinedByAnother;
	int pl_id;

	eTP_edgeType m_type;
public:
	Plane_ConnectiveEdgeList();
	void Initial_P_CEL(vector<TP_Edge> *m_input);
	bool insertEdge(TP_Edge *ed);

	bool InitialbyPtlist_stepEgs(TP_PtList *plist);
	bool InitialbyPtlist_stepEgs_withIDRange(TP_PtList *plist,CCVector2i rg);
	std::list<TP_Edge*> * get_List_e(){return &m_Edges;}
	std::list<TP_Vertex* > *get_List_v(){return &m_Pts;}
	void getPts(TP_PtList *m_accepted, bool flag_inverse);

	void ComparePtWithPCE(CCVector3 pt,int *pos, double *dMin);

	void copyPCE(Plane_ConnectiveEdgeList pce,TP_PtList *savedPts);

	void deleteSingleShortPCE();
};


#endif