//#include "stdafx.h"
#include "Graph.h"

int compareIDList(IDList &loops_3, IDList &loops_4)
{
	assert(loops_3.size() == 3  && loops_4.size() == 4);

	int count=0;
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<4;j++)
		{			
			if ( loops_3.data()[(i)] == loops_4.data()[(j)])
			{			
				count++;
				break;
			}
		}
	}
	return count;
}


void caculateDepthOf_V(int *matrix_now,int *depth_v,int n_V,int startPt,int *minTree=NULL)
{
	depth_v[startPt]=0;
	int depth_next=0,ID_now,i,j;
	std::vector<int > level_now;//当前层的节点
	std::vector<int > level_next;//当前层的节点
    level_now.push_back(startPt);

	while(level_now.size() > 0)//
	{		
		depth_next++;		
		for ( i=0;i< level_now.size();i++)
		{
			ID_now=level_now.data()[(i)];
			for ( j=0;j<n_V;j++)
			{
				if (matrix_now[ID_now*n_V+j] == 1  && depth_v[j] == TPGROUP_INATIAL)//相邻且未被访问
				{
					level_next.push_back(j);
					depth_v[j]=depth_next;
					if (minTree != NULL)
					{
						minTree[ID_now*n_V+j]=minTree[j*n_V+ID_now]=1;
					}
				}
			}
		}
		level_now.clear();
		for ( i=0;i< level_next.size();i++)
		{
			level_now.push_back(level_next.data()[(i)]);
		}
		level_next.clear();
	}
}
bool compareTwoIDList(IDList *src,IDList *dst)
{
	int n_src=src->size();
	int n_dst=dst->size();
	int i,j,count=0;
	int *flag=new int[n_dst];
	
	memset(flag,0,sizeof(int)*n_dst);
	for (i=0;i<n_src;i++)
	{
		for(j=0;j<n_dst;j++)
		{			
			if (src->data()[(i)] == dst->data()[(j)])
			{
				count++;
				flag[j]=1;
				break;
			}
		}
	}
	if (count < n_src)
	{
		delete []flag;flag=NULL;
		return false;
	}

	int firstID,decreaseCount=0;
	for(i=0;i<n_dst;i++)
	{
		if (flag[i] == 1){firstID = i;break;}		
	}
	if (firstID == 0)//首尾都要搜索
	{
		for(i=0;i<n_dst-1;i++)
		{
			if (flag[i+1] == 1){flag[i]=2;decreaseCount++;}
			else break;
		}//下一个仍然是，当前标记置0										
		if (flag[n_dst-1] !=0 )
		{
			for(i=n_dst-1;i>0;i--)
			{
				if (flag[i-1] == 1){flag[i]=2;decreaseCount++;}
				else break;
			}
		}
	}
	else
	{
		for(i=firstID+1;i<n_dst-1;i++)
		{
			if (flag[i+1] == 1){flag[i]=2;decreaseCount++;}
			else break;
		}
	}
	if (decreaseCount != (n_src-2))//不是连在一起的
	{
		delete []flag;flag=NULL;
		return false;
	}

	IDList outTemp;
	for(i=0;i<n_dst;i++)
	{
		if (flag[i]!= 2)outTemp.push_back(dst->data()[(i)]);
	}
	dst->clear();
	for(i=0;i<outTemp.size();i++)dst->push_back(outTemp.data()[(i)]);
	outTemp.clear();
	delete []flag;flag=NULL;
	return true;
}

bool addInID2list(IDList *ori_id, int id)
{
		if (ori_id->empty()) {ori_id->push_back(id);return true;}
		else
		{
			bool f_find= false;
			for (int i = 0; i< ori_id->size(); i++)
			{
				if (id == ori_id->data()[(i)])
				{
					f_find = true;
					break;
				}
			}
			if (f_find == false)
			{
				ori_id->push_back(id); 
				return true;
			}
			else 	return false;
		}

	
}

Graph::Graph()
{	
	m_Matrix=NULL;
	m_MatrixTemp=NULL;
//	m_spanningTrees=NULL;
//	m_pSpTrees=NULL;
	m_loops=new vector<IDList >;
	m_childs=NULL;
	tpGraph_childs=NULL;
}

void Graph::graphInitial(int n_vertex,vector<void *> *vertexMes)
{
	
	if (m_V.size() != 0  || m_Matrix != NULL)
	{
		m_V.clear();
		m_E.clear();
		delete []m_Matrix; m_Matrix=NULL;
	}
	
	for(int i=0;i<n_vertex;i++)
	{
		G_Vertex v_add;
		v_add.ID= i;
		if (vertexMes != NULL )
		{
			if (vertexMes->size() == n_vertex)
			v_add.attr= vertexMes->data()[(i)];
		}
		
		m_V.push_back(v_add);
	}


	n_V=n_vertex;
	m_Matrix=new int[n_vertex *n_vertex];
	memset(m_Matrix,-1,sizeof(int)*n_vertex *n_vertex);
	
	return;
}

// vertex method
int Graph::insert_Vertex(void *attr)
{
	n_V = m_V.size();

	G_Vertex v_add;
	v_add.ID=n_V;
	v_add.attr=attr;

	if(n_V  == 0) 
	{
		graphInitial(1);
		m_V.front().attr=attr;
		return 1;
	}
		
	int *tempMatrix=new int[n_V  *n_V ];
	memcpy(tempMatrix,m_Matrix,sizeof(int)*n_V*n_V);

	delete []m_Matrix;m_Matrix=NULL;

	m_Matrix=new int[(n_V+1)*(n_V+1)];

	for (int i=0;i<(n_V+1);i++)
	   for (int j=0;j<(n_V+1);j++)
	   {
		   if ( i == n_V || j== n_V) m_Matrix[i*(n_V+1)+j]= -1;
		   else  m_Matrix[i*(n_V+1)+j]=tempMatrix[i*n_V+j];
	   }
    delete []tempMatrix;tempMatrix=NULL; 

	m_V.push_back(v_add);
	n_V++;
	return n_V;
	
}

void Graph::setVertexType(int ID, int m_type)
{
	m_V.at(ID).m_type = m_type;
}


int Graph::getDegreeOfaVertex(int vID)
{
	int count = 0;
	for (int i = 0;i< n_V;i++ )
	{
		G_Edge * eg_now=getEdge(i,vID);
		if ( eg_now == NULL)continue;
		if ((int)eg_now->edgeType >=  (int)Step)count++;		
	}
	return count;
}

int Graph::getDegreeOfaVertex_noneStep(int vID)
{
	int count = 0;
	for (int i = 0; i < n_V; i++)
	{
		G_Edge * eg_now = getEdge(i, vID);
		if (eg_now == NULL)continue;
		if ((int)eg_now->edgeType > (int)Step)count++;
	}
	return count;
}

 void Graph::findNeighbours(int vertex_ID,IDList *pN)
{
	if (vertex_ID < 0 || vertex_ID> (n_V-1)) return ;

	int count=0;
	for (int i=0;i< n_V;i++)
	{
		if (m_Matrix[vertex_ID*n_V+i] != -1)
		{
			pN->push_back(i);
			count++;
		}
	}
}
 void Graph::findNeighbours_noneStep(int vertex_ID,IDList *pN)
 {
	 caculateTempMatrix();
	 setTempMatrix_bystepEdge(0);
	 setTempMatrix_byinsideEdge(1);
	 if (vertex_ID < 0 || vertex_ID> (n_V-1)) return ;

	 int count=0;
	 for (int i=0;i< n_V;i++)
	 {
		 if (m_MatrixTemp[vertex_ID*n_V+i] != 0)
		 {
			 pN->push_back(i);
			 count++;
		 }
	 }
 } 

// edge method
int Graph::checkEdge(int ID_1,int ID_2)
{
	if (ID_1 < 0 || ID_1 > (n_V-1)|| ID_2 < 0 || ID_2 > (n_V-1) )return -2;//越界

	if  (m_Matrix[ID_1*n_V+ID_2] == -1)return -1;
	else return m_Matrix[ID_1*n_V+ID_2];//已经存在该边
}

int Graph::insert_Edge_withType(int ID_1, int ID_2, int m_type, void *attr )
{
	int n_check = checkEdge(ID_1, ID_2);
	if (n_check != -1)return -1;
	insert_Edge(ID_1, ID_2);
	m_E.back().m_type = m_type;
	return m_E.size();
}
int Graph::insert_Edge(int ID_1,int ID_2,void *attr)
{
	int n_check=checkEdge(ID_1,ID_2);
	if (n_check != -1)return -1;
	
	G_Edge edge_add;
	edge_add.ID =m_E.size();
	edge_add.ID_1=ID_1;
	edge_add.ID_2=ID_2;
	edge_add.flag_use=true;
	edge_add.attr=attr;
	
	m_E.push_back(edge_add);

	m_Matrix[ID_1*n_V+ID_2]= edge_add.ID;
	m_Matrix[ID_2*n_V+ID_1]= edge_add.ID;
	return m_E.size();

}
int Graph::insert_Edge_Multiply(int ID_1,int ID_2,void *attr1)
{
	G_Edge edge_add;
	edge_add.ID =m_E.size();
	edge_add.ID_1=ID_1;
	edge_add.ID_2=ID_2;
	edge_add.flag_use=true;
	edge_add.attr1=attr1;

	int n_check=checkEdge(ID_1,ID_2);
	if (n_check != -1)
	{
		m_E_attr.push_back(edge_add);
		return -1;
	}	
	m_E.push_back(edge_add);

	m_Matrix[ID_1*n_V+ID_2]= edge_add.ID;
	m_Matrix[ID_2*n_V+ID_1]= edge_add.ID;
	return m_E.size();

}
int Graph::setEdge(int ID_1,int ID_2,bool flag,double weight,ridgeType edgeType,TP_Vertex *p1,TP_Vertex *p2)//边不存在时，修改失败
{
	if (checkEdge(ID_1,ID_2) < 0)return -1;
	int edge_ID=m_Matrix[ID_1*n_V+ID_2];
	m_E.data()[(edge_ID)].flag_use =flag;
	m_E.data()[(edge_ID)].weight =weight;
	m_E.data()[(edge_ID)].edgeType =edgeType;
	if (p1 != NULL && p2 != NULL)
	{
		(m_E.data()[(edge_ID)].p1)=p1;
		(m_E.data()[(edge_ID)].p2)=p2;
	}


	return 1;
}


int Graph::setEdgeFlag(int ID_1,int ID_2,bool flag)
{
	if (checkEdge(ID_1,ID_2) < 0)return -1;
	int edge_ID=m_Matrix[ID_1*n_V+ID_2];	
	m_E.data()[(edge_ID)].flag_use =flag;
	return 1;
}
int Graph::setEdgeWeight(int ID_1,int ID_2,double weight)
{
	if (checkEdge(ID_1,ID_2) < 0)return -1;
	int edge_ID=m_Matrix[ID_1*n_V+ID_2];
	m_E.data()[(edge_ID)].weight =weight;
	return 1;
}
int Graph::setEdgeType(int ID_1,int ID_2,ridgeType edgeType)
{
	if (checkEdge(ID_1,ID_2) < 0)return -1;
	int edge_ID=m_Matrix[ID_1*n_V+ID_2];
	m_E.data()[(edge_ID)].edgeType =edgeType;
	return 1;
}

G_Edge* Graph::getEdge(int ID_1,int ID_2)
{
	int n_id=checkEdge(ID_1,ID_2);
	if (n_id < 0)return NULL;
	return &(m_E.data()[(n_id)]);

}

bool Graph::setFatherID_v(int ID,int fatherID)
{
	if (ID < 0 || ID> (n_V-1))return false;
	else
	{
		m_V.data()[(ID)].fatherID=fatherID;
		return true;
	}
}
int Graph::getFatherID_v(int ID)
{
	if (ID < 0 || ID> (n_V-1))return -1;
	else
	{
		return m_V.data()[(ID)].fatherID;
	}
}
bool Graph::setFatherID_e(int ID,int fatherID)
{
	if (ID < 0 || ID> (m_E.size()-1))return false;
	else{
		m_E.data()[(ID)].fatherID=fatherID;
		return true;
	}
	
}
int Graph::getFatherID_e(int ID)
{
	if (ID < 0 || ID> (m_E.size()-1))return -1;
	else{
		return m_E.data()[(ID)].fatherID;
	}
}



//search method
void Graph::caculateTempMatrix()
{
	if (m_MatrixTemp != NULL)
	{
		delete []m_MatrixTemp;m_MatrixTemp=NULL;
	}


	int i,j;
	m_MatrixTemp=new int[n_V*n_V];

	for (i=0;i<n_V;i++)
		for(j=0;j<n_V;j++)
		{
			int id=m_Matrix[i*n_V+j];
			if (id != -1 && (m_E.data()[(id)].flag_use == true )) m_MatrixTemp[i*n_V+j]=1;
			else m_MatrixTemp[i*n_V+j]=0;			
		}
}
int Graph::setTempMatrix_bystepEdge(int step_flag)
{
	assert(step_flag == 1 || step_flag==0);
	int i,j,n_stepEdge=0;
	for (i=0;i<n_V;i++)
		for(j=0;j<i;j++)
		{
			int id=m_Matrix[i*n_V+j];
			if (id != -1 && (m_E.data()[(id)].edgeType == Step ||
				m_E.data()[(id)].edgeType == NotExist || m_E.data()[(id)].edgeType == Undecided)) 
			{
				m_MatrixTemp[i*n_V+j]=step_flag;
				m_MatrixTemp[j*n_V+i]=step_flag;
				n_stepEdge++;
			}	
		}
		return n_stepEdge;
}
int Graph::setTempMatrix_byinsideEdge(int step_flag)
{
	assert(step_flag == 1 || step_flag==0);
	int i,j,n_stepEdge=0;
	for (i=0;i<n_V;i++)
		for(j=0;j<i;j++)
		{
			int id=m_Matrix[i*n_V+j];
			if (id != -1 && (m_E.data()[(id)].edgeType == Inside)) 
			{
				m_MatrixTemp[i*n_V+j]=step_flag;
				m_MatrixTemp[j*n_V+i]=step_flag;
				n_stepEdge++;
			}	
		}
		return n_stepEdge;
}




void Graph::DFS(int  beginID, int groupNum,int *flags)//深度优先搜索算法
{
	if (beginID > (n_V-1) || beginID < 0) return ;

	if (flags[beginID] != TPGROUP_INATIAL)return ;
	flags[beginID]=groupNum;

    for (int i=0;i<n_V;i++)
    {
		int id = m_Matrix[beginID*n_V+i];
		if (id == -1) continue;
		
		bool flag_i= m_E.data()[(id)].flag_use;
		if(flag_i == true && flags[i] == (9999))DFS(i,groupNum,flags);
    }
}


void Graph::BFS(int  beginID, int groupNum,int* vertex_flags,int *edge_flags)//广度优先搜索算法
{


	if (beginID > (n_V-1) || beginID < 0) return ;

	if (vertex_flags[beginID] != TPGROUP_INATIAL)return ;
	vertex_flags[beginID]=groupNum;

	std::list<int > checkedPts;
	checkedPts.push_back(beginID);
	int i,j,id;
	while( checkedPts.size()  != 0)
	{	     
		j=checkedPts.front();
		checkedPts.pop_front();
		for (i=0;i<n_V;i++)
		{
			id = m_MatrixTemp[j*n_V+i];		
			
			if(id == 1 && vertex_flags[i] == TPGROUP_INATIAL)
			{
				edge_flags[i]=1;
				vertex_flags[i]=groupNum;
				checkedPts.push_back(i);
			}
		}
	}
}

int Graph::findConnectGroups(int *flags)
{
//	memset(flags,TPGROUP_INATIAL,sizeof(int)*n_V);
	for (int i=0;i<n_V;i++)flags[i]=TPGROUP_INATIAL;
	
	int n_choosed=0,groupNum=0,first_unchoosed = -1;
	int id=0;
	while (n_choosed <  n_V)
	{
		first_unchoosed= -1;
		DFS(id,groupNum,flags);
		for(int i=0;i<n_V;i++)
		{
			if (flags[i] == groupNum)n_choosed++;
			else
			{  
				if (flags[i] > groupNum && first_unchoosed == -1)
				{
					first_unchoosed = i;
				}
		
			}
		}
		id =first_unchoosed;
		groupNum++;

	}
	return groupNum;
}
// loops 

int Graph::findTriangles()
{
	IDList pN;
	int n_before=m_loops->size();
	int i,j,k,id1,id2;
	for (i=0;i<n_V;i++)
	{
		for (j=i+1;j< n_V;j++)//id要大于i 防止重复
		{
			if (m_MatrixTemp[i*n_V+j] != 0)
			{
				pN.push_back(j);
			}
		}

		int n_neighbours = pN.size();
		if (n_neighbours > 1)
		{
		      for (j=0;j<n_neighbours;j++)
		     {
				 id1= pN.data()[(j)];
				 for(k=j+1;k<n_neighbours;k++)
				 {
					 id2=pN.data()[(k)];
					 if (m_MatrixTemp[id1*n_V+id2] == 1)
					 {
						 IDList listadd;
						 listadd.push_back(i);listadd.push_back(id1);listadd.push_back(id2);
						 m_loops->push_back(listadd);
						
						 
					 }
				 }
		     }

		}
		pN.clear(); 
	}
	return m_loops->size()-n_before;
}
/*
int Graph::findQuadrangles()
{
	IDList pN;
	int n_before=m_loops->size();
	int i,j,k,l,id1,id2;
	for (i=0;i<n_V;i++)
	{
		for (j=i+1;j< n_V;j++)//id要大于i 防止重复
		{
			if (m_MatrixTemp[i*n_V+j] != 0)
			{
				pN.push_back(j);
			}
		}

		int n_neighbours = pN.size();
		if (n_neighbours > 1)
		{
			for (j=0;j<n_neighbours;j++)
			{
				id1= pN.data()[(j);
				for(k=j+1;k<n_neighbours;k++)
				{
					id2=pN.data()[(k);
					for (l=i+1;l<n_V;l++)
					{
						if (m_MatrixTemp[l*n_V+id1] == 1  && m_MatrixTemp[l*n_V+id2])
						{
							IDList listadd;
							listadd.push_back(i);listadd.push_back(id1);listadd.push_back(l);listadd.push_back(id2);

							bool flag_remove=false;
							for(int i_loops=0;i_loops<n_loops_3;i_loops++)
							{
								if( compareIDList(m_loops->data()[(i_loops),listadd)  > 2)
								{
									flag_remove =true;
									break;
								}
							}

							if (flag_remove == false)
							{
								m_loops->push_back(listadd);
							}



						//	m_loops->push_back(listadd);
						}
					}
					
				}
			}

		}
		pN.clear(); 
	}
	return m_loops->size()-n_before;
}
*/
//确定Graph中，各顶点到起始点的深度
int Graph::findLoops()
{
	m_loops->clear();
	vector<IDList > m_loops_temp;
	caculateTempMatrix();

	int n_steps= setTempMatrix_bystepEdge(0);
	int i,j;
	//int n_loops=m_E.size()-m_V.size()+1;		
	//计算顶点的度
	int *degreeOfV=new int[n_V];
	memset(degreeOfV,0,sizeof(int)*n_V);
	int MaxD_id=0,maxD=0;
	for (i=0;i<n_V;i++)
	{
		for(j=0;j<n_V;j++)
		{	
			if (m_MatrixTemp[i*n_V+j] == 1) degreeOfV[i]++;						
		}
		if (degreeOfV[i] > maxD)
		{
			maxD=degreeOfV[i];
			MaxD_id=i;
		}
	}
	//以最大度的点为起点 构建最小生成树
	int *v_flag=new int[n_V];
	
	for ( i=0;i<n_V;i++)v_flag[i]=TPGROUP_INATIAL;


	int *m_SpTrees=new int[n_V*n_V];
	memset(m_SpTrees,0,sizeof(int)*n_V*n_V);
	vector<G_Edge *> eds_toAdd;
	
	caculateDepthOf_V(m_MatrixTemp,v_flag,n_V,MaxD_id,m_SpTrees);
	
	for ( i=0;i<n_V;i++)
		for ( j=0;j<i;j++)
	{
		if (m_MatrixTemp[i*n_V+j]== 1 && m_SpTrees[i*n_V+j]== 0)
		{
			eds_toAdd.push_back(getEdge(i,j));
		}
	}
    n_loops=eds_toAdd.size();//没加入一条边 即可增加一个环。
    int n_add=0;
	int start_v,end_v,loop_length,id_before;
	
	while(n_add < n_loops)//逐个加入
	{
		G_Edge *eg_add=eds_toAdd.data()[(n_add)];
		start_v=eg_add->ID_1;
		end_v=eg_add->ID_2;
		for ( i=0;i<n_V;i++)v_flag[i]=TPGROUP_INATIAL;
		caculateDepthOf_V(m_SpTrees,v_flag,n_V,start_v);//从起始点开始，计算深度
		loop_length = v_flag[end_v];
		IDList listadd;
        listadd.push_back(end_v);
		id_before=end_v;
		while(loop_length--)//深度递减，回溯到起点
		{
			for (i=0;i<n_V;i++)
			{
				if (m_SpTrees[id_before*n_V+i] == 1 && v_flag[i]== loop_length)//直接相连且深度小 则回溯
				{
					listadd.push_back(i);
					id_before=i;
					break;
				}
			}
		}
		m_loops_temp.push_back(listadd);
		m_SpTrees[start_v*n_V+end_v]=m_SpTrees[end_v*n_V+start_v]=1;//加入该边 进入下一轮循环

		n_add++;
	}
    //消除非最小环
	
	IDList *list1=NULL,*list2=NULL;
	bool flag_change=true;//如果环缩小 则需要重新检查 看能否继续缩小
	int count=0;
	//能压缩的例子  l1： 4,5,6  l2： 3,（5,6,4,）2	 l2'(在两端):  6,4,）2,3,（5
	//判定:1 长度 2 含有压缩的段（），可平移或倒序，也可能在首尾！！
	//压缩过程（5,6,4,）---（5,4）以首尾段代替整个
	
	for (i=0;i<n_loops;i++)
	{
		list1=&m_loops_temp.data()[(i)];
		flag_change=true;
		while(flag_change == true)
		{
			flag_change=false;
			for(j=0;j<n_loops;j++)		
		    {
				list2=&m_loops_temp.data()[(j)];
				if (j==i || list1->size() >= list2->size() )continue;
				if (compareTwoIDList(list1,list2) == true)
				{
					flag_change=true;
					break;
				}				
		    }
		}
		
	}

	//考虑到图中存在K33的问题，会漏掉个别三角形，对三角形单独求解
	for (i=0;i<n_loops;i++)
	{
		list1=&m_loops_temp.data()[(i)];
		if (list1->size() > 3)
		{
			m_loops->push_back(m_loops_temp.data()[(i)]);
		}
	}

	m_loops_temp.clear();
	findTriangles();

	delete []v_flag;
	delete []m_SpTrees;


	return m_loops->size();
	
}

/*
void Graph::searchLoopWithEdge(int beginID,int endID)//去掉一条边，在剩余的图中搜索最短路径
{
	
	assert(beginID< n_V && beginID > (-1)&& endID < n_V && beginID > (-1));
	caculateTempMatrix();
	m_MatrixTemp[beginID*n_V +endID]= m_MatrixTemp[endID*n_V +beginID]=0;//去掉一条边

}

void Graph::addToTree(G_Tree *treeNow, int *matrixNow,int *flags)
{
	int ID=treeNow->m_index;
	if (flags[ID] == 1)return;

	flags[ID] =1;//标记父节点
	vector<int > childs;
	for(int i=0;i<n_V;i++)//搜索全部子节点
	{
		if (matrixNow[ID*n_V+i]==1 &&  flags[i] == 0)//边存在  顶点未被访问
		{
			treeNow->addChild(m_pSpTrees[i]);
			flags[i] = 1;
			childs.push_back(i);
		}
	}
	for(int i=0;i< childs.size();i++)
	{
		//addToTree(m_pSpTrees[i],matrixNow,flags);//
	}
}


G_Tree* Graph::SpanningTree(int fatherID, int *matrixNow)
{
	int i,j;
    for ( i=0;i<n_V;i++)
    {
		m_pSpTrees[i]->initialTree();
    }
	G_Tree *tree=m_pSpTrees[fatherID];

	int *flags=new int[n_V];
	memset(flags,0,sizeof(int)*n_V);
//	addToTree(tree,matrixNow,flags);	
	return tree;
}*/


void Graph::decomposeGraph()
{
	long i,j;
	m_childs=new vector<Graph * >;
	int n_plane=getVertexCount();
	//标示阶跃  分解模型
	for (i=0;i<getEdgeCount();i++)
	{
		G_Edge *gEdge=getEdgebyID(i);
		if (gEdge->edgeType == Step || gEdge->edgeType == NotExist)
		{
			setEdgeFlag(gEdge->ID_1,gEdge->ID_2,0);
		}
	} 	
	int *mID_f2c =new int[n_plane];
	int *vID_f2c =new int[n_plane];
	int child_count=findConnectGroups(mID_f2c);

	if (child_count > 0)
	{
		tpGraph_childs = new Graph;
		tpGraph_childs->graphInitial(child_count);

		//m_childs =new vector<TP_Model * >;
		for (i=0;i<child_count;i++)
		{
			int count_v=0;
			for (j=0;j<n_plane;j++)
			{
				if (mID_f2c[j] != i)continue;
				else
				{
					vID_f2c[j]=count_v++;
				}			
			}
			if (count_v == 0)continue;
			else
			{
				Graph *child_now=new Graph;
				child_now->graphInitial(count_v);

				m_childs->push_back(child_now);
			}
		}						

	}
	G_Edge *edge_now=NULL;
	G_Edge *edge_father=NULL;
	Graph *graph_now=NULL;
	for (i=0;i < getEdgeCount(); i++)
	{
		edge_now=getEdgebyID(i);
		int id_1,id_2;
		id_1=mID_f2c[edge_now->ID_1];
		id_2=mID_f2c[edge_now->ID_2];

		if (id_1 == id_2)//属于同一子模型
		{
			graph_now=m_childs->data()[(id_1)];
			graph_now->insert_Edge(vID_f2c[edge_now->ID_1],vID_f2c[edge_now->ID_2],edge_now->attr);			
			graph_now->setFatherID_e(graph_now->getEdgeCount() -1,i); 
			graph_now->setEdge(vID_f2c[edge_now->ID_1],vID_f2c[edge_now->ID_2],edge_now->flag_use,
				edge_now->weight,edge_now->edgeType,edge_now->p1,edge_now->p2);

		}
		else
		{
			tpGraph_childs->insert_Edge(id_1,id_2,edge_now->attr);
			tpGraph_childs->setFatherID_e(tpGraph_childs->getEdgeCount() -1,i); 
			tpGraph_childs->setEdge(id_1,id_2,edge_now->flag_use,edge_now->weight,edge_now->edgeType);
		}

	}
	for(i=0;i<n_plane;i++)
	{
		graph_now=m_childs->data()[(mID_f2c[i])];
		graph_now->setFatherID_v(vID_f2c[i],i);
	}
	delete []mID_f2c;
	delete []vID_f2c;
}
void Graph::expansionGraphFlags(vector<IDList >  *m_flags)
{
	if (m_flags == NULL  || m_flags->size() != n_V)return;
	
	int *f_empty = new int[n_V];
	int i,j,empty_count = 0, expansion_count = 1;
	for (i=0;i < n_V ; i++)
	{
		if (m_flags->data()[(i)].empty()) 
		{
			f_empty[i] = 0;
			empty_count++;
		}
		else f_empty[i] = 1;
	}
	while(empty_count > 0 && expansion_count != 0)//有无主方向的面，且上一轮有变化;
	{
		expansion_count = 0; 
		for (i=0;i< n_V ;i++)
		{
			IDList l_now = m_flags->data()[(i)];
			IDList pN,l_search;
			if (l_now.empty())
			{

				findNeighbours_noneStep(i,&pN);
				for (j = 0 ; j< pN.size();j++)
				{
					l_search = m_flags->data()[(pN.data()[j])];
					if (!l_search.empty())
					{
						for(int k =0 ; k < l_search.size();k++)
						{
							if (addInID2list(&m_flags->data()[(i)],l_search.data()[(k)]))expansion_count++;							
						}
					}					
				}
			}
		}
	}
	expansion_count = 1;
	while(empty_count > 0 && expansion_count != 0)//有无主方向的面，且上一轮有变化;
	{
		expansion_count = 0; 
		for (i=0;i< n_V ;i++)
		{
			IDList l_now = m_flags->data()[(i)];
			IDList pN,l_search;
			if (l_now.empty())
			{

				findNeighbours(i,&pN);
				for (j = 0 ; j< pN.size();j++)
				{
					l_search = m_flags->data()[(pN.data()[j])];
					if (!l_search.empty())
					{
						for(int k =0 ; k < l_search.size();k++)
						{
							if (addInID2list(&m_flags->data()[(i)],l_search.data()[(k)]))expansion_count++;							
						}
					}					
				}
			}
		}
	}


}
void Graph::getEdge_Multiply(int ID_1,int ID_2,vector<G_Edge* > *m_backs)
{
	assert (m_backs != NULL);m_backs->clear();

	for (int i =0; i< m_E.size();i++)
	{
		if (ID_1 == m_E.at(i).ID_1  && ID_2 == m_E.at(i).ID_2)m_backs->push_back(&m_E.data()[i]);
	}
	for (int i =0; i< m_E_attr.size();i++)
	{
		if (ID_1 == m_E_attr.at(i).ID_1  && ID_2 == m_E_attr.at(i).ID_2)m_backs->push_back(&m_E_attr.data()[i]);
	}


}


