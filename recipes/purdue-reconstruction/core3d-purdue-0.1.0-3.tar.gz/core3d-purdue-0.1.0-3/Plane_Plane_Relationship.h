#ifndef __LiDAR_POINT_PROCESS_TOPOLOGY_PLANE_PLANE_RELATIONSHIP_CLASS_DEFINE_H__
#define __LiDAR_POINT_PROCESS_TOPOLOGY_PLANE_PLANE_RELATIONSHIP_CLASS_DEFINE_H__

#include "tpPlane.h"
#include "BdLoop.h"

enum P2P_Type
{
	Apart = 0,
	Connect_step=1,
	Connect_cutbyEdge=2,
	Connect_mixed=3,
	Connect_inside=4
};
enum Div_Type
{
	Refuse = 0,
	L_Accept = 1,
	R_Accept = 2,
	Perfect = 3
	
};
struct TP_stepEdge
{
	int st_1,end_1,st_2,end_2;
	CCVector3 pt_st,pt_end;
	bool isPlane1_Upper;
	bool isEgSameX;
};

class Plane_Plane_Relation
{
private:
	
	P2P_Type m_type;

	CCVector3 r_srcPt,r_nv;//

	CCVector3 projection_para;//a_Pro,b_Pro,d_Pro;
	CCVector3 r_1,r_2;//
	Div_Type dType;

	CCVector2 r_range;//



	bool isRidgeProIncrease;
	CCVector2 ridgeProRange;

	

public:
	G_Edge *m_eg;
	TP_Plane *m_p1,*m_p2;
	CCVector2i ID_onlist_1,ID_onlist_2;//
	CCVector2i id_back1,id_back2;// 

	CCVector2i ID_onlist_1s,ID_onlist_2s;//

	
	LineSegmentsList *plist;

	vector< CCVector3 > bdPts_L;
	vector< CCVector3 > bdPts_R;
	TP_PtList back_bd1,back_bd2;

	Plane_ConnectiveEdgeList stepBD1,stepBD2;
	TP_PtList tps_stbd;
	bool isModleID_1over2;//eg  plane 1 in child model 2 eg  plane 2 in child model 1;
	CCVector2 m_ori_ifStep;
	int ori_id;
	double m_sigma;
public:
	Plane_Plane_Relation(TP_Plane *p1,TP_Plane *p2,G_Edge *eg)
	{
		m_p1 = p1;
		m_p2 = p2;
		m_eg = eg;
		m_type=Apart;
		isModleID_1over2 = false;
	}
	P2P_Type getP2PType(){return m_type; }
	CCVector3 getRidge_srcPt(){return r_srcPt;}
	CCVector3 getRidge_nv(){return r_nv;}

	void caculateRobustRidgesFirst();
	void caculateRobustStepEdges(vector< CCVector2> *m_oris);
	void markCommonPtsBetweenTwoClouds();
	void decideEdgeType();
private:
	void caculateRidgeParameter();

	void caculateRidegeEnds();
	
	bool updataReplacedIDsbyRidgeRange( TP_PtList *bd, CCVector2i * idOnList,CCVector2i rg);


};


void replacePtListByPolyLine(TP_PtList *plist_in,TP_PtList *plist_out,CCVector2i *id_bd,double dTh);
void PtList_IO(TP_PtList *_in,TP_PtList *_out, CCVector2 m_ori,bool m_type);
void adjustStepBd(TP_PtList *bd, TP_PtList *bd_new, TP_PtList *bdAll,CCVector2i pos, double mvRange);

#endif
