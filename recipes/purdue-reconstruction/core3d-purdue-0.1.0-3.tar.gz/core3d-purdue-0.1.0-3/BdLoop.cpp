//#include "stdafx.h"
#include "BdLoop.h"

void insertSkelonIntomixBd_1(Plane_ConnectiveEdgeList *P_CEL,bool _inverse,TP_PtList *m_mixBd)
{

	if (_inverse == false)
	{		
		for (std::list<TP_Vertex *>::iterator itr=P_CEL->get_List_v()->begin();itr != P_CEL->get_List_v()->end();itr++)
		{
			m_mixBd->push_back(**itr);
		}
	}
	else
	{
		for (std::list<TP_Vertex *>::reverse_iterator itr=P_CEL->get_List_v()->rbegin();itr != P_CEL->get_List_v()->rend();itr++)
		{
			m_mixBd->push_back(**itr);
		}
	}
}

Plane_ConnectiveEdgeList::Plane_ConnectiveEdgeList()
{
	flag_inverse =false;
	combinedByAnother= -1;
	isPCEStepEg = false;
	isPCECanceled = false;
}

void Plane_ConnectiveEdgeList::Initial_P_CEL(vector< TP_Edge> *m_input)
{
	if (m_input==NULL || m_input->size() == 0)return;

	m_Edges.clear();m_Pts.clear();

	int i,count=0,n_edge=m_input->size();
	bool flag_add=true;
	bool *flag_use=new bool[n_edge];
	for (i=0;i<n_edge;i++)flag_use[i]=false;
	while (count < n_edge && flag_add==true)
	{
		flag_add=false;
		for (i=0;i<n_edge;i++)
		{
			if (flag_use[i] == true)continue;
			TP_Edge *_input_i = m_input->data();
			if (insertEdge(&_input_i[i])== true)
			{
				flag_use[i]=true;
				count++;
				flag_add=true;
				break;
			}
		}
	}
	delete []flag_use;
	l_nbd = r_nbd =0;//现在只考虑单个外环
	//合成的链接可能方向反了  由第一个的方向决定
	if (m_input->front().translated == false)//未反
	{
		l_id = m_Edges.front()->bd_start;
		r_id = m_Edges.back()->bd_end;
		flag_inverse =false;
	}
	else
	{
		l_id = m_Edges.back()->bd_start;
		r_id =  m_Edges.front()->bd_end;
		flag_inverse =true;
	}
}

bool Plane_ConnectiveEdgeList::insertEdge( TP_Edge *ed)
{
	if (m_Edges.size() == 0)
	{
		m_Edges.push_back(ed);
		m_Pts.push_back(ed->ptBejin);
		m_Pts.push_back(ed->ptEnd);	
		return true;
	}

	TP_Vertex *v_f= m_Pts.front();
	TP_Vertex *v_b=m_Pts.back();

	if (ed->ptBejin == v_f) //|| calDisP2P(&ed->ptBejin->m_p,&v_f->m_p)< 0.1)
	{
		m_Edges.push_front(ed);
		m_Pts.push_front(ed->ptEnd);
		return true;
	}
	if (ed->ptEnd== v_f) 
	{
		m_Edges.push_front(ed);
		m_Pts.push_front(ed->ptBejin);
		return true;
	}
	if (ed->ptBejin == v_b)
	{
		m_Edges.push_back(ed);
		m_Pts.push_back(ed->ptEnd);
		return true;
	}
	if (ed->ptEnd == v_b) 
	{
		m_Edges.push_back(ed);
		m_Pts.push_back(ed->ptBejin);
		return true;
	}
	return false;
}
void Plane_ConnectiveEdgeList::getPts(TP_PtList *m_accepted, bool flag_inverse)
{
	if (m_Pts.empty())return;
	
	m_Pts.front()->PtStab = m_Pts.back()->PtStab=Extensible;
	TP_Vertex* pt=NULL;
	PointType theType1,theType2;
	int id_use1 = -3,id_use2 = -2;
	bool isOnBD = true;
	switch (m_type)
	{
		case outsideBD : theType1 = InterSect_Vertical_Outside_BD; theType2 = Extensible_OutsideStepBD_Ends;break;
		case insideStep : theType1 = InterSect_Vertical_Inside_Step;theType2 = Extensible_InsideStepBD_Ends; break;
		case roofRidge : theType1 = InterSect_MultiplyRidge_Inside;theType2 = Extensible_Roof_Ends;id_use1 =id_use2 = -1;isOnBD = false; break;
		default:  theType1 = InterSect_MultiplyRidge_Inside; id_use1 =id_use2 = -1;isOnBD = false; 	
	}

	for (std::list<TP_Vertex*>::iterator itr = m_Pts.begin(); itr!= m_Pts.end();itr++ )
	{
		pt = (*itr);
		pt->id_InComploop = -1;	
		pt->ID = id_use2;
		pt->PtType = theType1;
		pt->onBD = isOnBD;
	}
	m_Pts.front()->PtType = theType2;
	m_Pts.back()->PtType  = theType2;
	m_Pts.front()->ID = id_use1;
	m_Pts.back()->ID = id_use1;


	if (!isPCEStepEg)
	{
		m_Pts.front()->roofRidgeID_ifis = m_Edges.front()->edgeID;
		m_Pts.back()->roofRidgeID_ifis = m_Edges.back()->edgeID;
	}
	

	insertSkelonIntomixBd_1(this,flag_inverse,m_accepted);

	


}

bool Plane_ConnectiveEdgeList::InitialbyPtlist_stepEgs_withIDRange(TP_PtList *plist,CCVector2i rg)
{
	m_Edges.clear();
	m_Pts.clear();
	int npt = plist->size();
	TP_PtList m_cors;
	int id_st=0,id_end=0,id_now = 0;
	bool f_add= false;
	TP_Vertex *pt_add=NULL;
	for (int i = 0; i< npt;i++)
	{
		if ( i == rg.x) {id_st = id_now;f_add = true;}	
		if ( i == rg.y+1) {id_end = id_now;f_add = false;}	
		if (plist->at(i).PtStab > StepInside)
		{
			m_cors.push_back(plist->at(i));
			if (f_add)
			{
				pt_add = new TP_Vertex;
				*pt_add = plist->data()[i];
				m_Pts.push_back(pt_add);
			}
			id_now ++;
		}	
	}
	if (!(plist->at(rg.x).PtStab > StepInside)  && id_st!= 0)//以角点开始;1
	{//需要额外引入起点;
		CCVector3 newPt;
		calProjectionPoint_2d(m_cors.at(id_st-1).m_p,m_cors.at(id_st).m_p,plist->at(rg.x).m_p,&newPt);
		pt_add = new TP_Vertex;	*pt_add = plist->data()[rg.x];
		pt_add->m_p = newPt;
		m_Pts.push_front(pt_add);
	}
	if (!(plist->at(rg.y).PtStab > StepInside)  && id_end!= 0)
	{
		CCVector3 newPt;
		calProjectionPoint_2d(m_cors.at(id_end-1).m_p,m_cors.at(id_end).m_p,plist->at(rg.y).m_p,&newPt);
		pt_add = new TP_Vertex;		*pt_add = plist->data()[rg.y];	
		pt_add->m_p = newPt;
		m_Pts.push_back(pt_add);
	}

	if (m_Pts.size() < 2)return false;
	
	l_nbd = r_nbd = 0;
	int id1 = plist->at(rg.x).id_InComploop;
	int id2 = plist->at(rg.x+1).id_InComploop;
	//if ((id1!= 1 && id2 == 0 )|| (id2-id1 == 1))flag_inverse =false;
	//else flag_inverse = true;
	flag_inverse =false;
	l_id = m_Pts.front()->id_InComploop;
	r_id = m_Pts.back()->id_InComploop;
	m_Edges.clear();
	return true;
}





bool Plane_ConnectiveEdgeList::InitialbyPtlist_stepEgs(TP_PtList *plist)
{
	m_Edges.clear();
	m_Pts.clear();
	int npt = plist->size();
	
	for (int i =0; i< npt;i++)
	{
		TP_Vertex *pt = &plist->data()[i];		 
		if (pt->PtStab > StepInside)
		{
			TP_Vertex *pt_add = new TP_Vertex;
			*pt_add = *pt;
			m_Pts.push_back(pt_add);
		}		
	}
	l_nbd = r_nbd = 0;
	flag_inverse =false;
	if (m_Pts.empty())return false;
	
	l_id = m_Pts.front()->ID;
	r_id = m_Pts.back()->ID;
	m_Edges.clear();
	isPCEStepEg = true;
	return true;
}

void Plane_ConnectiveEdgeList::ComparePtWithPCE(CCVector3 pt,int *pos, double *dMin)
{
	TP_Vertex *pt1,*pt2;
	std::list<TP_Vertex* >::iterator itr = m_Pts.begin();
	double dis;	(*dMin) = 99999;
	for (int count=0; count < m_Pts.size() -1;count ++)
	{
		pt1 = (*itr++);
		pt2 = (*itr);
		dis = calProPt2LineSegment_2d(&pt,&pt1->m_p,&pt2->m_p);
	    if (dis < (*dMin))
	    {
			(*dMin) = dis;(*pos) = count;
	    }
	}	
}
void  Plane_ConnectiveEdgeList::copyPCE(Plane_ConnectiveEdgeList pce,TP_PtList *savedPts)
{

	l_id = pce.l_id; r_id = pce.l_id;
	l_nbd = pce.l_nbd;r_nbd = pce.r_nbd;
	flag_inverse = pce.flag_inverse;
	isPCEStepEg = pce.isPCEStepEg;
	combinedByAnother = pce.combinedByAnother;

	m_Pts.clear();
	m_Edges.clear();
	savedPts->clear();
	for (std::list<TP_Vertex*>::iterator itr = pce.m_Pts.begin(); itr!= pce.m_Pts.end();itr++ )
	{
		TP_Vertex * pt = (*itr);
		TP_Vertex pt_new = (* pt);
		savedPts->push_back(pt_new);
		m_Pts.push_back(&pt_new);
	}


//	for (std::list<TP_Vertex*>::iterator itr = pce.m_Pts.begin(); itr!= pce.m_Pts.end();itr++ )m_Pts.push_back(*itr);
	for (std::list<TP_Edge*>::iterator itr1 = pce.m_Edges.begin(); itr1!= pce.m_Edges.end();itr1++ )m_Edges.push_back(*itr1);	



}
void Plane_ConnectiveEdgeList::deleteSingleShortPCE()
{
	if (m_Pts.size() == 2)
	{
		CCVector3 pt1 = m_Pts.front()->m_p;
		CCVector3 pt2 = m_Pts.back()->m_p;
		if (calDisP2P_xyz_sqrt(pt1,pt2) < 1) isPCECanceled = true;
	}
}
