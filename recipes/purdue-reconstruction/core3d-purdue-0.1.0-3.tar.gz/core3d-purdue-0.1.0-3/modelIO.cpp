//#include "stdafx.h"
#include "modelIO.h"

void estimateModelSize(TP_Model *m_model,long &pt_count,long &pl_count)
{
	TP_BuidlingPlanes *planes=&m_model->planes;
	if (planes == nullptr || planes->empty())return;

	int n_planes=planes->size();
	TP_Plane *p_now=NULL;
	TP_PlaneBoundary *bd=NULL;
	long pt_countNow;
	for (size_t i = 0; i<n_planes; i++)
	{
		p_now=planes->data()[(i)];
		for (size_t j = 0; j < p_now->m_boundarys->size(); j++)
		{
			if (p_now->m_boundarys->at(j)->type != OUTSIDE_EDGE)continue;
			pt_countNow = p_now->m_boundarys->at(j)->mixBd.size();
			if (pt_countNow > 2)
			{
				pl_count++;
				pt_count += pt_countNow;
			}
		}
	}
}


void writePlyhead(FILE * fp,TP_Model *md, long pt_count,long pl_count)
{
	fprintf(fp,"ply\n format   ascii   1.0\n element   vertex   %d\n property   float32   x\n property   float32   y\n property   float32   z\n",pt_count);
	fprintf(fp," element   face   %d\n property   list   uint8   int32   vertex_index\n",pl_count);
	
	TP_BuidlingPlanes *planes = &md->planes;
	int n_planes = planes->size();
	TP_Plane *p_now = NULL;
	int *id_pro = new int[n_planes];
	for (int i = 0; i < n_planes; i++) id_pro[i] = -1;
	int id_pro_now = 0;
	for (int i = 0; i < n_planes; i++)
	{
		p_now = planes->data()[(i)];

		for (size_t j = 0; j < p_now->m_boundarys->size(); j++)
		{
			if (p_now->m_boundarys->at(j)->type != OUTSIDE_EDGE)continue;

			long pts_count = p_now->m_boundarys->at(j)->mixBd.size();
			if (pts_count < 3)continue;

			fprintf(fp, "comment :plane ID: %d   ",id_pro_now);
			fprintf(fp, " para: m_a = %lf m_b = %lf m_c = %lf\n", p_now->m_a, p_now->m_b, p_now->m_c);
			id_pro[i] = id_pro_now;
			id_pro_now++;
		}
	}

	PrimitiveMatch mat;
	mat.InitialMatch(md);
	mat.do_search();

	for (int i = 0; i < mat.hips.size();i++)
	{
		int *ids = &mat.hips.at(i).nodes_ids[0];
		fprintf(fp, "comment :a Hipped: Planes ID: %d %d %d %d\n", id_pro[*ids], id_pro[*(ids + 1)], id_pro[*(ids + 2)], id_pro[*(ids + 3)]);
	}
	for (int i = 0; i < mat.gams.size(); i++)
	{
		int *ids = &mat.gams.at(i).nodes_ids[0];
		fprintf(fp, "comment :a Gambrel: Planes ID: %d %d %d %d\n", id_pro[*ids], id_pro[*(ids + 1)], id_pro[*(ids + 2)], id_pro[*(ids + 3)]);
	}
	for (int i = 0; i < mat.gabs.size(); i++)
	{
		int *ids = &mat.gabs.at(i).nodes_ids[0];
		fprintf(fp, "comment :a Gable: Planes ID: %d %d\n", id_pro[*ids], id_pro[*(ids + 1)]);
	}

	char * ptlist_wri = new char[BUfPathLenght];
	memset(ptlist_wri, 0, sizeof(char) * 1024);

	if (!mat.flats.empty())
	{
		sprintf(ptlist_wri, "comment :all %d Flats: Planes ID: ", mat.flats.size());
		for (long k = 0; k < mat.flats.size(); k++)
		{
			int id = mat.flats.at(k);
			sprintf(ptlist_wri, "%s%d ", ptlist_wri, id_pro[id]);
		}		
		fprintf(fp, ptlist_wri);
		fprintf(fp, "\n");
	}

	if (!mat.sheds.empty())
	{
		sprintf(ptlist_wri, "comment :all %d Shelds: Planes ID: ", mat.sheds.size());
		for (long k = 0; k < mat.sheds.size(); k++)
		{
			int id = mat.sheds.at(k);
			sprintf(ptlist_wri, "%s%d ", ptlist_wri,id_pro[id] );
		}
		fprintf(fp, ptlist_wri);
		fprintf(fp, "\n");
	}
	
	fprintf(fp, "end_header\n");

}

void writeModelData1(FILE *fp,TP_Model *m_model,long &v_st,Vector3_lf m_offset)
{
		TP_BuidlingPlanes *planes=&m_model->planes;
		int n_planes=planes->size();
		TP_Plane *p_now=NULL;

		TP_PlaneBoundary *bd=NULL;
		TP_PtList *pts=NULL;		
		for (int i=0;i<n_planes;i++)
		{
			p_now=planes->data()[(i)];
			for (size_t j = 0; j < p_now->m_boundarys->size(); j++)
			{
				if (p_now->m_boundarys->at(j)->type != OUTSIDE_EDGE)continue;

				long pts_count = p_now->m_boundarys->at(j)->mixBd.size();

				if (pts_count < 3)continue;

				for (int k = 0; k < pts_count; k++)
				{
					CCVector3 mp = p_now->m_boundarys->at(j)->mixBd.at(k).m_p;
					p_now->Point2D_to_3D_ccVector3(mp);
					fprintf(fp, "%.6lf %.6lf %.6lf\n", mp.x + m_offset.x, mp.y + m_offset.y, mp.z + m_offset.z);
					//fprintf(fp, "%.6lf %.6lf %.6lf\n", mp.x, mp.y, mp.z);
				}
			}
		}	
}



void writeModelData2(FILE *fp,TP_Model *m_model,long &v_count)
{
	TP_BuidlingPlanes *planes=&m_model->planes;	
	int n_planes=planes->size();
	TP_Plane *p_now=NULL;
	TP_PlaneBoundary *bd=NULL;
	TP_PtList *pts=NULL;	
	char * ptlist_wri = new char[BUfPathLenght];

	for (int i=0;i<n_planes;i++)
	{
		memset(ptlist_wri, 0, sizeof(char) * 1024);
		p_now=planes->data()[(i)];
				
		for (size_t j = 0; j < p_now->m_boundarys->size();j++)
		{
			if (p_now->m_boundarys->at(j)->type != OUTSIDE_EDGE)continue;
	
			long pts_count = p_now->m_boundarys->at(j)->mixBd.size();
			if (pts_count < 3)continue;

			sprintf(ptlist_wri, "%d ", pts_count);
			for (long k = 0; k < pts_count; k++)
			{
				sprintf(ptlist_wri, "%s%d ", ptlist_wri, v_count + k);
			}
			v_count += pts_count;
			sprintf(ptlist_wri, "%s\n", ptlist_wri);
			fprintf(fp, ptlist_wri);			
		}
			
	}	



	delete[]ptlist_wri;
}


void model_IO::writeModel(char* outPath, TP_Model model, int modelNum)
{
  char* modelPath_i= new char[BUfPathLenght];

  long v_sum=0,f_sum=0;

  estimateModelSize(&model, v_sum, f_sum);
  if (v_sum == 0 || f_sum == 0)
    return;

  sprintf(modelPath_i, "%s%d.ply", outPath, modelNum);
  FILE *fp=fopen(modelPath_i,"w+");
  if (fp == nullptr)
  {
    printf("can not get the right output path");
    return ;
  }
  writePlyhead(fp, &model, v_sum, f_sum);
  long v_count=0, f_count =0;
  writeModelData1(fp, &model, v_count, Vector3_lf(offset_x, offset_y, offset_z));
  v_count =0;
  writeModelData2(fp, &model, v_count);

  fclose(fp);

  delete[]modelPath_i;
}

void model_IO::writsModels(char* outPath)
{
	char* modelPath_i= new char[BUfPathLenght];
	long md_count = 0;
	for(int i=0;i< m_models.size();i++)
	{
		long v_sum=0,f_sum=0;		
		estimateModelSize(&m_models.data()[i], v_sum, f_sum);
		if (v_sum == 0 || f_sum == 0)continue;

		sprintf(modelPath_i, "%s%d.ply", outPath, md_count);
		FILE *fp=fopen(modelPath_i,"w+");
		if (fp == nullptr)
		{
			printf("can not get the right output path");
			return ;
		}			
		writePlyhead(fp, &m_models.data()[i],v_sum, f_sum);
		long v_count=0, f_count =0;
		writeModelData1(fp, &m_models.data()[i], v_count, Vector3_lf(offset_x, offset_y, offset_z));
		v_count =0;
		writeModelData2(fp, &m_models.data()[i], v_count);



		fclose(fp);
		md_count++;
	}
	delete[]modelPath_i;
}
bool stasticLableInformation(vector<long >  &labels, vector<Vector2_d > &infors, long leastPtCount)
{
	if (labels.empty())return false;

	long id_max, id_min, id_now;
	id_min = id_max = labels.front();

	size_t npt = labels.size();
	for (size_t i = 0; i < npt; i++)
	{
		id_now = labels.at(i);
		if (id_now < id_min) id_min = id_now;
		if (id_now > id_max) id_max = id_now;
	}
	long n_lab = id_max - id_min + 1;
	Vector2_d *pLabs = new Vector2_d[n_lab];
	for (long j = 0; j < n_lab; j++)
	{
		pLabs[j].x = id_min + j;
		pLabs[j].y = 0;
	}
	for (size_t i = 0; i < npt; i++)
	{
		id_now = labels.at(i);
		pLabs[id_now - id_min].y += 1;
	}

	for (long j = 0; j < n_lab; j++)
	{
		if (pLabs[j].x != 0 && pLabs[j].y > leastPtCount)
		{
			infors.push_back(pLabs[j]);
		}
	}

	if (infors.empty())return false;
	
	return true;
}

bool re_center_PointCloud(ccPointCloud* _in, Vector3_lf &cen)
{
	size_t pt_in = _in->size();
	double cen_x, cen_y, cen_z;
	cen_x = cen_y = cen_z = 0;
	for (size_t i = 0; i < pt_in; i++)
	{
		cen_x += _in->data()[i].x / (double)pt_in;
		cen_y += _in->data()[i].y / (double)pt_in;
		cen_z += _in->data()[i].z / (double)pt_in;
	}

	cen.x = cen_x;
	cen.y = cen_y;
	cen.z = cen_z;

	for (size_t i = 0; i < pt_in; i++)
	{
		_in->data()[i].x -= cen_x;
		_in->data()[i].y -= cen_y;
		_in->data()[i].z -= cen_z;
	}
	return true;
}

bool model_IO::readSegmentationResults(char *inPath)
{
	FILE *fp = fopen(inPath, "r");
	if (fp == nullptr)return false;
	int modelCount = 0;
	long minBdPtNum  = 500;
	long minSegPtNum = 10;
	double aveDis = 0.5; 
	double v_alpha = 20 * aveDis;
	long n_pt, bd_id, seg_id,n_bdpt,pt_id;
	Vector3_lf pt_now;
	Vector2_d segRange, bdRange;
	int MAX_STRING = 200;
	char  *pLine = new char[MAX_STRING];
	
	vector<Vector3_lf> ptsBuf;
	vector<long > segLabel;
	vector<long > bdLabel;
	double id1, id2;
	while (NULL != fgets(pLine, MAX_STRING, fp))
	{
		//support long or double types of lables incase the type output labels are changed by softwares like cloudcompare;
		if (sscanf(pLine, "%lf %lf %lf %lf %lf", &pt_now.x, &pt_now.y, &pt_now.z, &id1, &id2))
	   {		  
		   ptsBuf.push_back(pt_now);
		   segLabel.push_back((long)id1);
		   bdLabel.push_back((long)id2);
	   }	  		
	}
	n_pt = (long)ptsBuf.size();

	Vector3_lf offset_val;
	re_center_PointCloud(&ptsBuf, offset_val);
	offset_x = offset_val.x; offset_y = offset_val.y; offset_z = offset_val.z;
	
	vector<Vector2_d > bdInfors;
	if (stasticLableInformation(bdLabel, bdInfors, minBdPtNum))
	{
		size_t n_bd = bdInfors.size();
		
		for (size_t i = 0; i < n_bd; i++)
		{
			Vector2_d inf_add = bdInfors.at(i);
			bd_id = inf_add.x;
			n_bdpt = inf_add.y;
			
			ccPointCloud *pts_add = new ccPointCloud; pts_add->resize(inf_add.y);						
			vector<long >  segLabels_i; segLabels_i.resize(inf_add.y);
			pt_id = 0;
			for (size_t j = 0; j < n_pt; j++)
			{
				if (bdLabel[j] == bd_id)
				{
					pts_add->data()[pt_id] = ptsBuf[j];
					segLabels_i[pt_id] = segLabel[j];
					pt_id++;
				}
			}
			if (pt_id < minBdPtNum)
			{
				pts_add->clear();
				continue;
			}
			int n_outbd = 0;
			TP_Model mod_add;
			mod_add.setPointCloud(pts_add);
			mod_add.aveDis = aveDis;
			mod_add.bd_all = generateEdge_adaptedAlpha(pts_add, &v_alpha, &n_outbd);

			bool flag_model_accept = true;

			for (long id_boundury = 0; id_boundury < mod_add.bd_all->size(); id_boundury++)
			{
				if (mod_add.bd_all->at(id_boundury)->type != OUTSIDE_EDGE)continue;
				TP_PtList *out_all = &mod_add.bd_all->at(id_boundury)->m_pts;
				CCVector3 bb1, bb2;
				getBBofPtlist(out_all, &bb1, &bb2);
				//double max_Size = 500;
				//if (bb2.x - bb1.x > max_Size || bb2.y - bb1.y > max_Size) flag_model_accept = false;
				
				double m_area = polygon_area(out_all);
				double m_len = polygon_length(out_all);
				double rat = sqrt(m_area) / m_len;
				//if (rat < 0.06 )flag_model_accept = false;
				printf("    ratio = %lf", rat);								
			}
			if (flag_model_accept == false)
			{
				printf("   We give up it!\n");
				continue;

			}			
			
			vector<Vector2_d > segInfors;
			stasticLableInformation(segLabels_i, segInfors, minSegPtNum);
			size_t nSeg_i = segInfors.size();
			double facade_count = 0;
			for (size_t j = 0; j < nSeg_i; j++)
			{
				ccPointCloud *facade_add = new ccPointCloud;
				long n_seg_i_j = segInfors.at(j).y;
				seg_id = segInfors.at(j).x;
				
				facade_add->resize(n_seg_i_j);
				pt_id = 0;
				for (size_t k = 0; k < n_bdpt; k++)
				{
					if (segLabels_i[k] == seg_id)
					{
						facade_add->data()[pt_id] = pts_add->data()[k];
						pt_id++;
					}
				}
				TP_Plane *plane_add = new TP_Plane;
				plane_add->setPointCloud(facade_add);
				if (seg_id < 0)plane_add->setPlaneType(true);
				else plane_add->setPlaneType(false);
				   plane_add->ID = plane_add->FacadeCount = facade_count;
				   plane_add->aveDis = mod_add.aveDis;
				   if (plane_add->caculatePlaneMessage() && plane_add->m_c > 0.3)
				   {					   
					   mod_add.planes.push_back(plane_add);
					   facade_count++;					 
				   }
				   else
				   {
					   delete facade_add;
					   delete plane_add;
				   }
			}
			mod_add.aveDis_all = aveDis;
			printf("Now begin to construct the %d th building\n", modelCount + 1);


			

			mod_add.Construct_main();

                        //                      m_models.push_back(mod_add);
                        writeModel( inPath, mod_add, modelCount);
			++modelCount;

			printf("      The %d th building end!\n",m_models.size());
		}
	}	
	return false;
}
