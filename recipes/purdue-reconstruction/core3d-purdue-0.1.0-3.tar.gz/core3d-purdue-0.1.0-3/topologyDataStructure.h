#ifndef _TOPOLOGY_DATA_STRUCTURE_NEW_DEFINE_H
#define _TOPOLOGY_DATA_STRUCTURE_NEW_DEFINE_H

//#include <pcl/point_types.h>
//#include <pcl/io/pcd_io.h>
//#include <pcl/search/search.h>
//#include <pcl/search/kdtree.h>
//#include <pcl/features/normal_3d.h>
//#include <pcl/common/centroid.h>
#include <pcl/common/transforms.h>
#include <pcl/common/common.h>
//#include <pcl/surface/gp3.h>
//#include <pcl/surface/poisson.h>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <list>
#include <assert.h>
using namespace std;

#define BUfPathLenght 1024
#define  PI 3.1415926535897932384626433832795e0

typedef std::vector<int > IDList;
struct Vector3_lf
{
	double x, y, z;
	Vector3_lf(){};
	Vector3_lf(double x1, double y1, double z1)
	{
		x = x1; y = y1; z = z1;
	};
	void operator=(const Vector3_lf &b)
	{
		x = b.x;
		y = b.y;
		z = b.z;
	};
	Vector3_lf operator+(const  Vector3_lf &b) const
	{
		return Vector3_lf(this->x + b.x, this->y + b.y, this->z + b.z);
	};
	 Vector3_lf operator-(const Vector3_lf &b) const
	{
		return Vector3_lf(this->x - b.x, this->y - b.y, this->z - b.z);
	};
	 Vector3_lf& operator += (const Vector3_lf &b)
	 {
		this->x += b.x;
		this->y += b.y;
		this->z += b.z;
                return *this;
		 
	 };
	 Vector3_lf& operator-=(const Vector3_lf &b)
	 {
                this->x -= b.x;
                this->y -= b.y;
                this->z -= b.z;
                return *this;
	 };
	 Vector3_lf operator*(double b) const
	{
		return Vector3_lf(this->x * b, this->y * b, this->z * b);		
	};
	
	 Vector3_lf operator/(double b) const
	{
		return Vector3_lf(this->x/b, this->y/b, this->z/b);
	};
	 Vector3_lf& operator *= (const double b) 
	 {
		this->x *= b;
		this->y *= b;
		this->z *= b;
                return *this;
	 };
	 Vector3_lf& operator/=(const double b) 
	 {
                this->x /= b;
                this->y /= b;
                this->z /= b;
	        return *this;
	 };
};
/*
Vector3_lf operator*(const double b, Vector3_lf pt)
{
	return pt *b;
};
*/


typedef Vector3_lf CCVector3;
typedef std::vector<Vector3_lf > ccPointCloud;


struct Vector2_lf
{
	double x, y;
	Vector2_lf(){x = 0; y = 0;};
	Vector2_lf(double x1, double y1)
	{
		x = x1; y = y1;
	};
};
typedef Vector2_lf CCVector2;

struct Vector2_d
{
	long x, y;
	Vector2_d(){x = 0; y = 0;};
	Vector2_d(long x1, long y1)
	{
		x = x1; y = y1;
	};
};
typedef Vector2_d CCVector2i;

struct Vector3_d
{
	long x, y,z;
	Vector3_d(){x = 0; y = 0; z = 0;};
	Vector3_d(long x1, long y1,long z1)
	{
		x = x1; y = y1,z =z1;
	};
};
typedef Vector3_d CCVector3d;

struct Plane_parameters
{
	double m_a,m_b,m_c,m_d;
};

enum CloudStatus
{
	Initial=0,
	Filtered=1,
	Classified=2
};

enum PointStability
{
	Ordinary=0,
	OriginCorner=1,
	StepInside=2,
	StepEdgeEnd_X=3,
	StepEdgeEnd_Y=4,
	StepEdgeCorner=5,
	Extensible=6,
	Extensided=7,
	Stable=8
};
enum PointType//for corner pts;
{
//unStable type
	//Ordinary
		Unknow=0,

	//after compared with out bd
		Ordinary_Inside=1,
		Ordinary_Outside=2,

	//for roof edge Pt
		Extensible_Unknow=3,
		Extensible_Inside=4,
		Extensible_nearBD=5,
		
		
		Extensible_OutsideStepBD_Ends=6,
		Extensible_InsideStepBD_Ends=7,
		Extensible_Roof_Ends=8,
    //  
	    NewlyAddCorners=9,
//Stable type
	//for roof edge Pt
	    InterSect_Vertical_Outside_BD=11,
		InterSect_Vertical_Inside_Step=12,

	    Extensided_onBD=14,
		Extensided_onInnerStep=15,
				
		InterSect_MultiplyRidge_Inside=16
};


struct TP_Vertex
{
	long ID;//in bd list
	int id_inMixBd;
	CCVector3 m_p;

	int ID_inPlane;
	int PlaneID;
	int roofRidgeID_ifis;

	PointStability PtStab;//������ȶ��� �����ཻΪ4	 �ݼ��߷ǽ���Ϊ3   ��Ծ�߶���Ϊ2  �����Ե���Ľǵ�Ϊ1
	PointType PtType;

	int comp_flag;// true: same;
    int id_InComploop;


    double dis_to_edge;
	bool near_edge;
	bool delete_flag;
	int  i_loop;
	bool onBD;
	int id_ifisModelCorner;
	TP_Vertex(){ near_edge = delete_flag = onBD = false; PtType = Unknow; PtStab = Ordinary; roofRidgeID_ifis = PlaneID = comp_flag = id_ifisModelCorner = -1; i_loop = -1; }
    TP_Vertex(TP_Vertex *m_value){memcpy(this,m_value,sizeof(TP_Vertex));}
};

typedef std::vector<TP_Vertex> TP_PtList;

struct TP_Edge
{
	int ID;	
	int orientation;//0 not set  1  para  2  ve
	TP_Vertex *ptBejin,*ptEnd;
	int l_stable,r_stable;
	bool translated;

	int n_bd,bd_start,bd_end;//ID in BdList
	double length;
	int edgeID;
	int face;	

    TP_Edge()
	{
		ptBejin=ptEnd=NULL;
	    l_stable=r_stable=0;
        translated =false;
	}
	//int certainty;//0-3.  0--none; 1- edge;  2- intersect edge; 3-mul intersect;
};
typedef std::vector<TP_Edge> TP_EgList;
enum BoundaryType
{
	OUTSIDE_EDGE =0,
	INNER_HOLE=1,
	False=2
};

struct  BoundaryPts 
{
	TP_PtList m_pts;
	TP_PtList corners;
    TP_PtList mixBd;
	 TP_PtList finalBd;


	TP_PtList convex;
	BoundaryType type;
	float alpha_scale;
	int ID;
} ;
typedef vector<BoundaryPts* > TP_PlaneBoundary;

typedef struct 
{
	double	XMax;
	double	XMin;
	double	YMax;
	double	YMin;
}D_RECT;


struct dauglasPoint
{
	int id;
	Vector3_lf *pts;
	double m_value;
	int save;//
};
enum eTV_PointClass
{
	Others=0,//
	Planar_Inside=1,//
	Planar_Boundury=2,//
	Noneplanar_Boundury=3,//
	Noise=4
};

struct TV_PointMessage
{
	long ID;
	double n_x;
	double n_y;
	double n_z;
	float c_1;
	float c_2;
	float c_3;
	int classification;//
	eTV_PointClass edgetype;//

};


enum planeType
{
	H=0,
	S=1
};


//Horizontal  : H 
//Slant       : S 
//Step        : Step 
enum ridgeType
{	
	Undecided=0,
	NotExist=1,     
	Step=2,         //   
	Inside=3,       // 
	SS_S_concave=4, //
	SS_S_convex=5,   //
	HS_H=6,         //
	SS_H=7         //

};


enum ori_Type
{
	ori_none= 0,
	ori_single=1,
	ori_multiply=2,

	ori_exSingle=3,//
	ori_exmultiply=4
};

enum PrimitivesType
{
	Shed_1 = 1,
	Flat_1 = 2,
	Gable_2 = 3,
	Gambrel_4 = 4,
	Hipped_4 = 5,
	Mansard_8 = 6
};

struct PrimitiveInfor
{
	PrimitivesType m_type;
	IDList planeIDs;
	IDList ridgeIds;
};

struct tinPointDiscriber
{
	int PlaneID;//
	long ID_all;
	long ID_plane;
	
	CCVector3 pt;
	CCVector3 nv;
};

struct tinPointConnecters//
{	
	int planeID_1;//
	int planeID_2;


	CCVector3 pt1, pt2;
	double dis_3d;//
	double delt_h;//
	double delt_h_1;//
};

typedef std::vector<tinPointConnecters > LineSegmentsList;



struct G_Vertex
{
	int ID;
	int fatherID;
	int m_type;
	void *attr;
	G_Vertex(){ fatherID = -1; m_type = -1; }
	
};

struct G_Edge
{  
	int ID;
	int fatherID;
	int ID_1;//v1
	int ID_2;//v2
	ridgeType edgeType;
	bool flag_use;
	double weight;
	double len;
	TP_Vertex *p1,*p2;

	int ori_group;
	void *attr;
	void *attr1;
	bool flag_planeInPlane;
	int m_type;
	G_Edge(){ fatherID = -1; m_type = -1; }
};


struct Plane_bd_range
{	
	int n_bd;
	int id_min;
	int id_max;
	bool f_inverse;
};

struct TP_Plane_ridgeMessage
{

	int ridge;//

	G_Edge *m_edge;
	bool isPlaneID_large;//p1_id < p2_id 
	//2.
	int n_bd;//

	int n_bd_attr;//
	int list_start;//
	int list_end;

	TP_Vertex *p1,*p2;
};
struct TP_Plane_LoopMessage//
{
	int loopID;
	int edge1,edge2;//plane1  plane2
	TP_Vertex *cornerPt;
};

struct TP_Plane_ExtensiblePts
{
	int n_bd;
	int IDinBd;
	bool flag_orientation;
	TP_Vertex end_pt;
	TP_Vertex inside_pt;

	int belonged_edge;// -1: step/bd   0-n  edgeID. 
	int type; //0 normal  1: same with main direction  2: vertical with main direction 
	TP_Plane_ExtensiblePts(){}
	TP_Plane_ExtensiblePts(int bd,int id, int be_eg,bool flag,TP_Vertex *pt_e,TP_Vertex *pt_in)
	{
		n_bd=bd;IDinBd=id;belonged_edge=be_eg,flag_orientation=flag;
		if (pt_e != NULL && pt_in!= NULL)
		{
           end_pt= *pt_e;inside_pt= *pt_in;
		}
       
	}
};

enum EdgeOri
{
	NotCount=-1,
	Any= 0,
	With_Same_X_Value=1,
	With_Same_Y_Value=2
};

struct UnDecideded_PtList
{
	int ridgeID;
	int ridge_next;
	bool f_cacullated;
	int planeID;
	int IDinMixBD;
	int ori;//insider id increase ori

	EdgeOri e_st,e_end;
	EdgeOri step_ori;//ori of setpEdge
	double val;//value of step
	bool f_sngPlaneEg;
	bool val_increase;

	TP_Vertex startPt_src;

	TP_Vertex startPt_new;
	TP_Vertex endPt_new;

	TP_Vertex st_InsidePt;
	TP_Vertex end_InsidePt;

	TP_PtList pts;
	TP_PtList *MixBD;
	UnDecideded_PtList()
	{
		ridge_next = -1;
		MixBD =NULL;
		f_sngPlaneEg =false;
		f_cacullated =false;
		e_st=e_end= NotCount;
	}
};

enum eTP_edgeType
{
	outsideBD =0,
	insideStep =1,
	roofRidge = 2
};
#endif
