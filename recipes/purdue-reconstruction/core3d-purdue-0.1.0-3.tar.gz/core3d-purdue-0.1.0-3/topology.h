﻿#ifndef __LiDAR_POINT_PROCESS_TOPOLOGY_CLASS_DEFINE_H__
#define __LiDAR_POINT_PROCESS_TOPOLOGY_CLASS_DEFINE_H__

#include "Function.h"
#include "Graph.h"
#include "tpPlane.h"
#include "BdLoop.h"
#include "Plane_Plane_Relationship.h"

struct TP_ModelBDSegments
{
	int id_plane;
	int id_st,id_end;

	IDList id_oris;
	vector<CCVector2 > m_oris;
	vector<Plane_Plane_Relation *> m_pprs;
	int id1,id2;
	Plane_ConnectiveEdgeList *pce;
};



 struct TP_ModelCorner
{
//	Plane_ConnectiveEdgeList *m_left,*m_right;
	TP_Vertex pt_l,pt_r;
};

class Wall_between_ChildModels
{
public:

	Plane_Plane_Relation * ppr_all;
	vector<Plane_ConnectiveEdgeList *> m_egs;

public:
	 Wall_between_ChildModels(){};
};



class TP_Model:public TP_showObject
{
public:
	TP_Model * father;
	int id_ifIschildmodel;


	char* f_path;

	CCVector2 *mainDirection;
	CCVector3 *centerPt;
  	double x_offset,y_offset,z_offset;

	float aveDis;
	float aveDis_all;
	TP_BuidlingPlanes planes; 
	int n_plane;
	
//	CTINClass *tin ;
	LineSegmentsList * pLSL;

	long *ptsID;
	int sfFacadeID;
//	TV_PointMessage *pMes;


	vector<TP_Plane *> m_insidePlanes;

	int *map_scalar2facade;
	tinPointDiscriber *ptsTPD;
	
	int *mID_f2c;//
	int *vID_f2c;//

	Graph *tpGraph_initial;
	Graph *tpGraph_childs;
	vector<TP_Model*  > *m_childs;

	ori_Type  m_oriType;
	vector<CCVector2 >  ori_pools;
	vector<IDList >  m_ori_flags;
	int *ori_ridges;

	Plane_Plane_Relation **m_ppr ;

	TP_PlaneBoundary  m_testBD;
	TP_PlaneBoundary *bd_all ;
	vector<TP_PtList > stepPlanes;


	TP_Plane *pl_As_a_Whole;

	vector <TP_ModelCorner* > mcd;
	vector <Wall_between_ChildModels *> wcm;


	bool flag_hasImageRidges;
	//vector <ImageLine > m_imageLines;
	//imageRPC  m_rpc;

	
public: 
	TP_Model();
	~TP_Model();
    void setShift(	double x_,double y_,double z_)
        {
            x_offset = x_;
            y_offset = y_;
            z_offset = z_;
        }

	void Construct_main();
	
	void setSfFacadeID(int ID){sfFacadeID= ID;}
	void caculateBuildingMainDirection();
    void caculateM2M_relation(TP_Model *child_1,TP_Model * child_2);
//  bool isLineNearModel(TP_PtList *m_outBD, double model_hei,imageRPC *m_rpc,ImageLine &m_line);
//	bool readImageLineFile(QString m_path,int img_id,double x_offset,double y_offset);

	//void neighborcompetetion();
private: 
	void findInsidePlanes_andProjection();
//main function
	void distinguishEdgeType();//1
	void divideModleIntoChilds();//2
//	void caculateBoundury();//3

	//methods for 1
	
	void createAdjGraph();
	//methods for 2
	void decomposeGraph();
	void caculateChildsAndRelations();

	//methods for 3
	void searchLoopsInGraph();
	TP_Vertex*  MultiplyPlanesAtOnePoint(IDList* planeIDs, double Thre);
	void caculateModelBounder();



	void caculateM2M_relation(TP_Model *child_1,TP_Model * child_2,vector <Plane_Plane_Relation *> m_pprs);
	TP_Plane* getPlaneByID(int ID)
	{
		if (planes.empty())return NULL;
		else 
		{
			for (int i = 0;i < planes.size(); i++)
			{
				if (planes.at(i)->ID == ID)return planes.data()[i];
			}
			return NULL;
		}
	}

//new
	void caculateLOD_1();
	ori_Type testOrientation();
	void decideModelOri();


	void markModelOusideBd();


	void caculateModelBounduryOnWall();
	void PrepareChildMessage();

	void AdjustModelCorners();


	void findPrimitivesInModel();
	//void uploadUndecidedBDs();
};





#endif