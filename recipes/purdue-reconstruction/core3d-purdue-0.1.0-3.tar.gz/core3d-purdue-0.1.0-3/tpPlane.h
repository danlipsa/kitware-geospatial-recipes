﻿#ifndef __LiDAR_POINT_PROCESS_TOPOLOGY_TP_PLANE_CLASS_DEFINE_H__
#define __LiDAR_POINT_PROCESS_TOPOLOGY_TP_PLANE_CLASS_DEFINE_H__

#include "Function.h"
#include "Graph.h"
//#include "bounduryAdjustment.h"
#include "BdLoop.h"

struct CornerEdgeSegment_Describer
{
	int ID;
	int corID;
	int count1,count2;
	int id_ifAddPts;

	double pro_max;
	bool isPara, isVertical;
	CCVector3 rg_nv,bd_nv;
	TP_Vertex *rg_out,*rg_in;
	TP_Vertex *bd_out,*bd_in;
	TP_Vertex *add_pt ;

	CornerEdgeSegment_Describer()
	{
		add_pt = NULL;
		ID = corID = count1= count2 = id_ifAddPts = -1;
		pro_max =0;
		isPara = isVertical =false;
	}


};
struct Pl_Triangle_IDs
{
	int id[3];
};



class TP_showObject
{
private:
	
	vector<Vector3_lf > * m_pts;
public:	
	TP_showObject(){}
	void setPointCloud(vector<Vector3_lf > *pts)
	{
		m_pts = pts;
	}
	vector<Vector3_lf >*  getPointCloud()
	{
		return m_pts;
	}
	long  getPointNumber()
	{
		return m_pts->size();
	}
	Vector3_lf computeGravityCenter();
};

class TP_Plane:public TP_showObject
{
public:

	vector<TP_Plane *> childPlanes;
	bool flag_IsInsidePlane;
	int fatherID;
	//	TP_PlaneRidges m_ridges;
	TP_PlaneBoundary  *m_boundarys;//
	BoundaryPts *m_outsideBD;//
	int id_outside;

	float alpha_scale;
	float alpha_0;
	//	int mainEdgeID;
	vector<TP_Plane_ridgeMessage> m_ridgesMessage;
	vector<TP_Plane_LoopMessage> m_loopMessage;
	vector<G_Edge*> m_GEdges;
	vector<CCVector2i > m_markedSegments;
	Graph *m_graph_Ed;

	float m_a,m_b,m_c,m_d;
	CCVector3 centerPt;
	double m_planeArea ;
	double m_planeLen ;
	double m_Planequa ;

	long ID;
	planeType m_type;
	bool flag_caculated;
	long ID_Pt_min;
	long FacadeCount;
	long ID_childModle;

	vector<Plane_ConnectiveEdgeList* > out_PCE;
	bool flag_havingCombingBds;
	Plane_bd_range r1,r2;

	vector<Plane_bd_range > bd_onModelEdge;
	vector<TP_Plane_ExtensiblePts> extPts;

	TP_PtList cornersInModelBd;


	TP_PtList convex_BD;

	float aveDis;

	
	IDList ori_id;
    ori_Type m_oriType;	
	bool f_expanded;
public:
	double show_val;

	//HE_edge* m_edge;
	vector <Pl_Triangle_IDs>   m_triangleIDs;
	vector <CCVector3 > m_trianglePts;
	long m_tri_idStart;

	bool isUnRoboustPlane;
	bool isBdRegular;
public:
	TP_Plane();
	void setPlaneType(bool isRo)
	{
		isUnRoboustPlane = isRo;
	}
	
	void Point2D_to_3D(TP_Vertex *_in);
	CCVector3 Point2D_to_3D_ccVector3(const CCVector3 _in);
	void MixBounduryWithRoofEdges();
//	void MixBounduryWithModelBd(bdAdjustment *modelBD);
	bool caculatePlaneMessage(int type=0);
	bool checkPlaneQuality();
	bool getPlaneEdge(double alpha);
	void getPlaneParameter();//ax+by+cz+d=0
//	void caculateSingleInsidePlane(bdAdjustment *modelBD,TP_Plane *FatherPlane);
	double calDisPt2Plane(CCVector3 pt)//
	{
		return fabs(m_a* pt.x + m_b* pt.y + m_c * pt.z + m_d);
	}
	bool getCornerEdgeSegment_Describer(int ID,CornerEdgeSegment_Describer *CES_D);
private:
	void connect_Out_PCE();
	void combineEdgeMessageInto_Out_PCE();
	vector<TP_Plane_ridgeMessage* > * getP_RM_byEdgeID(int n_e);
	void connectMulitiplyOutsideEdges();
	void getBdMixedbyRidgeAndBdPts();
	
	void insertPCEintoBd(TP_PtList *pts,Plane_ConnectiveEdgeList *_PCE,Plane_bd_range *m_range);
//	void adjustBdByReplaceBoundurys(bdAdjustment *modelBD);
//	void fitModelBdsFromMixBd(bdAdjustment *modelBD);

//	void connect_extensibleEdges(bdAdjustment *modelBD);
//  void removeRedundantPtsBetweenExtensidedRidgeAndModelBD(TP_PtList *m_bd,bdAdjustment *modelBD);
	bool updateEdgeEndPoint(int eg_id,CCVector3 *m_position);
//    void ReplaceModelBDintoMixBD(TP_PtList *m_mixBD, bdAdjustment *modelDB,Plane_bd_range *_r=NULL);
//	void ConnectFacadeOutsiderBD(TP_PtList *m_bd,bdAdjustment *modelBD);
    void caculateSinglePlane();

public:
	void ori_add(int id)
	{
		if (ori_id.empty()) {ori_id.push_back(id); m_oriType = ori_single; }
		else
		{
			bool f_find= false;
			for (int i = 0; i< ori_id.size(); i++)
			{
				if (id == ori_id.data()[(i)])
				{
					f_find = true;
					break;
				}
			}
			if (f_find == false)
			{
				ori_id.push_back(id); m_oriType = ori_multiply;
			}

		}
	}
	void ori_set(IDList _in)
	{
		ori_id = _in;
	}
	void ori_type_set(ori_Type  _type)
	{
      m_oriType= _type;
	}
	ori_Type ori_type() {return  m_oriType;}
	vector<int > ori_get() {return ori_id;}

};

typedef vector<TP_Plane *>  TP_BuidlingPlanes;


void findEdgeBdBetweenTwoPlanes(TP_Plane *p1,TP_Plane *p2,G_Edge *e_now);
bool planeInPlane(TP_Plane *p1,TP_Plane *p2);


#endif